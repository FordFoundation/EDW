/****** Object:  Job [Secondary Website DB Refresh from Public DB]    Script Date: 11-03-2020 17:31:49 ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'd138fe05-5121-4e29-a44a-6a0e3b5e9e77', @delete_unused_schedule=1
GO

/****** Object:  Job [Secondary Website DB Refresh from Public DB]    Script Date: 11-03-2020 17:31:49 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 11-03-2020 17:31:51 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Secondary Website DB Refresh from Public DB', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'dbadmin', 
		@notify_email_operator_name=N'GBSII', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Drop Tables for Website DB]    Script Date: 11-03-2020 17:31:52 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Drop Tables for Website DB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DROP TABLE IF EXISTS dbo.[Grants_Subjects]
Go 

DROP table IF EXISTS [dbo].[Grants_Program]
go

drop table IF EXISTS [dbo].[LOC_grants_locations]
go


drop table  IF EXISTS DBO.LOC_Locations
go

drop table IF EXISTS DBO.LOC_Grants
go

DROP TABLE IF EXISTS [dbo].[Grants]
GO

', 
		@database_name=N'PROD_WebsiteData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Create Table]    Script Date: 11-03-2020 17:31:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Create Table', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--- Grant Table 

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Grants](
	[Id] [int] NOT NULL,
	[Amount] [float] NOT NULL,
	[BenefitingLocations] [text] NOT NULL,
	BenefitingPopulations_Gender [text] NOT NULL,

	BenefitingPopulations_Race_Ethinicity [text] NOT NULL,
	--[Description] [text] NOT NULL,
	[Description] [text]  NULL,
	[EndDate] [date] NOT NULL,
	[FiscalYearOfApproval] [int] NOT NULL,
	[GranteeId] [int] NOT NULL,
	[GranteeName] [nvarchar](max) NOT NULL,
                [SortAsName] [varchar](1000) NULL,
	[RegionId] [int] NOT NULL,
	[RegionName] [nvarchar](max) NOT NULL,
	[StartDate] [date] NOT NULL,
	[IsBuild] [bit] NULL,
	[LinesOfWorkBitmask] [bigint] NOT NULL,
	[SubjectsBitmask] [bigint] NULL,
 CONSTRAINT [PrimaryKey_55b8b745-c314-4d67-ad9d-30346a75f971] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

--- Loc Grants

CREATE TABLE [dbo].[LOC_grants_locations](
	[GrantId] [int] NOT NULL,
	[LocationId] [int] NOT NULL,
	[Percentage] [int] NOT NULL
) ON [PRIMARY]

GO

----- Grants Program


CREATE TABLE [dbo].[Grants_Program](
	[GrantId] [int] NOT NULL,
	[OCProgramAreaID] [int] NOT NULL,
	
) ON [PRIMARY]

GO

----- Grant Subjects 

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Grants_Subjects](
	[GrantId] [int] NOT NULL,
	[SubjectId] [int] NOT NULL,
 CONSTRAINT [PK_Grants_Subjects] PRIMARY KEY CLUSTERED 
(
	[GrantId] ASC,
	[SubjectId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO 
', 
		@database_name=N'PROD_WebsiteData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Insert into Grants - Website DB]    Script Date: 11-03-2020 17:31:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Insert into Grants - Website DB', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET QUOTED_IDENTIFIER ON 
exec sp_updatestats
insert into PROD_WebsiteData.[dbo].Grants( [Id]
      ,[Amount]
      ,[BenefitingLocations]
      ,BenefitingPopulations_Gender
       ,BenefitingPopulations_Race_Ethinicity
      ,[Description]
      ,[EndDate]
      ,[FiscalYearOfApproval]
      ,[GranteeId]
      ,[GranteeName]
       ,[SortAsName]
      ,
       [RegionId]
      ,[RegionName]
      ,[StartDate]
      ,[IsBuild]
       , LinesOfWorkBitmask,[SubjectsBitmask])

select [Id]
      ,[Amount]
      ,[BenefitingLocations]
      ,BenefitingPopulations_Gender
         ,BenefitingPopulations_Race_Ethinicity
      ,[Description]
      ,[EndDate]
      ,[FiscalYearOfApproval]
      ,[GranteeId]
      ,[GranteeName]
         ,[SortAsName]
      ,
         [RegionId]
      ,[RegionName]
      ,[StartDate]
      ,[IsBuild]
         ,0 as LinesOfWorkBitmask,0 as [SubjectsBitmask]
  
         from 
         (
select 
[Id]
      ,[Amount]
      ,isnull([BenefitingLocations],'''') as [BenefitingLocations]
      ,isnull(BenefitingPopulations_Gender,'''') as BenefitingPopulations_Gender
         ,isnull(BenefitingPopulations_Race_Ethinicity,'''') as BenefitingPopulations_Race_Ethinicity
      ,[Description]
      ,isnull([EndDate],''1/1/1970'') as [EndDate]
      ,[FiscalYearOfApproval]
      ,[GranteeId]
      ,[GranteeName]
         ,[SortAsName]
      ,
       row_number() over(partition by id order by  regionname asc) as regioncount,   [RegionId]
      ,  [RegionName]
      ,isnull([StartDate],''1/1/1970'') as [StartDate]
      , IsBuild
      --,[LinesOfWorkBitmask]
      --,[SubjectsBitmask]
from 
(
select [Id]
      ,[Amount]
      ,[BenefitingLocations]
      ,BenefitingPopulations_Gender
         ,BenefitingPopulations_Race_Ethinicity
      ,[Description]
      ,[EndDate]
      ,[FiscalYearOfApproval]
      ,[GranteeId]
      ,[GranteeName]
         ,[SortAsName]
      
      ,[StartDate]
      ,[IsBuild]
       , ---row_number() over(partition by id order by regionname   ) as regioncount---,
       isnull([RegionId],9) as [RegionId]
      ,isnull([RegionName],''United States'') as [RegionName]
         --,grantamount

from
(
select distinct  gg.Id,Granttitle as [Description] ,StartDate,enddate,
FyOfApproval as [FiscalYearOfApproval],gg.GranteeId,NetAmount as Amount,
gg.[Grantee Name] as GranteeName ,ge.GranteeSortCode as [SortAsName]
,case granttype when ''BUILD''  then 1 else 0 end  as IsBuild,

BenefitingLocations = 
        STUFF(
                 (SELECT  ''@@@''+cast(GRL.LocationId as varchar) +''###'' + locations.LocationName+''###'' +
                 cast(GRL.Percentage as varchar)--+ ''@@@''
                     FROM Grants_Locations  GRL
                     inner join Locations on locations.Id=GRL.LocationId

                     WHERE GRL.GrantId=gg.Id
                 FOR XML PATH(''''),root(''BenLoc''), type 
     ).value(''/BenLoc[1]'',''varchar(max)'')
       , 1, 3, ''''),

BenefitingPopulations_Gender = 
        STUFF(
                 (SELECT  ''@@@''+cast(GRP.PopulationId as varchar) +''###'' + Populations.Description
                -- +''###'' +           cast(GRP.Percentage as varchar)--+ ''@@@''
                     FROM [dbo].[Grants_TargetGender_Populations]  GRP
                     inner join [dbo].[Populations_Gender] Populations on Populations.ID=GRP.PopulationId

                     WHERE GRP.GrantId=gg.Id
                 FOR XML PATH(''''),root(''BenPOP''), type 
     ).value(''/BenPOP[1]'',''varchar(max)'')
       , 1, 3, ''''),

       BenefitingPopulations_Race_Ethinicity = 
        STUFF(
                 (SELECT  ''@@@''+cast(GRP.PopulationId as varchar) +''###'' + Populations.Description
                 --+''###'' +cast(GRP.Percentage as varchar)--+ ''@@@''
                     FROM [dbo].[Grants_TargetRace_Ethnicity_Populations]  GRP
                     inner join [dbo].[Populations_Race_Ethinicty] Populations on Populations.ID=GRP.PopulationId

                     WHERE GRP.GrantId=gg.Id
                 FOR XML PATH(''''),root(''BenPOP''), type 
     ).value(''/BenPOP[1]'',''varchar(max)'')
       , 1, 3, ''''),
       ---row_number() over(partition by regionid1 order by regionname ) as regioncount,
         isnull(r1.[OCRegionID],Regions.[OCRegionID]) as [RegionID]
         ,isnull(r1.[OCRegionName],Regions.[OCRegionName]) as [RegionName]--,
         


--GDGE.grantid as Geograntid

from grants gg
inner join grantees ge on ge.Id=gg.GranteeId
left outer join [dbo].[Regions]gdge on  gdge.id=gg.regionid

left outer join  [PROD_WebsiteData].[dbo].[RegionMapping] Regions on Regions.[FLUXXID]=gg.RegionId
left outer join [PROD_WebsiteData].[dbo].[RegionMapping] r1 on r1.[OCRegionName]=gdge.[name]
where 
       FyOfApproval>=2006 --
and    gg.NetAmount>1000
and          gg.granttype<>''PRI''
)
grantnewstructure 
--,118297,125937)

) aa
---where  ID in(122832)
)countregion
where  
---ID in(123539) and

regioncount=1 
', 
		@database_name=N'PROD_PublicData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Insert into Subjects - Website DB]    Script Date: 11-03-2020 17:31:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Insert into Subjects - Website DB', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into PROD_WebsiteData.[dbo].[Grants_Subjects] ( GrantId,SubjectId)

 select distinct  grantid, isnull(id,12) as SubjectID from 
  (
   select  gg.id as Grantid,  sub.[OC Subject ID] as id

  from PROD_WebsiteData.[dbo].grants gg
  inner join [dbo].[Grants_Subjects] grsub on grsub.GrantId=gg.Id
  inner join PROD_PublicData.dbo.grants gg1 on gg.id=gg1.id
left outer join PROD_WebsiteData.[dbo].[SubjectsMapping] submap on submap.[Fluxx Subject ID]=grsub.[SubjectsId]
left outer join PROD_WebsiteData.dbo.[Subjects] sub  on sub.[OC Subject ID]=submap.[OC Subject ID]
WHERE gg1.granttype<>''PRI''
)subject', 
		@database_name=N'PROD_PublicData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Insert Program table]    Script Date: 11-03-2020 17:31:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Insert Program table', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into PROD_WebsiteData.[dbo].[Grants_Program] 


select distinct grl.grantid ,isnull(pm.[OCProgramAreaID],8) as OCProgramAreaID
 from [PROD_PublicData].[dbo].[Grants_ProgramLOWOutcome] grl
inner join PROD_WebsiteData.dbo.grants g on g.Id=grl.grantid
inner join PROD_PublicData.dbo.grants gg1 on g.id=gg1.id
left outer join PROD_WebsiteData.[dbo].[ProgramMapping] pm on pm.[FluxxProgramID]=grl.ProgramID 
and pm.[FluxxLowID]=grl.[LOWID] and gg1.granttype<>''PRI''', 
		@database_name=N'PROD_PublicData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Insert Loc Tables]    Script Date: 11-03-2020 17:31:54 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Insert Loc Tables', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into PROD_WebsiteData.[dbo].[LOC_grants_locations] 

select distinct grl.grantid, grl.LocationId ,percentage  
from [dbo].[Grants_Locations] grl
	inner join PROD_WebsiteData.[dbo].grants g on g.Id=grl.grantid
                inner join PROD_PublicData.dbo.grants gg1 on g.id=gg1.id
	where gg1.granttype<>''PRI''


select * into PROD_WebsiteData.[dbo].LOC_Locations 
FROM 
DBO.LOCATIONS



select g.Id,g.Description,g.GranteeName,g.Amount,g.[FiscalYearOfApproval] as FYofApproval
,g.RegionId,g.GranteeId, g.[LinesOfWorkBitmask]  as LowBitmask,  g.[SubjectsBitmask], g.IsBuild
 into PROD_WEBSITEDATA.DBO.LOC_Grants FROM 

PROD_WEBSITEDATA.[dbo].[Grants] g
 inner join PROD_PublicData.dbo.grants gg1 on g.id=gg1.id
	where gg1.granttype<>''PRI''
', 
		@database_name=N'PROD_PublicData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


