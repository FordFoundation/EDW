/****** Object:  StoredProcedure [dbo].[Sp_Fluxx_Foundation_Center_report]    Script Date: 11-03-2020 17:28:14 ******/
DROP PROCEDURE [dbo].[Sp_Fluxx_Foundation_Center_report]
GO

/****** Object:  StoredProcedure [dbo].[Sp_Fluxx_Foundation_Center_report]    Script Date: 11-03-2020 17:28:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*=============================================               
  
Revision History:        
******************  
Created By  : Siva Bache   
Created At  : 27/04/2018
Modified At : 
Description : Foundation Center report

Modified By: 
Modified on: 
Description: 
-- EXEC [dbo].[Sp_Fluxx_Foundation_Center_report] '2020-01-01 00:00:00.000','2020-01-31 00:00:00.000'
=============================================*/

CREATE PROCEDURE [dbo].[Sp_Fluxx_Foundation_Center_report] 
(
@MonthStart datetime,
@MonthEnd datetime
)  
AS                      
BEGIN  

print @MonthStart 
print @MonthEnd

select gl.grantid,(select TOP 1 ltrim(rtrim(Hierarchy)) from [dbo].[Fn_Get_LOC_Hierarchy] (l.id,l.locationname)) location
into #location0
from Grants_Locations GL 
INNER join Locations l on gl.LocationId=l.id

select distinct  grantid,location,convert(int,lpcs.[FC geoplace key]) [FC geoplace key]
into #location
from #location0 l
left join Location_PCS_Code lpcs on   right(location,charindex('/',reverse(location))-2) =lpcs.[Ford term]


SELECT B.Grantid
, STUFF((SELECT '; ' + A.location  FROM #location A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As location
, STUFF((SELECT '; ' + convert(varchar(max),A.[FC geoplace key])  FROM #location A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As location_lpcsCode
into #location2
From #location B
Group By B.Grantid

------------not necessary in query ProgramLOWOutcome----------------
 
SELECT  distinct grantid,Program +';'+low Program
INTO #Grants_ProgramLOWOutcome1 
FROM Grants_ProgramLOWOutcome
order by grantid

SELECT B.Grantid
, STUFF((SELECT '; ' + A.Program  FROM #Grants_ProgramLOWOutcome1 A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As [Program/Low]
into #Grants_ProgramLOWOutcome
From #Grants_ProgramLOWOutcome1 B
Group By B.Grantid

--------------------------Outcome--------------------------------------

SELECT  distinct grantid,Outcome
INTO #Grants_Outcome1 
FROM Grants_ProgramLOWOutcome
order by grantid

SELECT B.Grantid
, STUFF((SELECT '; ' + A.Outcome  FROM #Grants_Outcome1 A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As Outcome
into #Grants_Outcome
From #Grants_Outcome1 B
Group By B.Grantid

-------------------------SubjectName-------------------------------

SELECT B.Grantid,SubjectHierarchy
into #Subject0
From Grants_Subjects B

select #Subject0.*,lpcs.[PCS Subject Code]
into #Subject1
from #Subject0
left join Subject_PCS_Code lpcs on   right(SubjectHierarchy,IIF(SubjectHierarchy like '%/%',charindex('/',reverse(SubjectHierarchy))-1,len(SubjectHierarchy))) =lpcs.[Ford term] 


SELECT B.Grantid
, STUFF((SELECT '; ' + A.SubjectHierarchy  FROM #Subject1 A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As SubjectName
, STUFF((SELECT '; ' + A.[PCS Subject Code]  FROM #Subject1 A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As [PCS Subject Code]
into #Subject
From #Subject1 B
Group By B.Grantid

-----------------------TargetGender
SELECT GTP.Grantid,case when PG.Description='No Intention' THEN NULL ELSE PG.Description END Description  
INTO #Gender0
FROM Grants_TargetGender_Populations GTP
LEFT JOIN Populations_Gender PG ON GTP.Populationid=PG.id
where pg.isactive=1 --and pg.Description<>'No Intention' 


select distinct  grantid,Description,lpcs.[PCS Code(s)] [PCS Code(s)]
into #Gender
from #Gender0 l
left join Gender_PCS_Code lpcs on   Description=replace([Hierarchy (sort order)],'|','/ ')
--right(Description,IIF(Description like '%/%',charindex('/',reverse(Description))-2,len(Description))) =lpcs.[Ford term]

SELECT B.Grantid
, STUFF((SELECT '; ' +A.Description FROM #Gender A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As Gender_Description
, STUFF((SELECT '; ' + A.[PCS Code(s)] FROM #Gender A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As [PCS Code(s)_Gender]
into #Gender1
From #Gender B
Group By B.Grantid


--TargetRace
SELECT DISTINCT GTEP.GrantID
,(CASE WHEN (D2.[RefDesc] IS NULL or D2.[RefDesc]='No Intention' or D2.[RefDesc]='') THEN '' ELSE D2.[RefDesc]+'/ ' END )
+(CASE WHEN (D1.[RefDesc] IS NULL or D1.[RefDesc]='No Intention' or D1.[RefDesc]='') THEN '' ELSE D1.[RefDesc]+'/ ' END )
+(CASE WHEN (D.[RefDesc] IS NULL  or D.[RefDesc]='No Intention' or D.[RefDesc]='') THEN '' ELSE D.[RefDesc] END )as Description 
INTO #Race0
FROM [PROD_Fluxx_Reporting].[dbo].[Dim_MasterData] D
left join [PROD_Fluxx_Reporting].[dbo].[Dim_MasterData] D1 ON D1.fluxxid=d.parentfluxxid
left join [PROD_Fluxx_Reporting].[dbo].[Dim_MasterData] D2 ON D1.parentfluxxid=d2.fluxxid 
left join [PROD_PublicData].[dbo].Grants_TargetRace_Ethnicity_Populations GTEP ON GTEP.populationid=D.fluxxid 
WHERE GTEP.GrantID<>0 and D.reftype='TargetRace'


select distinct  grantid,Description,lpcs.[PCS Code(s)] [PCS Code(s)]
into #Race
from #Race0 l
left join Ethnicity_PCS_Code lpcs on   Description=replace([Hierarchy (sort order)],'|','/ ')
--right(Description,IIF(Description like '%/%',charindex('/',reverse(Description))-2,len(Description))) =lpcs.[Ford term]

SELECT B.Grantid
, STUFF((SELECT '; '+A.Description FROM #Race A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As Race_Description
,  STUFF((SELECT '; '+A.[PCS Code(s)] FROM #Race A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As [PCS Code(s)_RACE]
into #Race1
From #Race B
Group By B.Grantid

-----------------------Who
SELECT distinct Grantid,whohierarchy INTO #Who0
FROM Grants_TargetOther_Who 


select distinct  grantid,whohierarchy,lpcs.[PCS Code] [PCS Code]
into #Who
from #Who0 l
left join [Who Other_PCS_Code] lpcs on  right(whohierarchy,IIF(whohierarchy like '%/%',charindex('/',reverse(whohierarchy))-1,len(whohierarchy))) =lpcs.[Ford term]

SELECT B.Grantid
, STUFF((SELECT '; '+ A.whohierarchy FROM #Who A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As whohierarchy
, STUFF((SELECT '; '+ A.[PCS Code] FROM #Who A
Where A.Grantid=B.Grantid FOR XML PATH('')),1,1,'') As [PCS Code_who]
into #Who1
From #Who B
Group By B.Grantid


SELECT 
     DISTINCT
	'The Ford Foundation' [Grantor Name], 
	'320 43rd Street'     [Grantor Street Address], 
	'New York City'       [Grantor City], 
	'New York City'       [Grantor State], 
	'10017'               [Grantor Zip Code], 
	'United States'       [Grantor Country],
	--CASE WHEN Ge.Country='United States' THEN '' ELSE 'United States' END    [Grantor Country],
	Ge.[GranteeLegalName] [Grantee Name],
	''					  [Grantee AKA],
	''                    [Grantee DBA],
	''					  [Grantee FKA],
	'' [Grant Shared With], 
	'' [Grant Made With], 
	ltrim(rtrim(oc.OutCome)) [Grant Outcomes], 
	'' [Fiscal Sponsor], 
	l.location [Geographic Area Served],
	Ge.TaxIdentificationNumber  [Tax ID],
	--CASE WHEN GranteeName like '%,%' THEN substring(GranteeName,charindex(',',GranteeName)+2,len(GranteeName))
	--ELSE '' END		      grantee_unit,
	''                    [Grantee Unit],
	Ge.Adress1            [Grantee Street Address],
	--Ge.Address2            [Grantee Street Address 2],
	''					   [Grantee PO Box],
	Ge.City                [Grantee City],
	Ge.State               [Grantee State/Providence],
	Ge.PostalCode          [Gratnee Postal Code],
	CASE WHEN Ge.Country='United States' then '' else Ge.Country end    [Grantee Country],
	--Ge.Granteephonenumber  [Grantee Telephone],
	''                     [Grantee E-mail Address],
	Ge.WebsiteURL          [Grantee URL],
	--Ge.GranteeType         [Grantee Type],
	G.id                   [Grant ID],
	G.Granttitle                   [Grant Description],
	''           [Grant Title],
	G.NetAmount            [Grant Amount],
	'USD'                  [Currency],
	G.FiscalYear    [Fiscal Year End Date],
	CONVERT(VARCHAR(MAX),G.StartDate,101)            [Grant Start Date],
	CONVERT(VARCHAR(MAX),G.EndDate ,101)             [Grant End Date],
	CASE WHEN G.GrantType <>'PRI' THEN 'Cash grant' ELSE G.GrantType END        [Grant Type],
	left(G1.grant_support_type, abs(len(G1.grant_support_type + ',') - 2))  [Grant Support Type],
	''                       [Grant Duration (in Years)],
	G.[Term Length]       [Grant Duration (in Months)],
	--LTRIM(RTRIM(GPL.[Program/Low]))     [Program Area],
	--G.RPO [Program Area],
	GPA.ProgramArea [Program Area],
	LTRIM(RTRIM(s.SubjectName))        [Grant Subject],
	COALESCE(NULLIF(
	 CASE WHEN (LTRIM(RTRIM(Gen.Gender_Description)) IS NULL OR LTRIM(RTRIM(Gen.Gender_Description))='') THEN '' ELSE LTRIM(RTRIM(Gen.Gender_Description))+';' END 
	+CASE WHEN (LTRIM(RTRIM(R.Race_Description)) IS NULL OR LTRIM(RTRIM(R.Race_Description))='') THEN '' ELSE LTRIM(RTRIM(R.Race_Description))+';' END 
	+CASE WHEN (LTRIM(RTRIM(Who.WhoHierarchy)) IS NULL OR LTRIM(RTRIM(Who.WhoHierarchy))='') THEN '' ELSE LTRIM(RTRIM(Who.WhoHierarchy)) END,''),'No Intention')  [Grant Population Served],
	''                 [Publishable to IATI],
	G.ApprovalDate,
	l.location_lpcsCode [Geographic Area Served PCS Code],
	s.[PCS Subject Code] [Grant Subject PCS Code],
	COALESCE(NULLIF(
	 CASE WHEN (LTRIM(RTRIM(Gen.[PCS Code(s)_Gender])) IS NULL OR LTRIM(RTRIM(Gen.[PCS Code(s)_Gender]))='') THEN '' ELSE LTRIM(RTRIM(Gen.[PCS Code(s)_Gender]))+';' END 
	+CASE WHEN (LTRIM(RTRIM(R.[PCS Code(s)_RACE])) IS NULL OR LTRIM(RTRIM(R.[PCS Code(s)_RACE]))='') THEN '' ELSE LTRIM(RTRIM(R.[PCS Code(s)_RACE]))+';' END 
	+CASE WHEN (LTRIM(RTRIM(Who.[PCS Code_who])) IS NULL OR LTRIM(RTRIM(Who.[PCS Code_who]))='') THEN '' ELSE LTRIM(RTRIM(Who.[PCS Code_who])) END,''),'') [Grant Population Served PCS Codes]
	,YEAR(ApprovalDate) ApprovalYear

FROM 
	Grants G
	Inner join Grantees Ge ON G.GranteeId=Ge.id
	Inner Join
	(
		SELECT 
		id,case when [General Support] =1 then 'General,' ELSE '' END+''+
		case when [Core Support] =1  then 'Core,' ELSE '' END +''+
		case When [Project Support] =1 THEN 'Project,' ELSE '' END  grant_support_type
		FROM Grants
	) G1 On G1.id=G.id
	left join #Grants_ProgramLOWOutcome GPL On GPL.Grantid=G.id
	Left Join #Grants_Outcome OC ON OC.Grantid=G.id 
	left join #location2 l on l.grantid=g.id
	left join #Subject s on s.grantid=g.id
	LEFT JOIN #Gender1 Gen on Gen.Grantid=g.id
	LEFT JOIN #Race1 R on R.Grantid=g.id
	LEFT JOIN #Who1 Who on Who.Grantid=G.id
	LEFT JOIN Grants_ProgramArea GPA ON GPA.Grantid=G.id
	WHERE G.approvaldate IS NOT NULL
	AND  G.NetAmount>0
	and convert(datetime,ApprovalDate) >= @MonthStart and  convert(datetime,ApprovalDate) <= @MonthEnd



END







GO


