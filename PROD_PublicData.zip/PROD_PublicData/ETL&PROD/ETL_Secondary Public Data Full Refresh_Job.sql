/****** Object:  Job [Secondary Public Data Full Refresh]    Script Date: 11-03-2020 17:20:56 ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'aff8b43e-de38-4269-b4e6-8149399efe4d', @delete_unused_schedule=1
GO

/****** Object:  Job [Secondary Public Data Full Refresh]    Script Date: 11-03-2020 17:20:57 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 11-03-2020 17:20:58 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Secondary Public Data Full Refresh', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'dbadmin', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Truncate Tables]    Script Date: 11-03-2020 17:21:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Truncate Tables', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DELETE FROM dbo.[Grants_ProgramArea] Where Grantid in (Select GrantID From PROD_Fluxx_Reporting..Fact_grantdetails Where GrantFiscalYear >= 2018)
GO
DELETE FROM dbo.Grants_Locations
GO
DELETE FROM dbo.Grants_TargetGender_Populations
GO
DELETE FROM dbo.Grants_TargetRace_Ethnicity_Populations
GO
DELETE FROM dbo.[Grants_ProgramLOWOutcome]
GO
DELETE FROM [dbo].[Grants_Subjects]
GO
DELETE FROM dbo.Grants
GO
DELETE FROM dbo.Grantees
GO
DELETE FROM dbo.Locations
GO
DELETE FROM dbo.Populations_Race_Ethinicty
GO
DELETE FROM dbo.Populations_Gender
GO
DELETE FROM dbo.Regions
GO
DELETE FROM dbo.Subjects
GO
DELETE FROM dbo.Grants_StrategyMasterData
GO
DELETE FROM dbo.Grants_TargetOther_Who
GO
DELETE FROM dbo.ThematicArea_FordReport
GO', 
		@database_name=N'PROD_PublicData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Data Migration From EDW]    Script Date: 11-03-2020 17:21:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Data Migration From EDW', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantStrategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantStrategy] 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Strategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Strategy] 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Found_Targetother]'') AND type in (N''U''))
DROP TABLE [dbo].[Found_Targetother] 
GO

/****************Grantees*************************/
INSERT INTO dbo.Grantees (Id, GranteeSortCode, GranteeName, GranteeLegalName,Adress1, 
Address2, City, [State], Province, Country, PostalCode,TaxIdentificationNumber,WebsiteURL,GranteeType,GranteePhoneNumber)
SELECT GD.OrganizationId,GD.SortAsName,
case when GD.organizationType=''Individual'' THEN ''Individual Grantee'' ELSE GD.OrganizationName END OrganizationName, 
case when GD.organizationType=''Individual'' THEN ''Individual Grantee'' ELSE GD.OrganizationLegalName END OrganizationLegalName, 
case when GD.organizationType=''Individual'' THEN '''' ELSE GD.PermAddressStreetAddress1 END PermAddressStreetAddress1,
case when GD.organizationType=''Individual'' THEN '''' ELSE GD.PermAddressStreetAddress2 END PermAddressStreetAddress2,
case when GD.organizationType=''Individual'' THEN '''' ELSE GD.PermCity END PermCity,
GD.PermState,GD.PermState,GD.PermCountry,GD.PermPostalCode,
case when GD.organizationType=''Individual'' THEN '''' ELSE GD.TaxIdentificationNumber END TaxIdentificationNumber,
GD.WebsiteURL,GD.OrganizationType,GD.OrganizationPhoneNumber
FROM PROD_Fluxx_Reporting..Dim_OrganizationInfo GD
WHERE GD.OrganizationId IS NOT NULL
GO

/***************Subjects********************************/
Insert into Subjects (Id, SubjectName, ParentSubjectId, IsActive)
select FluxxId as ID,RefDesc as SubjectName,ParentFluxxId as ParentSubjectId,
Isactive  from PROD_Fluxx_Reporting..Dim_Masterdata where reftype=''TargetSubject''
GO

/************************Locations*****************************/ 
INSERT INTO dbo.Locations (Id, LocationName, LocationType, ParentLocationId,IsActive)
SELECT LS.FluxxgeoplaceID,LS.LocationName,LS.LocationType,ParentID,1 as IsActive FROM PROD_Fluxx_Reporting..Dim_Locations LS
WHERE LS.FluxxgeoplaceID IS NOT NULL
GO

/********************Populations - Gender************************/
INSERT INTO dbo.Populations_Gender (Id, [Description],IsActive)
SELECT FluxxId ,[RefDesc], IsActive FROM PROD_Fluxx_Reporting..Dim_Masterdata
WHERE RefType=''TargetGender''
GO

/********************Populations - Race_Ethinicty************************/
INSERT INTO dbo.Populations_Race_Ethinicty (Id, [Description],IsActive)
SELECT FluxxId ,[RefDesc], IsActive FROM PROD_Fluxx_Reporting..Dim_Masterdata
WHERE RefType=''TargetRace''
GO

/************************Regions*****************************/ 
INSERT INTO dbo.Regions(id,Name,Iscurrent)
SELECT FluxxId ,[RefDesc],Isactive FROM PROD_Fluxx_Reporting..Dim_Masterdata
WHERE RefType=''Regions''
GO

/*************************Grants********************************/
INSERT INTO [dbo].[Grants] (Id, Granttitle, Targetamount, NetAmount, ApprovalDate, StartDate, EndDate, FyOfApproval, 
GrantType, GranteeId, FundingSourceName, LowName, [Grantee Name],[secondary Grantee Name], RegionId,[currentgrantstatus],[General Support],[Core Support],[Project Support],[Term Length],FiscalYear,RPO)
Select FGD.GrantId as ID, Title as GrantDescription,GrantTargetAmount as OriginalAmount,
GrantNetAmount as NetAmount, GrantApprovedDate as ApprovalDate,TermStartDate as StartDate,
TermCurrentEndDate as EndDate,GrantFiscalYear as FyOfApproval,GrantTypeText as GrantType,
DOI.OrganizationId as GranteeId,Gamount.FundingSourceName as Costcentername,Gamount.LowName as ThemeName, 
PrimaryOrganizationName as [Grantee Name],secondaryOrganizationName as [secondary Grantee Name],RG.ID as RegionId,FGD.[CurrentGrantStatus],
FGD.[General Support],FGD.[Core Support],FGD.[Project Support] ,FGD.TermLength	,FGD.GrantFiscalYear,FGD.[RPO Office]
From PROD_Fluxx_Reporting..Fact_grantdetails FGD
Inner Join PROD_Fluxx_Reporting..Dim_OrganizationInfo DOI ON FGD.PrimaryOrganizationKey=DOI.OrganizationInfoKey
Inner Join (Select distinct grantId From PROD_Fluxx_Reporting..Fact_Grantpayments where paystatus=''Paid'') PTF ON FGD.GrantId=PTF.GrantId
Left Outer Join [dbo].[Regions] RG ON ltrim(rtrim(FGD.[RPO Office]))=ltrim(rtrim(RG.name))
Left Outer Join (SELECT a.GrantId, a.FundingSourceName, a.LowName FROM PROD_Fluxx_Reporting..fact_grantamountdetails a
INNER JOIN (SELECT e.GrantId, max(e.grantamountid) as maxid
FROM PROD_Fluxx_Reporting..fact_grantamountdetails e 
Where e.amount in (Select MAX(c.Amount) amounts From PROD_Fluxx_Reporting..fact_grantamountdetails c
where c.grantid=e.grantid group by c.grantid) GROUP BY e.GrantId) b ON a.GrantId = b.GrantId and a.grantamountid=b.maxid) Gamount ON  FGD.GrantId= Gamount.GrantId
Where FGD.GrantNetAmount<>0 and granttypetext not in (''FAP'',''PRI'')

Union

Select FGD.GrantId as ID, Title as GrantDescription,GrantTargetAmount as OriginalAmount,
GrantNetAmount as NetAmount, GrantApprovedDate as ApprovalDate,TermStartDate as StartDate,
TermCurrentEndDate as EndDate,GrantFiscalYear as FyOfApproval,GrantTypeText as GrantType,
DOI.OrganizationId as GranteeId,Gamount.FundingSourceName as Costcentername,Gamount.LowName as ThemeName, 
PrimaryOrganizationName as [Grantee Name],secondaryOrganizationName as [secondary Grantee Name],RG.ID as RegionId,FGD.[CurrentGrantStatus],
FGD.[General Support],FGD.[Core Support],FGD.[Project Support],FGD.TermLength,FGD.GrantFiscalYear,FGD.[RPO Office]		
From PROD_Fluxx_Reporting..Fact_grantdetails FGD
Inner Join PROD_Fluxx_Reporting..Dim_OrganizationInfo DOI ON FGD.PrimaryOrganizationKey=DOI.OrganizationInfoKey
Left Outer Join [dbo].[Regions] RG ON ltrim(rtrim(FGD.[RPO Office]))=ltrim(rtrim(RG.name))
Left Outer Join (SELECT a.GrantId, a.FundingSourceName, a.LowName FROM PROD_Fluxx_Reporting..fact_grantamountdetails a
INNER JOIN (SELECT e.GrantId, max(e.grantamountid) as maxid
FROM PROD_Fluxx_Reporting..fact_grantamountdetails e 
Where e.amount in (Select MAX(c.Amount) amounts From PROD_Fluxx_Reporting..fact_grantamountdetails c
where c.grantid=e.grantid group by c.grantid) GROUP BY e.GrantId) b ON a.GrantId = b.GrantId and a.grantamountid=b.maxid) Gamount ON  FGD.GrantId= Gamount.GrantId
Where FGD.GrantApprovedDate IS NOT NULL and FGD.GrantApprovedDate<>''1900-01-01 00:00:00.000'' and granttypetext in (''FAP'',''PRI'')
GO



SET QUOTED_IDENTIFIER ON
GO

/*************Grants Subjects********************************/
Insert into [dbo].[Grants_Subjects] (GrantId, SubjectsId, SubjectHierarchy)
select GT.ID as GrantID,ST.ID as SubjectsID,VGW.[SubjectHierarchy] from Grants GT
Inner Join [PROD_Fluxx_Reporting].[dbo].[VW_Fluxx_EDW_GrantSubject_What] VGW ON GT.ID=VGW.GrantId
Inner Join Subjects ST ON VGW.[SubjectID]=ST.ID
GO

/*************Grants_Gender_Populations*****************/
INSERT INTO dbo.Grants_TargetGender_Populations(GrantId, PopulationId)
Select Distinct VT.GrantId,DM.ID as TargetGender  
From PROD_Fluxx_Reporting..[VW_Fluxx_EDW_TargetGender_Who] VT
Left Outer Join (
Select ID, Description From Populations_Gender Where IsActive=1
Union
Select ID, Description From Populations_Gender Where IsActive=0 and 
ltrim(rtrim(Description)) not in (Select ltrim(rtrim(Description)) From Populations_Gender Where IsActive=1))  DM  ON ltrim(rtrim(TargetGender))=ltrim(rtrim(DM.Description))
Inner Join dbo.Grants GS ON VT.GrantId=GS.ID
Where TargetGender IS NOT NULL
GO

/*************Grants_Race_Ethnicity_Populations*****************/
INSERT INTO dbo.Grants_TargetRace_Ethnicity_Populations(GrantId, PopulationId)
Select Distinct VT.GrantId,DM.ID as [TargetRace/Ethnicity]  
From PROD_Fluxx_Reporting..[VW_Fluxx_EDW_TargetRace_Ethnicity_Who] VT
Left Outer Join (
Select ID, Description From Populations_Race_Ethinicty Where IsActive=1
Union
Select ID, Description From Populations_Race_Ethinicty Where IsActive=0 and 
ltrim(rtrim(Description)) not in (Select ltrim(rtrim(Description)) From Populations_Race_Ethinicty Where IsActive=1))  DM ON ltrim(rtrim([TargetRace/Ethnicity]))=ltrim(rtrim(DM.Description))
Inner Join dbo.Grants GS ON VT.GrantId=GS.ID
Where [TargetRace/Ethnicity] IS NOT NULL
GO

/*************Grants_Locations*****************/
INSERT INTO dbo.Grants_Locations(Grantid,LocationId,Percentage)
Select VFTW.GrantId,ISNULL(DL.ID,0) as LocationId,Sum(VFTW.TargetLocationPercentage) as Percentage 
From PROD_Fluxx_Reporting..VW_Fluxx_EDW_TargetLocations_where VFTW 
Inner Join dbo.Grants GS ON VFTW.GrantId=GS.ID
Inner Join Locations DL ON ltrim(rtrim(VFTW.LocationName))=ltrim(rtrim(DL.LocationName))
Group by VFTW.GrantId,ISNULL(DL.ID,0)
GO

/*************Grants Line of Work********************************/
Insert into [dbo].[Grants_ProgramLOWOutcome] 
(GrantId, Program,LOW,Outcome,ProgramID,LOWID,OutcomeID)
select GT.ID as GrantID,VGW.[GrantStrategy Program] as 
Program,VGW.[GrantStrategy LOW] as LOW,VGW.[GrantStrategy Outcomes] as Outcomes,
VGW.[GrantStrategy ProgramID],VGW.[GrantStrategy LOWID],VGW.[GrantStrategy OutcomesID]  from Grants GT
Inner Join [PROD_Fluxx_Reporting].[dbo].[VW_Fluxx_EDW_GrantStrategy_WHY] VGW ON GT.ID=VGW.GrantId

/************************Strategy*****************************/ 
INSERT INTO [dbo].[Grants_StrategyMasterData]([FluxxProgramID],[FluxxLowID]
      ,[FluxxOutcomeID],[Program],[Lows],[Outcome])
SELECT B.ParentFluxxId FluxxProgramID,ISNULL(B.FluxxId,0) FluxxLowID,ISNULL(C.FluxxId,0) FluxxOutcomeID,A.RefDesc Program ,B.RefDesc LOW,C.RefDesc Outcome 
FROM PROD_Fluxx_Reporting..Dim_MasterData A
LEFT JOIN PROD_Fluxx_Reporting..Dim_MasterData B ON A.FluxxId=B.ParentFluxxId
LEFT JOIN PROD_Fluxx_Reporting..Dim_MasterData C On B.FluxxId=C.ParentFluxxId
WHERE ISNULL(A.ParentFluxxId,0)=0 AND A.RefType=''ProgHierarchy'' and ISNULL(B.ParentFluxxId,0)<>0 
Order by A.RefDesc
GO

Select * into Found_Targetother From PROD_Fluxx_Reporting..VW_Fluxx_EDW_TargetOther_Who
GO

/******************************TargetOther_Who*******************************/
INSERT INTO Grants_TargetOther_Who (Grantid,GrantTypeText,WhoHierarchy)
SELECT DISTINCT Vwho.Grantid,cast(ltrim(rtrim(Vwho.GrantTypeText)) as varchar(10)) as GrantTypeText,Vwho.WhoHierarchy FROM Found_Targetother Vwho
Inner Join dbo.Grants GS ON Vwho.GrantId=GS.ID
GO
/*************************Grants Programarea************************/

Select * into GrantStrategy From PROD_Fluxx_Reporting..VW_Fluxx_EDW_GrantStrategy_WHY with (nolock)
GO

Select DISTINCT VFEG.GrantID,VFEG.GrantTypeKey,VFEG.GrantTypeText,VFEG.[GrantStrategy Program],VFEG.[GrantStrategy LOW],
VFEG.[GrantStrategy Outcomes],VFEG.[GrantStrategy ProgramID],VFEG.[GrantStrategy LOWID],VFEG.[GrantStrategy OutcomesID],
VFEG.GrantStrategy,VFEG.[LOW/Outcome],
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim([GrantStrategy]))) > 0,'' ; '','''') + [GrantStrategy] From [dbo].[GrantStrategy] Gout
Where Gout.grantid=FD.GrantID
FOR XML PATH('''')
),1,1,''''),2,4000)))) as Nvarchar(4000)) AS [GrantAnalyticsStrategy] into GrantAnalytics_Strategy From [dbo].[GrantStrategy] VFEG
Inner Join PROD_Fluxx_Reporting..Fact_Grantdetails FD with (nolock) ON VFEG.GrantId=FD.GrantId
GO 

Insert into [dbo].[Grants_ProgramArea] (GrantId,ProgramArea)
Select Distinct [AllRequests_Grants].GrantID,gss.GrantAnalyticsStrategy as [Program Area]
FROM PROD_Fluxx_Reporting..[Fact_Grantdetails] [AllRequests_Grants] With (nolock)
Left outer join GrantAnalytics_Strategy gss With (nolock) on [AllRequests_Grants].grantid=gss.grantid
Where [AllRequests_Grants].GrantFiscalYear >= 2018
Order by [AllRequests_Grants].GrantID
GO

/***************************ThematicArea For FordFoundation Report*****************************/
INSERT INTO [dbo].[ThematicArea_FordReport]
           ([Grantid]
           ,[GrantStrategy Program]
           ,[GrantStrategy Low]
           ,[ProgramArea])

Select [AllRequests_Grants].Grantid,
       [GrantStrategy Program],
	   [GrantStrategy Low] ,
	   CASE WHEN  [GrantStrategy Low]=''Non-low'' 
	   THEN [GrantStrategy Program] 
	   WHEN [GrantStrategy Program]=[GrantStrategy Low] THEN [GrantStrategy Program]
	   ELSE [GrantStrategy Program]+''/ ''+[GrantStrategy Low] END ProgramArea 
FROM PROD_Fluxx_Reporting..[Fact_Grantdetails] [AllRequests_Grants] With (nolock)
Left outer join PROD_Fluxx_Reporting..VW_Fluxx_EDW_GrantStrategy_WHY why with (nolock)  on [AllRequests_Grants].grantid=WHY.grantid
Where [AllRequests_Grants].GrantFiscalYear >= 2018
order by [GrantStrategy Low]

SET QUOTED_IDENTIFIER OFF
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantStrategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantStrategy] 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Strategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Strategy] 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Found_Targetother]'') AND type in (N''U''))
DROP TABLE [dbo].[Found_Targetother] 
GO', 
		@database_name=N'PROD_PublicData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Public DB to Restore into Report Server]    Script Date: 11-03-2020 17:21:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Public DB to Restore into Report Server', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'----Backup 
BACKUP DATABASE [PROD_PublicData] TO  DISK = N''\\FFGCP0558\TEMPSQLBCKP\PROD_PublicData.BAK'' WITH COMPRESSION , copy_only, FORMAT, INIT,  NAME = N''PROD_PublicData-Full Database Backup'', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call Restore From EDW]    Script Date: 11-03-2020 17:21:00 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call Restore From EDW', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'osql -E -S FFGCP0558\INST_EDWPROD -Q "exec msdb.dbo.sp_start_job @job_name = ''Secondary PublicData Restore from ETL''', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


