/****** Object:  View [dbo].[GrantBoardBook_outcomes]    Script Date: 3/11/2020 6:54:12 AM ******/
DROP VIEW [dbo].[GrantBoardBook_outcomes]
GO

/****** Object:  View [dbo].[GrantBoardBook_outcomes]    Script Date: 3/11/2020 6:54:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




---select * from [dbo].[GrantBoardBook_outcomes] 
CREATE  view [dbo].[GrantBoardBook_outcomes] 
as 
Select distinct gd.grantid
,gd.grantfiscalyear
,gd.grantnetamount
,gd.granttargetamount
,gd.PrimaryOrganizationName
,org.PermCity
,org.permstate
,org.permcountry
,org.affiliatedtrusteetext
,gd.Title
,gd.[RPO Office]
,gd.CurrentProgramOfficer
,gd.PrimaryProgramOfficer
,gd.GrantManager
,gd.TermLength
,ISNULL(convert(varchar,gd.TermStartDate,121),'') TermStartDate
,ISNULL(convert(varchar,gd.TermCurrentEndDate,121),'') TermCurrentEndDate
,gd.granttypetext
,gd.CurrentGrantStatus
,gd.[Core Support Percentage]
,gd.[General Support Percentage]
,gd.[Project Support Percentage]
,ISNULL(convert(varchar,gd.grantapproveddate,121),'') grantapproveddate
,GTM.RPOGrouping as [RPO Grantmaking Team] 
,gss.[GrantStrategy LOW]
,gss.[GrantStrategy Outcomes]
,gss.[GrantStrategy Program]
from [dbo].[Fact_GrantDetails] gd
Left Outer Join [dbo].[Dim_OrganizationInfo] ORG ON gd.PrimaryOrganizationKey=ORG.OrganizationInfoKey
left join [PROD_MasterData_DMZ].[dbo].GrantMakingTeamBreakdown GTM ON ltrim(rtrim(gd.[RPO Office]))=ltrim(rtrim(GTM.RefValue)) 
and GTM.refid=7
left outer join 
 GrantAnalytics_Strategy gss With (nolock) on   gd.grantid=gss.grantid





GO


