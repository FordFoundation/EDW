/****** Object:  Job [DMZ Grant Analytics Viz]    Script Date: 3/11/2020 6:57:50 AM ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'93f23c29-1fc8-4a8d-b2f2-2edbe8634910', @delete_unused_schedule=1
GO

/****** Object:  Job [DMZ Grant Analytics Viz]    Script Date: 3/11/2020 6:57:50 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 3/11/2020 6:57:50 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DMZ Grant Analytics Viz', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'FFGCP0535\s.tableaucloud', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Analytics Main Table Data Loading]    Script Date: 3/11/2020 6:57:50 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Analytics Main Table Data Loading', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsLocLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsLocLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsLocs]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsLocs] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsOthersLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsOthersLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsStrategyLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsStrategyLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsSubjectLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsSubjectLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsFullLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsFullLoad] 
GO

------------------------1 : All Other fields

SELECT [AllRequests_Grants].[RPO Office] AS [RPO Office],
  GTM.RPOGrouping as [RPO Grantmaking Team], 
  [AllRequests_Grants].[GrantFiscalYear] AS [GrantFiscalYear],
  [AllRequests_Grants].[GrantID] AS [GrantID],
  [AllRequests_Grants].[Title] AS [GrantTitle],
  [AllRequests_Grants].[PrimaryOrganizationName] AS [PrimaryOrganizationName],
  [AllRequests_Grants].[PrimaryProgramOfficer] AS [PrimaryProgramOfficer],
  [AllRequests_Grants].[CurrentProgramOfficer] AS [CurrentProgramOfficer],
  loc.LocationName,
  loc.LocationType As [Location Type],
  cast(fgc.[TargetLocationPercentage] as decimal(5,2)) as [LocationPercentage],
  Case when loc.LocationType =''State'' or loc.LocationType=''Province'' or loc.LocationType=''Techsmart_State'' then loc.LocationName
  else Case When (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy))) from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''State''))='''' then
  Case When (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Province''))='''' then
  (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Techsmart_State'')) else
  (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Province'')) end else 
  (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''State'')) end end  as [ParentLocationName(State/Province)],
  Case when loc.LocationType =''Country'' or loc.LocationType =''Techsmart_Country'' then loc.LocationName
  else Case When (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Country''))='''' then
  (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Techsmart_Country'')) else
  (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Country'')) end end as [ParentLocationName(Country)],
  case when loc.LocationType =''City''  then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''City'')) end 
  as [ParentLocationName(City)], 
  case when loc.LocationType =''Logical Group''  then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Logical Group'')) end 
  as [ParentLocationName(LogicalGroup)], 
  Case when loc.LocationType =''Continent'' or loc.LocationType=''Techsmart_Continent'' then loc.LocationName
  else Case When (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Continent''))='''' then
  (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Techsmart_Continent'')) else
  (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Continent'')) end 
  end as [ParentLocationName(Continent)],
  Case when loc.LocationType =''Part Of Country'' then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Part Of Country'')) 
  end as [ParentLocationName(Part Of Country)],
  Case when loc.LocationType =''Part Of Continent'' then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='''',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Part Of Continent'')) 
  end as [ParentLocationName(Part Of Continent)],
  (Select Case When len(ltrim(rtrim(Hierarchy))) > 0 then
  ltrim(rtrim(Hierarchy))+''($''+Cast(ISNULL(fgc.Locperamount,0) as Varchar(15))+'')''
  Else '''' End From [dbo].[Fn_Get_Fluxx_LOC_Hierarchy](fgc.TargetLocationKey,LOC.LocationName)) as [Target locations],
  fgc.Locperamount as Locperamount, 
  GrantNetAmount,
  ''State/Province'' as ParentLocationType,
  ''Country'' as ParentLocationType_Country,
  Loc.LocationKey as LocationID,
  CASE WHEN ((loc.LocationName in (''United States'',''Virgin Islands (US)'')) OR 
  ((select ltrim(rtrim(Hierarchy)) from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,''Country'')) in (''United States'',''Virgin Islands (US)'')))
  then ''US''
  else ''International'' end as USIntl,
  ISNULL([AllRequests_Grants].[GrantApprovedDate],'''') AS [GrantApprovedDate],
  [AllRequests_Grants].[GrantTypeText] AS [GrantTypeText],
  [AllRequests_Grants].[ApprovalType] AS [ApprovalType],
  ISNULL([AllRequests_Grants].[TermCurrentEndDate],'''') AS [TermCurrentEndDate],
  ISNULL([AllRequests_Grants].[Termstartdate],'''') AS termstartdate,
  [AllRequests_Grants].[GrantManager] AS [GrantManager],
  [AllRequests_Grants].[CurrentGrantStatus] AS [CurrentGrantStatus],
  GA. [ApproachLevel1], GA. [ApproachLevel2],
  gr.[TargetRace/Ethnicity], 
  gg.[TargetGender],
  [AllRequests_Grants].[Core Support],
  [AllRequests_Grants].[Core Support Percentage],
  [AllRequests_Grants].[General Support],
  [AllRequests_Grants].[General Support Percentage],
  [AllRequests_Grants].[Project Support],
  [AllRequests_Grants].[Project Support Percentage],
  ltrim(rtrim(Case When  [AllRequests_Grants].[Core Support]=1 then ''Core Support (''+Cast([Core Support Percentage] as Varchar(4))+''%)''
  Else '''' End + Case When [AllRequests_Grants].[Core Support]=1 and ([AllRequests_Grants].[General Support]=1 OR
  [AllRequests_Grants].[Project Support]=1) then '' ; '' Else '''' End + Case When [AllRequests_Grants].[General Support]=1 then
  ''General Support (''+Cast([General Support Percentage] as Varchar(4))+''%)'' Else '''' End + Case When ([AllRequests_Grants].[General Support]=1 AND
  [AllRequests_Grants].[Project Support]=1) then '' ; '' Else '''' End + Case When [AllRequests_Grants].[Project Support]=1 then
  ''Project Support (''+Cast([Project Support Percentage] as Varchar(4))+''%)'' Else '''' End)) as [Support type],
  ga.Approach, 
  FGD.FundingSourceName,FGD.LowName,FGD.Amount as GrantAmount,
  GPercentage.[FundingSourceLOW],VTW.targetwhoother,VTW.WhoLevel1,VTW.WhoLevel2,VTW.WhoLevel3,VTW.WhoLevel4,VTW.[WhoOther], 
  ltrim(rtrim(VFC.[Custom Codes])) as [Custom Codes],
  gg.TargetGenderLevel1,gg.TargetGenderLevel2,gg.[Gender], 
  gr.TargetRaceLevel1,gr.TargetRaceLevel2,gr.TargetRaceLevel3,gr.[Race]
  into AnalyticsOthersLoad
FROM [dbo].[Fact_Grantdetails] [AllRequests_Grants] With (nolock)
left join GrantAnalytics_TargetLocation fgc With (nolock) on [AllRequests_Grants].GrantID=fgc.GrantID
left join GrantAnalytics_FundingPercentage GPercentage With (nolock) on [AllRequests_Grants].GrantID=GPercentage.GrantID
left join Dim_Locations LOC With (nolock) on LOC.LocationKey=fgc.TargetLocationKey
left join GrantAnalytics_Approach ga With (nolock) on ga.grantid=[AllRequests_Grants].GrantID
left join GrantAnalytics_Race gr With (nolock) on [AllRequests_Grants].grantid=gr.GrantID
left join GrantAnalytics_Gender gg With (nolock) on [AllRequests_Grants].grantid=gg.grantid
Left join GrantAnalytics_WhoOther VTW With (nolock) ON [AllRequests_Grants].GrantID=VTW.GrantID
Left join GrantAnalytics_CustomCodes VFC With (nolock) ON [AllRequests_Grants].GrantID=VFC.GrantID
left join [PROD_MasterData_DMZ].[dbo].GrantMakingTeamBreakdown GTM With (nolock) ON ltrim(rtrim([AllRequests_Grants].[RPO Office]))=ltrim(rtrim(GTM.RefValue)) and GTM.refid=7
Left join Fact_Grantamountdetails FGD With (nolock) ON [AllRequests_Grants].GrantID=FGD.GrantID
Where   [AllRequests_Grants].[GrantFiscalYear] >= 2006 
and ltrim(rtrim([AllRequests_Grants].currentgrantstatus)) not in (''Delete'',''Declined'',''Rejected Projection'') 
GO

------------------------2 : Program Hirarchey

Select gss.[GrantStrategy Outcomes],gss.[GrantStrategy Program],gss.[GrantStrategy LOW], 
gss.[GrantAnalyticsStrategy] AS [LOW/Outcome],[AllRequests_Grants].GrantID into AnalyticsStrategyLoad
FROM [dbo].[Fact_Grantdetails] [AllRequests_Grants] With (nolock)
left join GrantAnalytics_Strategy gss With (nolock) on   [AllRequests_Grants].grantid=gss.grantid
Where   [AllRequests_Grants].[GrantFiscalYear] >= 2006 
and ltrim(rtrim([AllRequests_Grants].currentgrantstatus)) not in (''Delete'',''Declined'',''Rejected Projection'') 
GO

------------------------3 : Subjects

Select gs.[Target Subject],GS.SubjLevel1,GS.SubjLevel2,GS.SubjLevel3,GS.SubjLevel4,
gs.[Subject],[AllRequests_Grants].GrantID into AnalyticsSubjectLoad
FROM [dbo].[Fact_Grantdetails] [AllRequests_Grants] With (nolock)
left join GrantAnalytics_Subject gs With (nolock) on  [AllRequests_Grants].grantid=gs.grantid
Where   [AllRequests_Grants].[GrantFiscalYear] >= 2006 
and ltrim(rtrim([AllRequests_Grants].currentgrantstatus)) not in (''Delete'',''Declined'',''Rejected Projection'') 
GO

------------------------4 : Location Hirarchey

Select Distinct GrantId,[Target locations] into AnalyticsLocs From  AnalyticsOthersLoad
GO

Select Distinct GrantID,
ltrim(rtrim((select substring(stuff ((Select distinct iif(len(ltrim(rtrim(TGA.[Target locations]))) > 0,'' ; '','''') + TGA.[Target locations] From [DBO].[AnalyticsLocs] TGA
Where TGA.GrantID=[AnalyticsLocs].GrantID    FOR XML PATH('''')
   ),1,1,''''),2,4000)))) as ''Target location'' into AnalyticsLocLoad
From AnalyticsLocs
GO

Select [RPO Office],[RPO Grantmaking Team],GrantFiscalYear,AOL.GrantID,GrantTitle,PrimaryOrganizationName,
PrimaryProgramOfficer,CurrentProgramOfficer,LocationName,[Location Type],LocationPercentage,
[ParentLocationName(State/Province)],[ParentLocationName(Country)], ALD.[Target location],
[ParentLocationName(City)],
[ParentLocationName(LogicalGroup)],[ParentLocationName(Continent)],[ParentLocationName(Part Of Country)],
[ParentLocationName(Part Of Continent)],Locperamount,GrantNetAmount,ParentLocationType,
ParentLocationType_Country,LocationID,USIntl,GrantApprovedDate,GrantTypeText,ApprovalType,TermCurrentEndDate,
termstartdate,GrantManager,CurrentGrantStatus,ApproachLevel1,ApproachLevel2,[TargetRace/Ethnicity],
TargetGender,[Core Support],[Core Support Percentage],[General Support],[General Support Percentage],
[Project Support],[Project Support Percentage],[Support type],Approach,FundingSourceName,LowName,
GrantAmount,FundingSourceLOW,targetwhoother,WhoLevel1,WhoLevel2,WhoLevel3,WhoLevel4,WhoOther,
[Custom Codes],TargetGenderLevel1,TargetGenderLevel2,Gender,TargetRaceLevel1,TargetRaceLevel2,
TargetRaceLevel3,Race into AnalyticsFullLoad From AnalyticsOthersLoad AOL
Left Join AnalyticsLocLoad ALD ON AOL.GrantID=ALD.GrantID
GO

-----------------------5  : Insert Data to Viz Table

Truncate Table GrantAnalyticsViz
GO

DECLARE @Sql NVARCHAR(MAX);

SET @Sql = ''Insert into GrantAnalyticsViz ([RPO Office],[RPO Grantmaking Team],GrantFiscalYear,GrantID,GrantTitle,PrimaryOrganizationName,
PrimaryProgramOfficer,CurrentProgramOfficer,LocationName,[Location Type],[ParentLocationName(State/Province)],
[ParentLocationName(Country)],[Target location],Locperamount,GrantNetAmount,ParentLocationType,ParentLocationType_Country,
LocationID,USIntl,GrantApprovedDate,GrantTypeText,ApprovalType,TermCurrentEndDate,termstartdate,GrantManager,CurrentGrantStatus,
ApproachLevel1,ApproachLevel2,[TargetRace/Ethnicity],[Target Subject],SubjLevel1,SubjLevel2,SubjLevel3,SubjLevel4,
[GrantStrategy Outcomes],[GrantStrategy Program],TargetGender,[GrantStrategy LOW],[Core Support],[Core Support Percentage],
[General Support],[General Support Percentage],[Project Support],[Project Support Percentage],Approach,Subject,
[LOW/Outcome],FundingSourceName,LowName,GrantAmount,targetwhoother,WhoLevel1,WhoLevel2,WhoOther,[Custom Codes],
TargetGenderLevel1,TargetGenderLevel2,Gender,TargetRaceLevel1,TargetRaceLevel2,[Who (Race/ Ethnicity)],
FundingSourceLOW,[Support type],LocationPercentage,[ParentLocationName(City)],[ParentLocationName(LogicalGroup)],
WhoLevel3,WhoLevel4,TargetRaceLevel3,[ParentLocationName(Continent)],[ParentLocationName(Part Of Country)],
[ParentLocationName(Part Of Continent)])
Select [RPO Office],[RPO Grantmaking Team],GrantFiscalYear,AF.GrantID,GrantTitle,PrimaryOrganizationName,
PrimaryProgramOfficer,CurrentProgramOfficer,LocationName,[Location Type],
Cast(ltrim(rtrim([ParentLocationName(State/Province)])) as Varchar(255)) as [ParentLocationName(State/Province)],
Cast(ltrim(rtrim([ParentLocationName(Country)])) as Varchar(255)) as [ParentLocationName(Country)],
Cast(ltrim(rtrim([Target location])) as Varchar(6000)) as [Target location],
Cast(Locperamount as Numeric(36,2)) as Locperamount,GrantNetAmount,ParentLocationType,
ParentLocationType_Country,LocationID,USIntl,GrantApprovedDate,GrantTypeText,ApprovalType,TermCurrentEndDate,
termstartdate,GrantManager,CurrentGrantStatus,ApproachLevel1,ApproachLevel2,[TargetRace/Ethnicity],
ASJ.[Target Subject],ASJ.SubjLevel1,ASJ.SubjLevel2,ASJ.SubjLevel3,ASJ.SubjLevel4,
ASL.[GrantStrategy Outcomes],ASL.[GrantStrategy Program],TargetGender,ASL.[GrantStrategy LOW], 
[Core Support],[Core Support Percentage],[General Support],[General Support Percentage],
[Project Support],[Project Support Percentage],Cast(ltrim(rtrim(Approach)) as Varchar(4000)) as Approach,
Cast(ltrim(rtrim(ASJ.[Subject])) as Varchar(4000)) as [Subject],
Cast(ltrim(rtrim(ASL.[LOW/Outcome])) as Varchar(4000)) as [LOW/Outcome],
FundingSourceName,LowName,GrantAmount,targetwhoother,WhoLevel1,WhoLevel2,
Cast(ltrim(rtrim(WhoOther)) as Varchar(4000)) as WhoOther,
[Custom Codes],TargetGenderLevel1,TargetGenderLevel2,Cast(ltrim(rtrim(Gender)) as Varchar(4000)) as Gender,
TargetRaceLevel1,TargetRaceLevel2,Cast(ltrim(rtrim(Race)) as Varchar(4000)) as [Who (Race/ Ethnicity)],
FundingSourceLOW,Cast(ltrim(rtrim([Support type])) as Varchar(255)) as [Support type],
LocationPercentage,Cast(ltrim(rtrim([ParentLocationName(City)])) as Varchar(255)) as [ParentLocationName(City)],
Cast(ltrim(rtrim([ParentLocationName(LogicalGroup)])) as Varchar(255)) as [ParentLocationName(LogicalGroup)],
WhoLevel3,WhoLevel4,TargetRaceLevel3,
Cast(ltrim(rtrim([ParentLocationName(Continent)])) as Varchar(255)) as [ParentLocationName(Continent)],
Cast(ltrim(rtrim([ParentLocationName(Part Of Country)])) as Varchar(255)) as [ParentLocationName(Part Of Country)],
Cast(ltrim(rtrim([ParentLocationName(Part Of Continent)])) as Varchar(255)) as [ParentLocationName(Part Of Continent)]
From AnalyticsFullLoad AF
Left Join AnalyticsStrategyLoad ASL ON AF.GrantID=ASL.GrantID
Left Join AnalyticsSubjectLoad ASJ ON AF.GrantID=ASJ.GrantID''

EXECUTE sp_executesql @Sql
GO', 
		@database_name=N'PROD_Fluxx_Reporting_DMZ', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Drop Viz Temp Tables]    Script Date: 3/11/2020 6:57:50 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Drop Viz Temp Tables', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsLocLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsLocLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsLocs]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsLocs] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsOthersLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsOthersLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsStrategyLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsStrategyLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsSubjectLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsSubjectLoad] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[AnalyticsFullLoad]'') AND type in (N''U''))
DROP TABLE [dbo].[AnalyticsFullLoad] 
GO', 
		@database_name=N'PROD_Fluxx_Reporting_DMZ', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


