/****** Object:  View [dbo].[GrantBoardBook]    Script Date: 3/11/2020 6:52:57 AM ******/
DROP VIEW [dbo].[GrantBoardBook]
GO

/****** Object:  View [dbo].[GrantBoardBook]    Script Date: 3/11/2020 6:52:57 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE  view [dbo].[GrantBoardBook] 
as 
Select distinct gd.grantid
,gd.grantfiscalyear
,gd.grantnetamount
,gd.granttargetamount
,gd.PrimaryOrganizationName
,org.PermCity
,org.permstate
,org.permcountry
--,org.affiliatedtrusteetext
,gd.affiliatedtrusteetext
,gd.Title
,gd.[RPO Office]
,gd.CurrentProgramOfficer
,gd.PrimaryProgramOfficer
,gd.GrantManager
,gd.TermLength
,ISNULL(convert(varchar,gd.TermStartDate,121),'')TermStartDate
,ISNULL(convert(varchar,gd.TermCurrentEndDate,121),'')TermCurrentEndDate
,gd.granttypetext
,gd.CurrentGrantStatus
,gd.[Core Support Percentage]
,gd.[General Support Percentage]
,gd.[Project Support Percentage]
,ISNULL(convert(varchar,gd.grantapproveddate,121),'')grantapproveddate
,GTM.RPOGrouping as [RPO Grantmaking Team] ,
gd.[secondaryorganizationname],gd.requestIsrenewal
from [dbo].[Fact_GrantDetails] gd
Left Outer Join [dbo].[Dim_OrganizationInfo] ORG ON gd.PrimaryOrganizationKey=ORG.OrganizationInfoKey
left join [PROD_MasterData_DMZ].[dbo].GrantMakingTeamBreakdown GTM ON ltrim(rtrim(gd.[RPO Office]))=ltrim(rtrim(GTM.RefValue)) 
and GTM.refid=7










GO


