/****** Object:  Job [FluxxNmaster_SnapRefresh]    Script Date: 3/11/2020 6:56:53 AM ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'9c6176fb-ee1b-4ea7-8ac5-bc899d7333c9', @delete_unused_schedule=1
GO

/****** Object:  Job [FluxxNmaster_SnapRefresh]    Script Date: 3/11/2020 6:56:53 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 3/11/2020 6:56:53 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FluxxNmaster_SnapRefresh', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'dbadmin', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PROD_Fluxx_Reporting_refresh]    Script Date: 3/11/2020 6:56:54 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PROD_Fluxx_Reporting_refresh', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [master];
go
DECLARE @kill varchar(8000) = '''';  
SELECT @kill = @kill + ''kill '' + CONVERT(varchar(5), session_id) + '';''  
FROM sys.dm_exec_sessions
WHERE database_id  = db_id(''PROD_Fluxx_Reporting_A'')
EXEC(@kill);
go
IF  EXISTS (SELECT name FROM sys.databases WHERE name=''PROD_Fluxx_Reporting_A'')
drop database PROD_Fluxx_Reporting_A
go
use master
go
create database PROD_Fluxx_Reporting_A
on (name=Fluxx_New_FF_Grants_EDW,filename=''E:\Snap Databases\prod_fluxx_reporting_a.snap'')
as snapshot of PROD_Fluxx_Reporting
go

', 
		@database_name=N'master', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PROD_MasterData_refresh]    Script Date: 3/11/2020 6:56:54 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PROD_MasterData_refresh', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [master];
go
DECLARE @kill varchar(8000) = '''';  
SELECT @kill = @kill + ''kill '' + CONVERT(varchar(5), session_id) + '';''  
FROM sys.dm_exec_sessions
WHERE database_id  = db_id(''PROD_MasterData_DMZ'')
EXEC(@kill);
go
IF  EXISTS (SELECT name FROM sys.databases WHERE name=''PROD_MasterData_DMZ'')
drop database PROD_MasterData_DMZ
go
use master
go
create database PROD_MasterData_DMZ
on (name=PROD_MasterData,filename=''E:\Snap Databases\prod_masterdata.snap'')
as snapshot of PROD_MasterData
go', 
		@database_name=N'master', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call DMZ Grant Analytics Job]    Script Date: 3/11/2020 6:56:54 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call DMZ Grant Analytics Job', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=9, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_start_job N''DMZ Grant Analytics Viz''', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


