/****** Object:  View [dbo].[BudgetTracking]    Script Date: 3/11/2020 6:48:43 AM ******/
DROP VIEW [dbo].[BudgetTracking]
GO

/****** Object:  View [dbo].[BudgetTracking]    Script Date: 3/11/2020 6:48:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE view [dbo].[BudgetTracking] 
as 
----select * from [dbo].[BudgetTracking] where  Increase_YN='Yes' and Increase_approval_date is not null

 
		select distinct
		bud.BudgetFiscalYear,bud.BudgetType,bud.Amount as budget_amount,bud.FundingSourceName,bud.LOW,
		bdp.ProgramType as [ProgramType] ,
		bud.FLUXXFundingSourceAllocationID,

		isnull(fpc.[BuildGrouping],ISNULL(Rpc.[BuildGrouping],'Other')) as [Category],fpc.NonBuildGrouping,Rpc.RPOGrouping,
		gradamt.*

		from Fact_BudgetAllocations Bud
		left join BudgetTracking_ProgramType bdp on ltrim(rtrim(bud.FundingSourceName))=ltrim(rtrim(bdp.FundingSourceName))
		and ISNULL(ltrim(rtrim(bud.LOW)),'NULL')=ltrim(rtrim(bdp.LOW))
		left outer  join 
			(
			select  CASE WHEN GIA.FundingSourceID IS NOT NULL THEN GIA.ModificationID
			             WHEN GDM.FundingSourceID IS NOT NULL THEN GDM.ModificationID ELSE NULL END ModificationID
						 ,grad.FundingSourceAllocationID,grad.Amount as actual_amount,grad.Isplanning,grad.[Grantamount CreateDate]
			,grad.GrantAmountYear,grad.GrantID,gd.BuildGrant,gd.TermLength,gd.CurrentGrantStatus,gd.PrimaryOrganizationName, 
			ISNULL(convert(varchar,gd.GrantApprovedDate,121),'') as GrantApprovedDate , 
			gd.GrantTargetAmount,gd.GrantNetAmount,gd.GrantManager,gd.CurrentProgramOfficer,gd.targetapprovalmonth,gd.[RPO Office]
			,SecondaryOrganizationName,IIF(is_increased_amount=1,'Yes','No') Increase_YN,	
			IIF(is_increased_amount=1,FT.Amendmentstatus,NULL)Increase_Status,
			IIF(GIA.FundingSourceID IS NOT NULL,GIA.Approved_at,NULL) Increase_Approval_Date,gd.grantfiscalyear
			 from 	Fact_Grantamountdetails GRAD 
			inner join Fact_GrantDetails gd on gd.GrantID=grad.GrantID
			left join Grant_Increase_ApprovedDate GIA ON GIA.FundingSourceID=GRAD.fluxxgrantamountid
			left join Grant_Decrease_ModificationID GDM ON GDM.FundingSourceID=GRAD.fluxxgrantamountid
			LEFT JOIN Fact_GrantTransactions FT ON GIA.contig_id=FT.Grantid AND FT.Fluxxamendmentid=GIA.Modificationid
		  UNION ALL--Below Query for Pipeline for Incraese
		  
			select  GRAD.id ModificationID,grad.FundingSourceID,grad.PipelineAmount ,''Isplanning,GRAD.Amended_at [Grantamount CreateDate],YEAR(GRAD.updated_at)GrantAmountYear,
			grad.Contig_id,gd.BuildGrant,gd.TermLength,gd.CurrentGrantStatus,gd.PrimaryOrganizationName, 
			ISNULL(convert(varchar,gd.GrantApprovedDate,121),'') as GrantApprovedDate , 
			gd.GrantTargetAmount,gd.GrantNetAmount,gd.GrantManager,gd.CurrentProgramOfficer,gd.targetapprovalmonth,gd.[RPO Office]
			,SecondaryOrganizationName,'Yes' Increase_YN,GRAD.status Increase_Status, Approved_at Increase_Approval_Date,gd.grantfiscalyear
			 from 	dbo.Grant_Increase_Pipeline GRAD 
			inner join dbo.Fact_GrantDetails gd on gd.GrantID=grad.Contig_id
			WHERE GRAD.status<>'declined'
			) gradamt	on gradamt.FundingSourceAllocationID=bud.FLUXXFundingSourceAllocationID
		left outer join (Select [BuildGrouping],NonBuildGrouping,[FluxxId],refvalue From [PROD_MasterData_DMZ].[dbo].[GrantMakingTeamBreakdown]
		Where refid=9)  fpc on ---fpc.[FluxxId]=bud.FLUXXFundingSourceAllocationID
		ltrim(rtrim(fpc.RefValue))=ltrim(rtrim(bud.FundingSourceName))
		left outer join (Select [BuildGrouping],RPOGrouping,RefValue From [PROD_MasterData_DMZ].[dbo].[GrantMakingTeamBreakdown]  
		Where refid=7) Rpc on ltrim(rtrim(Rpc.RefValue))=ltrim(rtrim(gradamt.[RPO Office]))

		--Added on 15/03/2019
		Inner Join (Select distinct ltrim(rtrim(Refdesc)) as Fundings,F.BudgetFiscalYear,F.BudgetType  From Dim_Masterdata M
		inner join Fact_BudgetAllocations F ON ltrim(rtrim(M.Refdesc)) =Ltrim(Rtrim(F.FundingSourceName))
		where refid=9 and 
		Retired=case when  F.BudgetType='Build Budget' and ltrim(rtrim(Refdesc)) in ('Equitable Development','Inclusive Economies','Youth Opportunity and Learning') THEN 1 
		when   ltrim(rtrim(Refdesc))  in ('Equitable Development','Inclusive Economies','Youth Opportunity and Learning')  and F.BudgetType='Regular Budget' and F.BudgetFiscalYear<=2018 THEN 1
		else 0 END ) Funds
		/**
		Above case written as per Suzie request for BudgetTracker view missing 3 funding sources: Equitable Development, Inclusive Economies, and Youth Opportunity and Learning. Even though these are no longer active today, 
		they were active until 2018 so need to be included when user views BUILD totals and/or prior year non-build totals
		**/ 
		ON ltrim(rtrim(bud.FundingSourceName))=ltrim(rtrim(Funds.Fundings)) AND bud.budgetfiscalyear=funds.BudgetFiscalYear and bud.BudgetType=funds.BudgetType
		Inner Join (Select distinct ltrim(rtrim(Refdesc)) as Lineofwork,Retired From Dim_Masterdata where refid=12 and Retired=0) LOWs 
		ON ltrim(rtrim(ISNULL(bud.LOW,'')))=ltrim(rtrim(ISNULL(LOWs.Lineofwork,'')))

		where bud.BudgetFiscalYear >=2010 --and grantid=127418--126627

















GO


