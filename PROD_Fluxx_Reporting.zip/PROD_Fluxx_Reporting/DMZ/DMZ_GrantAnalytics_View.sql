/****** Object:  View [dbo].[GrantAnalytics]    Script Date: 3/11/2020 6:51:57 AM ******/
DROP VIEW [dbo].[GrantAnalytics]
GO

/****** Object:  View [dbo].[GrantAnalytics]    Script Date: 3/11/2020 6:51:57 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  view [dbo].[GrantAnalytics] 
as 
SELECT [AllRequests_Grants].[RPO Office] AS [RPO Office],
  GTM.RPOGrouping as [RPO Grantmaking Team], 
  [AllRequests_Grants].[GrantFiscalYear] AS [GrantFiscalYear],
  [AllRequests_Grants].[GrantID] AS [GrantID],
  [AllRequests_Grants].[Title] AS [GrantTitle],
  [AllRequests_Grants].[PrimaryOrganizationName] AS [PrimaryOrganizationName],
  [AllRequests_Grants].[PrimaryProgramOfficer] AS [PrimaryProgramOfficer],
  [AllRequests_Grants].[CurrentProgramOfficer] AS [CurrentProgramOfficer],
  loc.LocationName,
  loc.LocationType As [Location Type],
  cast(fgc.[TargetLocationPercentage] as decimal(5,2)) as [LocationPercentage], --Added on 5/23/2018

  --Modified on 7/18/2018
  Case when loc.LocationType ='State' or loc.LocationType='Province' or loc.LocationType='Techsmart_State' then loc.LocationName
  else Case When (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy))) from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'State'))='' then
  Case When (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Province'))='' then
  (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Techsmart_State')) else
  (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Province')) end else 
  (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'State')) end end  as [ParentLocationName(State/Province)],
  Case when loc.LocationType ='Country' or loc.LocationType ='Techsmart_Country' then loc.LocationName
  else Case When (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Country'))='' then
  (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Techsmart_Country')) else
  (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Country')) end end as [ParentLocationName(Country)],
  case when loc.LocationType ='City'  then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'City')) end 
  as [ParentLocationName(City)], 
  case when loc.LocationType ='Logical Group'  then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Logical Group')) end 
  as [ParentLocationName(LogicalGroup)], 

  --Added on 7/18/2018
  Case when loc.LocationType ='Continent' or loc.LocationType='Techsmart_Continent' then loc.LocationName
  else Case When (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Continent'))='' then
  (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Techsmart_Continent')) else
  (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Continent')) end 
  end as [ParentLocationName(Continent)],
  Case when loc.LocationType ='Part Of Country' then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Part Of Country')) 
  end as [ParentLocationName(Part Of Country)],
  Case when loc.LocationType ='Part Of Continent' then loc.LocationName
  else (select iif(ltrim(rtrim(Hierarchy))='',NULL,ltrim(rtrim(Hierarchy)))  from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Part Of Continent')) 
  end as [ParentLocationName(Part Of Continent)],

  --Modified on 6/15/2018
  --(Select Case When len(ltrim(rtrim(Hierarchy))) > 0 then 
  --ltrim(rtrim(Hierarchy))+'('+Cast((cast(fgc.[TargetLocationPercentage] as decimal(5,0))) as Varchar(6))+'%)'
  --Else '' End From [dbo].[Fn_Get_Fluxx_LOC_Hierarchy](fgc.TargetLocationKey,LOC.LocationName)) as [Target location],
  (Select Case When len(ltrim(rtrim(Hierarchy))) > 0 then
  ltrim(rtrim(Hierarchy))+'($'+Cast(ISNULL(fgc.Locperamount,0) as Varchar(15))+')'
  Else '' End From [dbo].[Fn_Get_Fluxx_LOC_Hierarchy](fgc.TargetLocationKey,LOC.LocationName)) as [Target locations],

  fgc.Locperamount as Locperamount, 
  GrantNetAmount,
  'State/Province' as ParentLocationType,
  'Country' as ParentLocationType_Country,
  Loc.LocationKey as LocationID,
  CASE WHEN ((loc.LocationName in ('United States','Virgin Islands (US)')) OR 
  ((select ltrim(rtrim(Hierarchy)) from [dbo].[Fn_Get_Fluxx_LOC_Details] (fgc.TargetLocationKey,'Country')) in ('United States','Virgin Islands (US)')))
  then 'US'
  else 'International' end as USIntl,
  ISNULL([AllRequests_Grants].[GrantApprovedDate],'') AS [GrantApprovedDate],
  [AllRequests_Grants].[GrantTypeText] AS [GrantTypeText],
  [AllRequests_Grants].[ApprovalType] AS [ApprovalType],
  ISNULL([AllRequests_Grants].[TermCurrentEndDate],'') AS [TermCurrentEndDate],
  ISNULL([AllRequests_Grants].[Termstartdate],'') AS termstartdate,
  [AllRequests_Grants].[GrantManager] AS [GrantManager],
  [AllRequests_Grants].[CurrentGrantStatus] AS [CurrentGrantStatus],
  GA. [ApproachLevel1], GA. [ApproachLevel2],
  gr.[TargetRace/Ethnicity],
  gs.[Target Subject],GS.SubjLevel1,GS.SubjLevel2,
  GS.SubjLevel3,GS.SubjLevel4,gss.[GrantStrategy Outcomes],
  gss.[GrantStrategy Program],
  gg.[TargetGender],gss.[GrantStrategy LOW],
  [AllRequests_Grants].[Core Support],
  [AllRequests_Grants].[Core Support Percentage],
  [AllRequests_Grants].[General Support],
  [AllRequests_Grants].[General Support Percentage],
  [AllRequests_Grants].[Project Support],
  [AllRequests_Grants].[Project Support Percentage],

  --Added on 5/22/2018
  ltrim(rtrim(Case When  [AllRequests_Grants].[Core Support]=1 then 'Core Support ('+Cast([Core Support Percentage] as Varchar(4))+'%)'
  Else '' End + Case When [AllRequests_Grants].[Core Support]=1 and ([AllRequests_Grants].[General Support]=1 OR
  [AllRequests_Grants].[Project Support]=1) then ' ; ' Else '' End + Case When [AllRequests_Grants].[General Support]=1 then
  'General Support ('+Cast([General Support Percentage] as Varchar(4))+'%)' Else '' End + Case When ([AllRequests_Grants].[General Support]=1 AND
  [AllRequests_Grants].[Project Support]=1) then ' ; ' Else '' End + Case When [AllRequests_Grants].[Project Support]=1 then
  'Project Support ('+Cast([Project Support Percentage] as Varchar(4))+'%)' Else '' End)) as [Support type],

  --Added on 5/3/2018
  ga.Approach,gs.[Subject],gss.[GrantAnalyticsStrategy] AS [LOW/Outcome],

  --Added on 5/9/2018 
  FGD.FundingSourceName,
  FGD.LowName,FGD.Amount as GrantAmount,

  --Added on 5/17/2018
  GPercentage.[FundingSourceLOW],

  --Added on 5/10/2018
  VTW.targetwhoother,VTW.WhoLevel1,VTW.WhoLevel2,VTW.WhoLevel3,VTW.WhoLevel4,VTW.[WhoOther],

  --Modified from ; to # on 5/22/2018
  ltrim(rtrim(VFC.[Custom Codes])) as [Custom Codes],

  --Added on 5/11/2018
  gg.TargetGenderLevel1,gg.TargetGenderLevel2,gg.[Gender],
  gr.TargetRaceLevel1,gr.TargetRaceLevel2,gr.TargetRaceLevel3,gr.[Race]

FROM [dbo].[Fact_Grantdetails] [AllRequests_Grants] With (nolock)
left join GrantAnalytics_TargetLocation fgc With (nolock) on [AllRequests_Grants].GrantID=fgc.GrantID
left join GrantAnalytics_FundingPercentage GPercentage With (nolock) on [AllRequests_Grants].GrantID=GPercentage.GrantID
left join Dim_Locations LOC With (nolock) on LOC.LocationKey=fgc.TargetLocationKey
left join GrantAnalytics_Approach ga With (nolock) on ga.grantid=[AllRequests_Grants].GrantID
left join GrantAnalytics_Race gr With (nolock) on [AllRequests_Grants].grantid=gr.GrantID
left join GrantAnalytics_Subject gs With (nolock) on  [AllRequests_Grants].grantid=gs.grantid 
left join GrantAnalytics_Strategy gss With (nolock) on   [AllRequests_Grants].grantid=gss.grantid
left join GrantAnalytics_Gender gg With (nolock) on [AllRequests_Grants].grantid=gg.grantid
left join [PROD_MasterData_DMZ].[dbo].GrantMakingTeamBreakdown GTM With (nolock) ON ltrim(rtrim([AllRequests_Grants].[RPO Office]))=ltrim(rtrim(GTM.RefValue)) and GTM.refid=7
Left join Fact_Grantamountdetails FGD With (nolock) ON [AllRequests_Grants].GrantID=FGD.GrantID
Left join GrantAnalytics_WhoOther VTW With (nolock) ON [AllRequests_Grants].GrantID=VTW.GrantID
Left join GrantAnalytics_CustomCodes VFC With (nolock) ON [AllRequests_Grants].GrantID=VFC.GrantID
Where   [AllRequests_Grants].[GrantFiscalYear] >= 2006 --Modified Year(getdate()) to 2006 on 5/3/2018
--Marked on 11/26/2018 to get all grant type (Fluxx 2.0)
--and [AllRequests_Grants].GrantTypeText in ('BUILD','GRANT','FAP','PRI') 
and ltrim(rtrim([AllRequests_Grants].currentgrantstatus)) not in ('Delete','Declined','Rejected Projection') -- Added on 5/22/2018










GO


