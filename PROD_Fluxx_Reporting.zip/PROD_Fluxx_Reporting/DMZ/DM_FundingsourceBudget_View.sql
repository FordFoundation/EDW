/****** Object:  View [dbo].[FundingSourceBudget]    Script Date: 3/11/2020 6:50:16 AM ******/
DROP VIEW [dbo].[FundingSourceBudget]
GO

/****** Object:  View [dbo].[FundingSourceBudget]    Script Date: 3/11/2020 6:50:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



create view [dbo].[FundingSourceBudget]
as 

select bud.*,category from [dbo].[FACT_BUDGETALLOCATIONS] bud

left outer join  [PROD_MasterData_DMZ].[dbo].[FundingProgramwithcategory_asof05032018]  fpc on fpc.[FluxxId]=bud.FLUXXFundingSourceAllocationID

where BudgetFiscalYear>=2010


GO


