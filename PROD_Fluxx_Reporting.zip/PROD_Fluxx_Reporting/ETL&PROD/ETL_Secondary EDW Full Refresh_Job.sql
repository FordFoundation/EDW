/****** Object:  Job [Secondary EDW Full Refresh]    Script Date: 11-03-2020 16:05:49 ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'2bc2cf76-0ed3-47a8-9e03-d4029cf658e0', @delete_unused_schedule=1
GO

/****** Object:  Job [Secondary EDW Full Refresh]    Script Date: 11-03-2020 16:05:50 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 11-03-2020 16:05:51 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Secondary EDW Full Refresh', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'dbadmin', 
		@notify_email_operator_name=N'GBSII', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Drop & Truncate EDW Tables]    Script Date: 11-03-2020 16:05:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Drop & Truncate EDW Tables', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/******************These tables are one time load data tables*****************************/
--Truncate table Fact_FAPDetails_GBS
--GO
--Truncate table Fact_ThematicLOWTargets_GBS
--GO
--Truncate table Fact_BudgetThematicFundingLOW_GBS
--GO
--Truncate table Fact_GrantMilestones_GBS
--GO
--Truncate table Fact_OrganizationBudget_GBS
--GO
--Truncate table Fact_GrantTargetSummary_GBS
--GO
--Truncate table Fact_BudgetTransactions_GBS
--GO
--Truncate table Fact_GrantApproaches_GBS
--GO

/*****************************Normal Load****************************/
Truncate table Fact_BudgetTransactions
GO
Truncate table Fact_GrantSummary
GO
Truncate table Fact_GrantCoding
GO
Truncate table Fact_BudgetSummary
GO
Truncate table Fact_OrganizationContactDetails
GO
Truncate table Fact_Documents
GO
Truncate table Fact_OrganizationBankInfo
GO
Truncate table Fact_GrantTransactions
GO
Truncate table Fact_GrantPayments
GO
Truncate table Fact_GrantDetails
GO
Truncate table Fact_Grantamountdetails
GO
Truncate table Fact_BudgetAllocations
GO
Truncate table Fact_GrantReports
GO
Truncate table Fact_GrantBudget
GO
Truncate table Fact_Modification
GO
Truncate table Fact_BoardListDetails
GO
Truncate table Fact_WorkFlowtransactions
GO
Truncate table Fact_GrantProgramNotes
GO
Truncate table Fact_GrantAdditionalFunders
GO
Delete from Dim_GrantTAndCDetails
GO
DBCC CheckIdent(Dim_GrantTAndCDetails,reseed,0)
GO
Delete from Dim_OrganizationInfo
GO
DBCC CheckIdent(Dim_OrganizationInfo,reseed,0)
GO
Delete from Dim_GrantType
GO
DBCC CheckIdent(Dim_GrantType,reseed,0)
GO
Delete from Dim_OfficeUserRole
GO
DBCC CheckIdent(Dim_OfficeUserRole,reseed,0)
GO
Delete from Dim_Locations
GO
DBCC CheckIdent(Dim_Locations,reseed,0)
GO
Delete from Dim_WorkflowEvents
GO
DBCC CheckIdent(Dim_WorkflowEvents,reseed,0)
GO

/***********************************Analytics Master Data Tables************************************/


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Subject]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Subject] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Strategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Strategy] 
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_CustomCodes]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_CustomCodes] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_FundingPercentage]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_FundingPercentage] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_TargetLocation]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_TargetLocation] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GranteeApproach]'') AND type in (N''U''))
DROP TABLE [dbo].[GranteeApproach] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Subjects]'') AND type in (N''U''))
DROP TABLE [dbo].[Subjects] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantStrategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantStrategy] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetOther]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetOther] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetGender]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetGender] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetRaceEthnicity]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetRaceEthnicity] 
GO
', 
		@database_name=N'PROD_Fluxx_Reporting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Fluxx To EDW Dimension Tables Data Load]    Script Date: 11-03-2020 16:05:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Fluxx To EDW Dimension Tables Data Load', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--This table load only one time..
--Exec SP_Fluxx_EDW_Dim_FiscalYear
--GO
Exec SP_Fluxx_EDW_Dim_GrantType
GO
Exec SP_Fluxx_EDW_Dim_GrantTAndCDetails
GO
Exec SP_Fluxx_EDW_Dim_OfficeUserRole
GO
Exec SP_Fluxx_EDW_Dim_Locations
GO
Exec SP_Fluxx_EDW_Dim_OrganizationInfo
GO
Exec SP_Fluxx_EDW_Dim_WorkflowEvents
GO', 
		@database_name=N'PROD_Fluxx_Reporting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update EDW DimensionTables]    Script Date: 11-03-2020 16:05:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update EDW DimensionTables', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF NOT EXISTS (SELECT * FROM Dim_FiscalYear WHERE FiscalYear IS NULL and FiscalMonth IS NULL)
BEGIN
    INSERT INTO Dim_FiscalYear (FiscalYearKey, FiscalYear, FiscalMonth, IsCurrent) 
    (SELECT max(FiscalYearKey)+1 AS ''FiscalCalendarKey'',NULL AS ''FiscalYear'',NULL AS ''FiscalMonth'', 0 AS ''IsCurrent'' from Dim_FiscalYear) 
END
GO

Update Dim_FiscalYear Set IsCurrent=1 Where FiscalYear=Year(Getdate()) and FiscalMonth=Month(Getdate())
GO

IF NOT EXISTS (SELECT * FROM Dim_GrantTAndCDetails  WHERE GrantId IS NULL )
BEGIN
      INSERT INTO Dim_GrantTAndCDetails (GrantId)
      (SELECT NULL AS ''GrantId'' ) 
END
GO

IF NOT EXISTS (SELECT * FROM Dim_OrganizationInfo  WHERE OrganizationId IS NULL )
BEGIN
      INSERT INTO Dim_OrganizationInfo (OrganizationId)
      (SELECT NULL AS ''OrganizationId'' ) 
END
GO

--IF NOT EXISTS (SELECT * FROM Dim_GrantType  WHERE GrantTypeId IS NULL )
--BEGIN
--      INSERT INTO Dim_GrantType (GrantTypeId)
--      (SELECT NULL AS ''GrantTypeId'' ) 
--END
--GO

IF NOT EXISTS (SELECT * FROM Dim_OfficeUserRole  WHERE FLUXXOfficeUserRoleId IS NULL )
BEGIN
      INSERT INTO Dim_OfficeUserRole (FLUXXOfficeUserRoleId)
      (SELECT NULL AS ''OfficeUserRoleId'' ) 
END
GO

IF NOT EXISTS (SELECT * FROM Dim_Locations  WHERE FluxxgeoplaceID IS NULL )
BEGIN
      INSERT INTO Dim_Locations (FluxxgeoplaceID)
      (SELECT NULL AS ''LocationId'' ) 
END
GO', 
		@database_name=N'PROD_Fluxx_Reporting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Master Data EDW Tables]    Script Date: 11-03-2020 16:05:53 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Master Data EDW Tables', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'---Insert Masterdata for ProgHierarchy,Regions, Approach, Gender, Race,Who(other)
Delete from dbo.dim_masterdata where refid in (4,1,3,2,6,7,8,9,10,11,12)
GO

----FundingSource
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
SELECT DISTINCT FSAT.ID FluxxId,''FundingSource'' RefType,9 RefID,name Refdesc,name RefValue,
NULL as ParentFluxxId,NULL Displayorder,
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,TFPT.Retired 
FROM [Fluxx_Staging_Secondary].[dbo].[funding_source_allocations_table] FSAT 
Inner Join [Fluxx_Staging_Secondary].[dbo].[PROGRAMS_TABLE] TFPT ON FSAT.program_id=TFPT.ID
WHERE FSAT.program_id IS NOT NULL
GO

----ProgHirarchy
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
select ID as FluxxId, ''ProgHierarchy'' as RefType,6 as RefID,description as Refdesc,value as RefValue,
dependent_model_attribute_value_id as ParentFluxxId,display_order as Displayorder, 
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,Retired  
from [Fluxx_Staging_Secondary].[dbo].MODEL_ATTRIBUTE_VALUES_TABLE
where model_attribute_id=57645
GO

----Regions
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
select ID as FluxxId, ''Regions'' as RefType,7 as RefID,description as Refdesc,value as RefValue,
dependent_model_attribute_value_id as ParentFluxxId,display_order as Displayorder, 
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,Retired  
from [Fluxx_Staging_Secondary].[dbo].MODEL_ATTRIBUTE_VALUES_TABLE
where model_attribute_id=57272
GO

---Approach
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
select ID as FluxxId, ''TargetApproach'' as RefType,4 as RefID,description as Refdesc,value as RefValue,
dependent_model_attribute_value_id as ParentFluxxId,display_order as Displayorder, 
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,Retired  
from [Fluxx_Staging_Secondary].[dbo].MODEL_ATTRIBUTE_VALUES_TABLE
where model_attribute_id=57759
GO

----Gender
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
select ID as FluxxId, ''TargetGender'' as RefType,1 as RefID,description as Refdesc,value as RefValue,
dependent_model_attribute_value_id as ParentFluxxId,display_order as Displayorder, 
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,Retired  
from [Fluxx_Staging_Secondary].[dbo].MODEL_ATTRIBUTE_VALUES_TABLE
where model_attribute_id=57607
GO

----Race
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
select ID as FluxxId, ''TargetRace'' as RefType,2 as RefID,description as Refdesc,value as RefValue,
dependent_model_attribute_value_id as ParentFluxxId,display_order as Displayorder, 
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,Retired  
from [Fluxx_Staging_Secondary].[dbo].MODEL_ATTRIBUTE_VALUES_TABLE
where model_attribute_id=57611
GO

---Status
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
Select ID as FluxxId,model_type as RefType,8 as RefID,description as Refdes,
name as RefValue,NULL as ParentFluxxId,state_order as Displayorder,
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,0 as Retired  
From [Fluxx_Staging_Secondary].[dbo].MACHINE_STATES_TABLE 
Union All
Select 0 as ID,''Organization'' as RefType,8 as RefID,'''' as Refdes,'''' as RefValue,NULL as ParentFluxxId,
0 as Displayorder,1 as Isactive,0 as Retired
Union All
Select 0 as ID,''GrantRequest'' as RefType,8 as RefID,'''' as Refdes,'''' as RefValue,NULL as ParentFluxxId,
0 as Displayorder,1 as Isactive,0 as Retired
Union All
Select 0 as ID,''RequestReport'' as RefType,8 as RefID,'''' as Refdes,'''' as RefValue,NULL as ParentFluxxId,
0 as Displayorder,1 as Isactive,0 as Retired
GO

--Country Code (IRS)
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
Select ID as FluxxId,''CountryCode'' as RefType,10 as RefID,
name as RefDesc,fips104 as RefValue, NULL as ParentFluxxId,NULL as DisplayOrder,
Case When retired=1 then 0 Else 1 End as IsActive,Retired  from [Fluxx_Staging_Secondary].[dbo].geo_countries
GO

---Insert Masterdata for Program Hirarchey to GrantstrategyMasterdata table
Truncate table dbo.Dim_GrantStrategyMasterData
GO

INSERT INTO [dbo].[Dim_GrantStrategyMasterData]([FluxxProgramID],[FluxxLowID],[FluxxOutcomeID],[Program],[Lows],[Outcome])
SELECT B.ParentFluxxId FluxxProgramID,ISNULL(B.FluxxId,0) FluxxLowID,ISNULL(C.FluxxId,0) FluxxOutcomeID,A.RefDesc Program ,B.RefDesc LOW,C.RefDesc Outcome 
FROM PROD_Fluxx_Reporting..Dim_MasterData A
LEFT JOIN PROD_Fluxx_Reporting..Dim_MasterData B ON A.FluxxId=B.ParentFluxxId
LEFT JOIN PROD_Fluxx_Reporting..Dim_MasterData C On B.FluxxId=C.ParentFluxxId
WHERE ISNULL(A.ParentFluxxId,0)=0 AND A.RefType=''ProgHierarchy'' and ISNULL(B.ParentFluxxId,0)<>0 
Order by A.RefDesc
GO

--Insert new subject records into dim_masterdata
insert into dbo.dim_masterdata (fluxxid,RefType,RefID,Refdesc,RefValue,ParentFluxxId,Displayorder,Isactive,Retired)
SELECT r.FluxxId,r.RefType,r.RefID,r.Refdesc,r.RefValue,r.ParentFluxxId,r.Displayorder,r.Isactive,r.Retired
FROM dbo.dim_masterdata as l
right join 
(select ID as FluxxId, ''TargetSubject'' as RefType,3 as RefID,description as Refdesc,value as RefValue,
dependent_model_attribute_value_id as ParentFluxxId,display_order as Displayorder, 
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,Retired  
from [Fluxx_Staging_Secondary].[dbo].MODEL_ATTRIBUTE_VALUES_TABLE
where model_attribute_id=57760) as r on l.fluxxid = r.FluxxId
where l.fluxxid is null;
GO

--Who(Other)
Insert into dbo.dim_masterdata (FluxxId,RefType,RefId,RefDesc,RefValue,ParentFluxxId,
DisplayOrder,IsActive,Retired)
select ID as FluxxId, ''WhoOther'' as RefType,11 as RefID,description as Refdesc,value as RefValue,
dependent_model_attribute_value_id as ParentFluxxId,display_order as Displayorder, 
Case when (deleted_at IS NULL OR deleted_at=''1900-01-01 00:00:00.0000000'') then 1 else 0 end as Isactive,Retired  
from [Fluxx_Staging_Secondary].[dbo].MODEL_ATTRIBUTE_VALUES_TABLE
where model_attribute_id=57829
GO

---Line of Work
insert into dbo.dim_masterdata (fluxxid,RefType,RefID,Refdesc,RefValue,ParentFluxxId,Displayorder,Isactive,Retired)
Select fluxxid,RefType,RefID,Refdesc,RefValue,ParentFluxxId,Displayorder,Isactive,Retired From
(
	Select ID as fluxxid,''LineofWork'' as RefType,12 as RefID,name Refdesc,name RefValue,
	NULL as ParentFluxxId,NULL Displayorder,Case When retired=1 then 0 Else 1 End as IsActive,Retired
	From Fluxx_Staging_Secondary.[dbo].SUB_PROGRAMS_TABLE Where name IS NOT NULL
	Union
	Select ID as fluxxid,''LineofWork'' as RefType,12 as RefID,name Refdesc,name RefValue,
	NULL as ParentFluxxId,NULL Displayorder,Case When retired=1 then 0 Else 1 End as IsActive,Retired
	From Fluxx_Staging_Secondary.[dbo].INITIATIVES_TABLE Where name IS NOT NULL
	Union
	Select 0 as ID,''LineofWork'' as RefType,12 as RefID,NULL as Refdes,NULL as RefValue,NULL as ParentFluxxId,
	0 as Displayorder,1 as Isactive,0 as Retired
) LOW 
GO

', 
		@database_name=N'PROD_Fluxx_Reporting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Fluxx To EDW Fact Tables Data Load]    Script Date: 11-03-2020 16:05:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Fluxx To EDW Fact Tables Data Load', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Exec SP_Fluxx_EDW_Fact_OrganizationContactDetails
GO
Exec SP_Fluxx_EDW_Fact_Documents
GO
Exec SP_Fluxx_EDW_Fact_OrganizationBankInfo
GO
Exec SP_Fluxx_EDW_Fact_GrantTransactions
GO
Exec SP_Fluxx_EDW_Fact_GrantPayments
GO
Exec SP_Fluxx_EDW_Fact_GrantDetails
GO
Exec SP_Fluxx_EDW_Fact_Grantamountdetails
GO
Exec SP_Fluxx_EDW_Fact_BudgetAllocations
GO
Exec SP_Fluxx_EDW_Fact_GrantSummary
GO
Exec SP_Fluxx_EDW_Fact_BudgetTransactions
GO
Exec SP_Fluxx_EDW_Fact_GrantReports
GO
Exec SP_Fluxx_EDW_Fact_GrantCoding
GO
Exec SP_Fluxx_EDW_Fact_GrantBudget
GO
Exec SP_Fluxx_EDW_Fact_Modification
GO
Exec SP_Fluxx_EDW_Fact_BoardListDetails
GO
Exec SP_Fluxx_EDW_Fact_BudgetSummary
GO
Exec SP_Fluxx_EDW_Fact_WorkFlowtransactions
GO
Exec SP_Fluxx_EDW_Fact_GrantProgramNotes
GO
Exec SP_Fluxx_EDW_Fact_GrantAdditionalFunders
GO', 
		@database_name=N'PROD_Fluxx_Reporting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [EDW Execution Log]    Script Date: 11-03-2020 16:05:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'EDW Execution Log', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Exec usp_DWExecutionLog ''FLUXXPRODSMTP'',''FLUXXPRODSMTP'','''',''ff.atom@fordfoundation.org'','''',''k.kothur@fordfound.org;k.zhao@fordfound.org;m.agrawal@fordfound.org;anagelli@galaxe.com;sbache@galaxe.com;ljose@galaxe.com'',0
GO', 
		@database_name=N'PROD_Fluxx_Reporting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup ETL EDW DB]    Script Date: 11-03-2020 16:05:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup ETL EDW DB', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=5, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'----Backup EDW Staging 
BACKUP DATABASE [PROD_Fluxx_Reporting] TO  DISK = N''\\FFGCP0558\TEMPSQLBCKP\PROD_Fluxx_Reporting.BAK'' WITH COMPRESSION , copy_only, FORMAT, INIT,  NAME = N''PROD_Fluxx_Reporting-Full Database Backup'', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call Restore From EDW]    Script Date: 11-03-2020 16:05:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call Restore From EDW', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'osql -E -S FFGCP0558\INST_EDWPROD -Q "exec msdb.dbo.sp_start_job @job_name = ''Secondary DW Restore from ETL''', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Analytics Master Data]    Script Date: 11-03-2020 16:05:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Analytics Master Data', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-----------------------Drop Sub Tables and Recreation
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Approach]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Approach] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Subject]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Subject] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Strategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Strategy] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_WhoOther]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_WhoOther] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Gender]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Gender] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_Race]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_Race] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_CustomCodes]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_CustomCodes] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_FundingPercentage]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_FundingPercentage] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantAnalytics_TargetLocation]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantAnalytics_TargetLocation] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GranteeApproach]'') AND type in (N''U''))
DROP TABLE [dbo].[GranteeApproach] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Subjects]'') AND type in (N''U''))
DROP TABLE [dbo].[Subjects] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantStrategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantStrategy] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetOther]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetOther] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetGender]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetGender] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetRaceEthnicity]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetRaceEthnicity] 
GO

------------------------Data Moving Temp Tables

SET QUOTED_IDENTIFIER ON

Select * into GranteeApproach From VW_Fluxx_EDW_GranteeApproach_How with (nolock)
GO
Select * into subjects from [dbo].[VW_Fluxx_EDW_GrantSubject_What] with (nolock)
GO
Select * into GrantStrategy From VW_Fluxx_EDW_GrantStrategy_WHY with (nolock)
GO
Select * into TargetOther From VW_Fluxx_EDW_TargetOther_Who with (nolock)
GO
Select * into TargetGender From VW_Fluxx_EDW_TargetGender_Who with (nolock)
GO
Select * into TargetRaceEthnicity From VW_Fluxx_EDW_TargetRace_Ethnicity_Who with (nolock)
GO

------------------------- Viz Sub tables data loading

Select DISTINCT VGH.GrantID,VGH.GrantTypeKey,VGH.GrantTypeText,VGH.ApproachID,VGH.ApproachHierarchy,VGH.ApproachLevel1,
VGH.ApproachLevel2,
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim([ApproachHierarchy]))) > 0,'' ; '','''') + ApproachHierarchy From [dbo].[GranteeApproach] Gapp
Where Gapp.grantid=FD.GrantID
FOR XML PATH('''')
),1,1,''''),2,4000)))) as Nvarchar(4000)) AS Approach into GrantAnalytics_Approach From [dbo].[GranteeApproach] VGH with (nolock)
Inner Join Fact_Grantdetails FD with (nolock) ON VGH.GrantId=FD.GrantId
GO 

Select DISTINCT VEGW.GrantID,VEGW.GrantTypeKey,VEGW.GrantTypeText,VEGW.[Target Subject],VEGW.SubjectID,VEGW.SubjectHierarchy,VEGW.SubjLevel1,
VEGW.SubjLevel2,VEGW.SubjLevel3,VEGW.SubjLevel4,VEGW.SubjLevel5,VEGW.SubjLevel6,VEGW.SubjLevel7,
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim([SubjectHierarchy]))) > 0,'' ; '','''') + SubjectHierarchy 
From subjects GSub with (nolock)
Where GSub.grantid=FD.GrantID
FOR XML PATH('''')
),1,1,''''),2,4000)))) as Nvarchar(4000)) AS [Subject] into GrantAnalytics_Subject From subjects VEGW with (nolock)
Inner Join Fact_Grantdetails FD with (nolock) ON VEGW.GrantId=FD.GrantId
GO

Select DISTINCT VFEG.GrantID,VFEG.GrantTypeKey,VFEG.GrantTypeText,VFEG.[GrantStrategy Program],VFEG.[GrantStrategy LOW],
VFEG.[GrantStrategy Outcomes],VFEG.[GrantStrategy ProgramID],VFEG.[GrantStrategy LOWID],VFEG.[GrantStrategy OutcomesID],
VFEG.GrantStrategy,VFEG.[LOW/Outcome],
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim([GrantStrategy]))) > 0,'' ; '','''') + [GrantStrategy] From [dbo].[GrantStrategy] Gout
Where Gout.grantid=FD.GrantID
FOR XML PATH('''')
),1,1,''''),2,4000)))) as Nvarchar(4000)) AS [GrantAnalyticsStrategy] into GrantAnalytics_Strategy From [dbo].[GrantStrategy] VFEG
Inner Join Fact_Grantdetails FD with (nolock) ON VFEG.GrantId=FD.GrantId
GO 

Select DISTINCT VFEO.GrantID,VFEO.GrantTypeKey,VFEO.GrantTypeText,VFEO.targetwhoother,VFEO.WhoOtherID,
Cast(ltrim(rtrim(VFEO.WhoHierarchy)) as Varchar(511)) as WhoHierarchy,VFEO.WhoLevel1,
VFEO.WhoLevel2,VFEO.WhoLevel3,VFEO.WhoLevel4,VFEO.Targetwhootherpercentage,
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim([WhoHierarchy]))) > 0,'' ; '','''') + [WhoHierarchy] From [dbo].[TargetOther] Wout
Where Wout.grantid=FD.GrantID
FOR XML PATH('''')
),1,1,''''),2,4000)))) as Nvarchar(4000)) AS [WhoOther] into GrantAnalytics_WhoOther From [dbo].[TargetOther] VFEO
Inner Join Fact_Grantdetails FD with (nolock)  ON VFEO.GrantId=FD.GrantId
GO 

Select DISTINCT VFEGW.GrantID,VFEGW.GrantTypeKey,VFEGW.GrantTypeText,VFEGW.TargetGender,VFEGW.GenderID,
Cast(ltrim(rtrim(VFEGW.TargetGenderHierarchy)) as Varchar(511)) as TargetGenderHierarchy,
VFEGW.TargetGenderLevel1,VFEGW.TargetGenderLevel2,VFEGW.Targetgenderpercentage,
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim([TargetGenderHierarchy]))) > 0,'' ; '','''') + [TargetGenderHierarchy] From [dbo].[TargetGender] TG
Where TG.grantid=FD.GrantID
FOR XML PATH('''')
),1,1,''''),2,4000)))) as Nvarchar(4000)) AS [Gender] into GrantAnalytics_Gender From [dbo].[TargetGender] VFEGW
Inner Join Fact_Grantdetails FD  with (nolock) ON VFEGW.GrantId=FD.GrantId
GO 

Select DISTINCT VFETW.GrantID,VFETW.GrantTypeKey,VFETW.GrantTypeText,VFETW.[TargetRace/Ethnicity],VFETW.RaceID,
Cast(ltrim(rtrim(VFETW.TargetRaceHierarchy)) as Varchar(511)) as TargetRaceHierarchy,
VFETW.TargetRaceLevel1,VFETW.TargetRaceLevel2,VFETW.TargetRacepercentage,
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim([TargetRaceHierarchy]))) > 0,'' ; '','''') + [TargetRaceHierarchy] From [dbo].[TargetRaceEthnicity] TR
Where TR.grantid=FD.GrantID
FOR XML PATH('''')
),1,1,''''),2,4000)))) as Nvarchar(4000)) AS [Race],TargetRaceLevel3 into GrantAnalytics_Race From [dbo].[TargetRaceEthnicity] VFETW
Inner Join Fact_Grantdetails FD with (nolock) ON VFETW.GrantId=FD.GrantId
GO 

Select DISTINCT VFEC.GrantID,VFEC.GrantTypeKey,VFEC.GrantTypeText,VFEC.[Custom Codes]  
into GrantAnalytics_CustomCodes From [dbo].[VW_Fluxx_EDW_Customcodes] VFEC with (nolock)
GO

Select Distinct GT.GrantId,
Cast(ltrim(rtrim((select substring(stuff ((Select iif(len(ltrim(rtrim(ISNULL(FG.FundingSourceName,'''')+
   Case When FG.FundingSourceName IS NOT NULL and FG.LowName IS NOT NULL then ''/'' Else '''' End +
   ISNULL(FG.LowName,'''')))) > 0,'' ; '','''') + ltrim(rtrim(ISNULL(FG.FundingSourceName,'''')+
   Case When FG.FundingSourceName IS NOT NULL and FG.LowName IS NOT NULL then ''/'' Else '''' End +
   ISNULL(FG.LowName,'''')+''(''+ISNULL(ltrim(rtrim(Convert(varchar(10),Convert(Decimal(10,0),FG.amount*100.0/GT.GrantNetAmount))+ ''%'')),''0%'')+'')'')) From [dbo].[Fact_Grantamountdetails] FG With (nolock)
   Where FG.grantid=GT.GrantID and FG.Fundingsourcename is not null 
   FOR XML PATH('''')
   ),1,1,''''),2,8000)))) as Varchar(8000)) as [FundingSourceLOW] into GrantAnalytics_FundingPercentage
From Fact_Grantdetails GT With (nolock) 
Where GT.[GrantFiscalYear] >= 2006 
and ltrim(rtrim(GT.currentgrantstatus)) not in (''Delete'',''Declined'',''Rejected Projection'')
and ISNULL(GT.GrantNetAmount,0)<>0
GO

Select distinct FGC.GrantID,FGC.TargetLocationKey,FGC.TargetLocationPercentage,
cast(round((FGC.[TargetLocationPercentage] * GT.GrantNetAmount)/100 ,0) as INT) as Locperamount 
into GrantAnalytics_TargetLocation
From [dbo].[Fact_GrantCoding] FGC with (nolock)
Inner Join Fact_Grantdetails GT  with (nolock) ON FGC.GrantID=GT.GrantID
GO

SET QUOTED_IDENTIFIER OFF

-----------------------Drop Temp Tables
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GranteeApproach]'') AND type in (N''U''))
DROP TABLE [dbo].[GranteeApproach] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[Subjects]'') AND type in (N''U''))
DROP TABLE [dbo].[Subjects] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GrantStrategy]'') AND type in (N''U''))
DROP TABLE [dbo].[GrantStrategy] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetOther]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetOther] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetGender]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetGender] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[TargetRaceEthnicity]'') AND type in (N''U''))
DROP TABLE [dbo].[TargetRaceEthnicity] 
GO
', 
		@database_name=N'PROD_Fluxx_Reporting', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update PROD Master Data]    Script Date: 11-03-2020 16:05:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update PROD Master Data', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate table AmendmentStatus
GO
Insert into [dbo].[AmendmentStatus] (Request#, Amendment#, Requestor, Vendor, Program, Submitted_Offline, 
Submitted_In_WP, Draft_Sent_To_Program, Returned_Legal, Under_Review, Routing_WPApprovals, Sent_Consultant, 
Returned_Consultant, Purchase_Created, Notes, Draft_Sent_To_Consultant, Assigned_Lawyer)
Select Request#, Amendment#, Requestor, Vendor, Program, Submitted_Offline, 
Submitted_In_WP, Draft_Sent_To_Program, Returned_Legal, Under_Review, Routing_WPApprovals, Sent_Consultant, 
Returned_Consultant, Purchase_Created, Notes, Draft_Sent_To_Consultant, Assigned_Lawyer
From [FFGCP0558\INST_EDWPROD].[PROD_MasterData].[dbo].[AmendmentStatus]
GO

Truncate Table ContractStatus
GO
Insert into ContractStatus (Req#, Requestor, Vendor, Program, Submitted_Offline, Submitted_In_WP, Draft_Sent_To_Program, 
Returned_Legal, Under_Review, Routing_WPApprovals, Sent_Consultant, Returned_Consultant, Purchase_Created, Notes, 
Draft_Sent_To_Consultant, Assigned_Lawyer)
Select Req#, Requestor, Vendor, Program, Submitted_Offline, Submitted_In_WP, Draft_Sent_To_Program, 
Returned_Legal, Under_Review, Routing_WPApprovals, Sent_Consultant, Returned_Consultant, Purchase_Created, Notes, 
Draft_Sent_To_Consultant, Assigned_Lawyer 
From [FFGCP0558\INST_EDWPROD].[PROD_MasterData].[dbo].[ContractStatus]
GO

Truncate Table tblPeriodBalances
GO
Insert into tblPeriodBalances (YEAR1, PERIODID, PERDBLNC, ACTNUMBR_3)
Select YEAR1, PERIODID, PERDBLNC, ACTNUMBR_3 
From [FFGCP0558\INST_EDWPROD].[PROD_MasterData].[dbo].[tblPeriodBalances]
GO', 
		@database_name=N'PROD_MasterData', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DMZ-FluxxNmaster_SnapRefresh]    Script Date: 11-03-2020 16:05:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DMZ-FluxxNmaster_SnapRefresh', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [DMZ].msdb.dbo.sp_start_job N''FluxxNmaster_SnapRefresh''', 
		@database_name=N'master', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call Secondary Public Data Job]    Script Date: 11-03-2020 16:05:56 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call Secondary Public Data Job', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_start_job N''Secondary Public Data Full Refresh''', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call EDW Dev Refresh Backup]    Script Date: 11-03-2020 16:05:57 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call EDW Dev Refresh Backup', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_start_job N''Backup_DEVdatarefresh''', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Step1', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190123, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'35f5f381-6796-47b4-bec5-d156d8d60e4e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


