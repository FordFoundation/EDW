/****** Object:  Job [Secondary_GP_ExpenseReport_DataLoading]    Script Date: 11-03-2020 17:10:31 ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'94440a96-7ebc-4dd9-b69d-ee87ba7b2ece', @delete_unused_schedule=1
GO

/****** Object:  Job [Secondary_GP_ExpenseReport_DataLoading]    Script Date: 11-03-2020 17:10:32 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 11-03-2020 17:10:33 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Secondary_GP_ExpenseReport_DataLoading', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'dbadmin', 
		@notify_email_operator_name=N'GBSII', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load ffdescription]    Script Date: 11-03-2020 17:10:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load ffdescription', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPExpensesDescription]'') AND type in (N''U''))
DROP TABLE [dbo].[GPExpensesDescription]
GO

Select * into GPExpensesDescription From [BI2].[Expenses_Description](nolock)  where year([ReceiptDate]) >=2016
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load GP Invoice Summary Data]    Script Date: 11-03-2020 17:10:35 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load GP Invoice Summary Data', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffInvoiceSummary]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffInvoiceSummary]
GO

Select invdetails.PAIV_Document_No as DocumentNumber,
invdetails.PAPROJNUMBER, invdetails.PAIV_Transfer_type as TransferType  into GPffInvoiceSummary from ffsmq0300.Ford.dbo.PA30900 invsummary with (nolock)
inner join ffsmq0300.Ford.dbo.PA30901 invdetails with (nolock) on invsummary.PAIV_Document_No=invdetails.PAIV_Document_No
GO
', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


