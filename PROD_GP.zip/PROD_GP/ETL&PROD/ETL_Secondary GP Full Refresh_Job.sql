/****** Object:  Job [Secondary GP Full Refresh]    Script Date: 11-03-2020 17:09:28 ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'1da3cbbf-d093-4a7e-9af9-1299775bbedf', @delete_unused_schedule=1
GO

/****** Object:  Job [Secondary GP Full Refresh]    Script Date: 11-03-2020 17:09:28 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 11-03-2020 17:09:29 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Secondary GP Full Refresh', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'dbadmin', 
		@notify_email_operator_name=N'GBSII', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Drop GP Tables]    Script Date: 11-03-2020 17:09:31 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Drop GP Tables', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/******************Drop Existing Tables**********************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffInvoiceDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffInvoiceDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffInvoices]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffInvoices]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffOTIINFO]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffOTIINFO]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentDetails]'') AND type in (N''U''))
TRUNCATE TABLE [dbo].[GPffPaymentDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentDetailsWithCostCenter]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPaymentDetailsWithCostCenter]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentDetailsWithRequisitionDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPaymentDetailsWithRequisitionDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPayments]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPayments]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPOInquiry]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPOInquiry]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPurchaseOrderDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPurchaseOrderDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPurchaseOrders]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPurchaseOrders]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitionDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitionDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitions]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitions]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffShipmentReceiptDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffShipmentReceiptDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffShipmentReceipts]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffShipmentReceipts]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPRqdetail]'') AND type in (N''U''))
DROP TABLE [dbo].[GPRqdetail]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffDescriptions]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffDescriptions]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffEmployeeTravel]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffEmployeeTravel]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffEmployeeTravel]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffEmployeeTravel]
GO

/*********************Drop Existing Table - BICCL 212************************************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffInvoiceDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffInvoiceDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentdetailsWithRequisitionDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPaymentdetailsWithRequisitionDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPurchaseOrderDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPurchaseOrderDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitionDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitionDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffShipmentReceiptDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffShipmentReceiptDetailsCalculated]
GO

/********Added on 7/14/2016 LJ********************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffpurchaseorderdetailscalculated20160713]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffpurchaseorderdetailscalculated20160713]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitiondetailscalculated20160713]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitiondetailscalculated20160713]
GO

/****Loading New View for Expense Dashboard 9/11/2014 MA********/

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffManualAdjustments]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffManualAdjustments] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffExpensesRowDefinition]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffExpensesRowDefinition] 
GO

----Loading the Budget Data [MA2/26/2015] Currently commented as it is once a year]

--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[dbo].[GPAccountBudget]'') AND type in (N''U''))
--DROP TABLE .[dbo].[GPAccountBudget]
--GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffrcvheader]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffrcvheader] 
GO

-----Added on 01/27/2017 for Masters
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPProjectMaster]'') AND type in (N''U''))
DROP TABLE [dbo].[GPProjectMaster]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPVendorMaster]'') AND type in (N''U''))
DROP TABLE [dbo].[GPVendorMaster]
GO

--Added on 2/16/2017
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffpurchaseorderdetailscalculated20170214]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffpurchaseorderdetailscalculated20170214]
GO

--Added on 03/09/2017
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPExpensesDescription]'') AND type in (N''U''))
DROP TABLE [dbo].[GPExpensesDescription]
GO

--Added on 05/08/2018
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitionDetailsCalculated20180802]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitionDetailsCalculated20180802] 
GO

--Added on 26/02/2019
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffReceiptsDraft20170201]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffReceiptsDraft20170201] 
GO

--Added on 05/03/2019
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPVendorOFACView]'') AND type in (N''U''))
DROP TABLE [dbo].[GPVendorOFACView]
GO

--Added on17/03/2019
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPRQDetailLog]'') AND type in (N''U''))
DROP TABLE [dbo].[GPRQDetailLog]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPWCLogType]'') AND type in (N''U''))
DROP TABLE [dbo].[GPWCLogType]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPWCLanguageResourceD]'') AND type in (N''U''))
DROP TABLE [dbo].[GPWCLanguageResourceD]
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Expense Report Data Load]    Script Date: 11-03-2020 17:09:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Expense Report Data Load', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate table [ExpenseReport_Data]
GO

DECLARE @StartDate DATE
----- MA 1/8/2018 Changing the date to start from 2016 onwards to increase performance.
----SELECT @StartDate=''1/1/2013''
SELECT @StartDate=''1/1/2016''

insert into [ExpenseReport_Data] WITH (TABLOCK) (JournalEntry, SequenceNumber, RecurringTransactionSequence, LineOrder, AccountNumber, 
AccountDescription, FacilityID, Facility, CostCentreID, CostCentre, ObjectID, ObjectName, 
SourceDocumentID, SourceDocumentDescription, Series, Reference, TransactionDescription, 
TransactionDate, OriginatingSource, OriginatingControlNumber, BatchNumber, OriginatingMasterID, 
OriginatingMasterName, OriginatingDocumentNumber, CurrencyID, POType, VendorID, VendorName, 
VendorDocumentNumber, ReceiptDate, SubledgerDocumentReference, ShowDetailsFlag, ItemNumber, 
ItemDescription, VendorItemNumber, VendorItemDescription, ExtendedCost, GLAmount, CreditAmount, 
DebitAmount, OriginatingGLAmount, OriginatingCreditAmount, OriginatingDebitAmount)
Select * from (
SELECT 
	  GL.JRNENTRY AS JournalEntry,
	  SEQNUMBR AS SequenceNumber,
	  RCTRXSEQ AS RecurringTransactionSequence,
	  1 AS LineOrder,
	  LTRIM(RTRIM(ACTNUMST)) AS AccountNumber,
	  LTRIM(RTRIM(ACT.ACTDESCR)) AS AccountDescription,
	  LTRIM(RTRIM(AC.ACTNUMBR_1)) AS FacilityID,
	  FAC.DSCRIPTN AS Facility,
	  LTRIM(RTRIM(AC.ACTNUMBR_2)) AS CostCentreID,
	  CST.DSCRIPTN AS CostCentre,
	  LTRIM(RTRIM(AC.ACTNUMBR_3)) AS ObjectID,
	  OBJ.DSCRIPTN AS ObjectName,
      LTRIM(RTRIM(GL.SOURCDOC)) AS SourceDocumentID,
      SRC.SDOCDSCR AS SourceDocumentDescription,
      CASE SERIES WHEN 2 THEN ''Financial'' WHEN 3 THEN ''Sales'' WHEN 4 THEN ''Purchasing'' WHEN 7 THEN ''Project'' ELSE '''' END AS Series,
      GL.REFRENCE AS Reference,
      GL.DSCRIPTN AS TransactionDescription,
      GL.TRXDATE AS TransactionDate,
      ORGNTSRC AS OriginatingSource,
      GL.ORCTRNUM AS OriginatingControlNumber,
      CASE 
      WHEN GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'') THEN REC.BACHNUMB
      WHEN GL.SOURCDOC LIKE ''PM%'' THEN isnull(PMOpen.BACHNUMB,isnull(PMHistory.BACHNUMB,''''))
      WHEN GL.SOURCDOC IN (''CMDEP'',''CMTRX'') THEN ''''
      ELSE ''''
      END AS BatchNumber,
      ORMSTRID AS OriginatingMasterID,
      CASE WHEN ORMSTRNM=''GHEEROW STEPHEN'' THEN (CASE WHEN ISNULL(RECDTL.VNDITDSC,'''')='''' THEN ORMSTRNM ELSE RECDTL.VNDITDSC END)
      ELSE ORMSTRNM END AS OriginatingMasterName,
      ORDOCNUM AS OriginatingDocumentNumber,
      GL.CURNCYID AS CurrencyID,
 	  CASE REC.POPTYPE 
		WHEN 1 THEN ''Shipment'' 
		WHEN 2 THEN ''Invoice''
		WHEN 3 THEN ''Shipment/Invoice'' 
		WHEN 4 THEN ''Return'' 
		WHEN 5 THEN ''Return w/Credit'' END AS POType,
		REC.VENDORID AS VendorID,
		CASE WHEN REC.VENDNAME=''GHEEROW STEPHEN'' 
		THEN (CASE WHEN ISNULL(RECDTL.VNDITDSC,'''')='''' THEN REC.VENDNAME ELSE RECDTL.VNDITDSC END)
        ELSE REC.VENDNAME END AS VendorName,
		REC.VNDDOCNM AS VendorDocumentNumber,
		REC.receiptdate AS ReceiptDate,
		REC.REFRENCE AS SubledgerDocumentReference,
	  CASE WHEN (GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'') OR (GL.SOURCDOC IN (''ALTRN'') AND (DEF_REC.ITEMNMBR IS NOT NULL))) 
	  THEN 1 ELSE 0 END AS ShowDetailsFlag,
	  CASE 
      WHEN (GL.SOURCDOC IN (''RECVG'',''PORET'')) THEN ISNULL(RECDTL.ITEMNMBR,'''')
      WHEN (GL.SOURCDOC IN (''POIVC'')) THEN ISNULL(INVDTL.ITEMNMBR,'''')
      WHEN (GL.SOURCDOC IN (''ALTRN'') AND (DEF_REC.ITEMNMBR IS NOT NULL)) THEN ISNULL(DEF_REC.ITEMNMBR,'''')
      WHEN GL.SOURCDOC LIKE ''PM%'' THEN isnull(PMOpen.DOCNUMBR,isnull(PMHistory.DOCNUMBR,''''))
      WHEN GL.SOURCDOC IN (''CMDEP'') THEN CMDep.CHEKBKID
      WHEN GL.SOURCDOC IN (''CMTRX'') THEN ISNULL(CMTrx.CHEKBKID,CMRec.CHEKBKID)
      ELSE ''''
      END AS ItemNumber,
      CASE 
      WHEN GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'') THEN 
      (CASE WHEN CHARINDEX(''Desc'',ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))>0 THEN
      CASE WHEN SUBSTRING(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))),CHARINDEX(''Desc'',LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))+7,LEN(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))-(CHARINDEX(''Desc'',LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))+
       (CASE WHEN RIGHT(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))),1)=CHAR(39) THEN 7 ELSE 6 END)))='''' THEN
       SUBSTRING(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))),CHARINDEX(''EC:'',LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))+5,LEN(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))-15)      
       ELSE 
       SUBSTRING(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))),CHARINDEX(''Desc'',LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))+7,LEN(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))-(CHARINDEX(''Desc'',LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))))+
       (CASE WHEN RIGHT(LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC))),1)=CHAR(39) THEN 7 ELSE 6 END)))
       END
       ELSE
        LTRIM(RTRIM(ISNULL(RECDTL.ITEMDESC,INVDTL.ITEMDESC)))
       END)
      WHEN (GL.SOURCDOC IN (''ALTRN'') AND (DEF_REC.ITEMNMBR IS NOT NULL)) THEN ISNULL(DEF_REC.ITEMDESC,'''')
      WHEN GL.SOURCDOC LIKE ''PM%'' THEN ''''
      WHEN GL.SOURCDOC IN (''CMDEP'') THEN CMDep.paidtorcvdfrom
      WHEN GL.SOURCDOC IN (''CMTRX'') THEN ISNULL(CMTrx.paidtorcvdfrom,CMRec.RcvdFrom)
      ELSE ''''
      END AS ItemDescription,
      RECDTL.VNDITNUM AS VendorItemNumber,
      RECDTL.VNDITDSC AS VendorItemDescription,
      CASE WHEN GL.SOURCDOC IN (''RECVG'') THEN ISNULL(RECDTL.EXTDCOST,0)
      WHEN GL.SOURCDOC IN (''PORET'') THEN -ISNULL(RECDTL.EXTDCOST,0)
      WHEN GL.SOURCDOC IN (''POIVC'') THEN ISNULL(INVDTL.PPVTotal,0)
      WHEN GL.SOURCDOC IN (''ALTRN'') THEN (CASE WHEN ISNULL(DEF_REC_SUM.EXTDCOST,0)!=0 THEN (ISNULL(DEF_REC.EXTDCOST,0)/ISNULL(DEF_REC_SUM.EXTDCOST,0)) ELSE 0 END) * (DEBITAMT-CRDTAMNT)
      ELSE 0 END AS ExtendedCost,
      DEBITAMT-CRDTAMNT AS GLAmount,
      CRDTAMNT AS CreditAmount,
      DEBITAMT AS DebitAmount,
      ORDBTAMT-ORCRDAMT AS OriginatingGLAmount,
      ORCRDAMT AS OriginatingCreditAmount,
      ORDBTAMT AS OriginatingDebitAmount
 FROM 
 (SELECT ORDOCNUM,GL.ACTINDX,JRNENTRY,
   ROW_NUMBER() OVER (PARTITION BY JRNENTRY,ORDOCNUM,SOURCDOC ORDER BY GL.ACTINDX ASC) AS SEQNUMBR,
	MAX(REFRENCE) AS REFRENCE,MAX(SERIES) AS SERIES,
	MAX(DSCRIPTN) AS DSCRIPTN,MAX(TRXDATE) AS TRXDATE,MAX(RCTRXSEQ) AS RCTRXSEQ,
	MAX(ORGNTSRC) AS ORGNTSRC,MAX(ORCTRNUM) AS ORCTRNUM,
	MAX(ORMSTRID) AS ORMSTRID,MAX(ORMSTRNM) AS ORMSTRNM,
	MAX(CURNCYID) AS CURNCYID,SOURCDOC AS SOURCDOC,
    SUM(CRDTAMNT) AS CRDTAMNT,SUM(DEBITAMT) AS DEBITAMT, 
    SUM(ORCRDAMT) AS ORCRDAMT,SUM(ORDBTAMT) AS ORDBTAMT
 FROM [FFSMQ0300].[FORD].[DBO].GL20000 GL (NOLOCK)
 JOIN [FFSMQ0300].[FORD].[DBO].GL00100 AC ON GL.ACTINDX=AC.ACTINDX
 WHERE AC.ACTNUMBR_3 LIKE ''6%'' --Expense Accounts only
 AND AC.ACTNUMBR_3 NOT IN (''68000'',''66800'',''60100'') --Excluding Depreciation Accounts
 AND GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'')
 GROUP BY ORDOCNUM,GL.ACTINDX,SOURCDOC,JRNENTRY
 UNION ALL 
 SELECT ORDOCNUM,GL.ACTINDX,JRNENTRY AS JRNENTRY,
	ROW_NUMBER() OVER (PARTITION BY JRNENTRY,TRXDATE,RCTRXSEQ ORDER BY SEQNUMBR ASC) AS SEQNUMBR,
	REFRENCE AS REFRENCE,SERIES AS SERIES,
	DSCRIPTN AS DSCRIPTN,TRXDATE AS TRXDATE,RCTRXSEQ,
	ORGNTSRC AS ORGNTSRC,ORCTRNUM AS ORCTRNUM,
	ORMSTRID AS ORMSTRID,ORMSTRNM AS ORMSTRNM,
	CURNCYID AS CURNCYID,SOURCDOC AS SOURCDOC,
    CRDTAMNT AS CRDTAMNT,DEBITAMT AS DEBITAMT, 
    ORCRDAMT AS ORCRDAMT,ORDBTAMT AS ORDBTAMT
 FROM [FFSMQ0300].[FORD].[DBO].GL20000 GL (NOLOCK)
 JOIN [FFSMQ0300].[FORD].[DBO].GL00100 AC ON GL.ACTINDX=AC.ACTINDX
 WHERE AC.ACTNUMBR_3 LIKE ''6%'' --Expense Accounts only
 AND AC.ACTNUMBR_3 NOT IN (''68000'',''66800'',''60100'') --Excluding Depreciation Accounts
 AND GL.SOURCDOC NOT IN (''RECVG'',''POIVC'',''PORET'')
 UNION ALL 
 SELECT ORDOCNUM,GL.ACTINDX,JRNENTRY,
    ROW_NUMBER() OVER (PARTITION BY JRNENTRY,ORDOCNUM,SOURCDOC ORDER BY GL.ACTINDX ASC) AS SEQNUMBR,
	MAX(REFRENCE) AS REFRENCE,MAX(SERIES) AS SERIES,
	MAX(DSCRIPTN) AS DSCRIPTN,MAX(TRXDATE) AS TRXDATE,MAX(RCTRXSEQ) AS RCTRXSEQ,
	MAX(ORGNTSRC) AS ORGNTSRC,MAX(ORCTRNUM) AS ORCTRNUM,
	MAX(ORMSTRID) AS ORMSTRID,MAX(ORMSTRNM) AS ORMSTRNM,
	MAX(CURNCYID) AS CURNCYID,SOURCDOC AS SOURCDOC,
    SUM(CRDTAMNT) AS CRDTAMNT,SUM(DEBITAMT) AS DEBITAMT, 
    SUM(ORCRDAMT) AS ORCRDAMT,SUM(ORDBTAMT) AS ORDBTAMT
 FROM [FFSMQ0300].[FORD].[DBO].GL30000 GL (NOLOCK)
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL00100 AC ON GL.ACTINDX=AC.ACTINDX
 WHERE AC.ACTNUMBR_3 LIKE ''6%'' --Expense Accounts only
 AND AC.ACTNUMBR_3 NOT IN (''68000'',''66800'',''60100'') --Excluding Depreciation Accounts
 AND GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'')
 GROUP BY ORDOCNUM,GL.ACTINDX,SOURCDOC,JRNENTRY
 UNION ALL
  SELECT ORDOCNUM,GL.ACTINDX,JRNENTRY AS JRNENTRY,
  	ROW_NUMBER() OVER (PARTITION BY JRNENTRY,TRXDATE,RCTRXSEQ ORDER BY SEQNUMBR ASC) AS SEQNUMBR,
  	REFRENCE AS REFRENCE,SERIES AS SERIES,
	DSCRIPTN AS DSCRIPTN,TRXDATE AS TRXDATE,RCTRXSEQ,
	ORGNTSRC AS ORGNTSRC,ORCTRNUM AS ORCTRNUM,
	ORMSTRID AS ORMSTRID,ORMSTRNM AS ORMSTRNM,
	CURNCYID AS CURNCYID,SOURCDOC AS SOURCDOC,
    CRDTAMNT AS CRDTAMNT,DEBITAMT AS DEBITAMT, 
    ORCRDAMT AS ORCRDAMT,ORDBTAMT AS ORDBTAMT
 FROM [FFSMQ0300].[FORD].[DBO].GL30000 GL (NOLOCK)
 JOIN [FFSMQ0300].[FORD].[DBO].GL00100 AC ON GL.ACTINDX=AC.ACTINDX
 WHERE AC.ACTNUMBR_3 LIKE ''6%'' --Expense Accounts only
 AND AC.ACTNUMBR_3 NOT IN (''68000'',''66800'',''60100'') --Excluding Depreciation Accounts
 AND GL.SOURCDOC NOT IN (''RECVG'',''POIVC'',''PORET'')) GL
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL00105 AC (NOLOCK) ON GL.ACTINDX=AC.ACTINDX
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL00100 ACT (NOLOCK) ON GL.ACTINDX=ACT.ACTINDX
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL40200 FAC ON FAC.SGMTNUMB=1 AND SGMNTID=AC.ACTNUMBR_1 
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL40200 CST ON CST.SGMTNUMB=2 AND CST.SGMNTID=AC.ACTNUMBR_2
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL40200 OBJ ON OBJ.SGMTNUMB=3 AND OBJ.SGMNTID=AC.ACTNUMBR_3
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].SY00900 SRC (NOLOCK) ON GL.SOURCDOC=SRC.SOURCDOC
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].POP30300 REC (NOLOCK) ON GL.ORCTRNUM=REC.POPRCTNM AND GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'')
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].POP30310 RECDTL (NOLOCK) ON GL.ORCTRNUM=RECDTL.POPRCTNM AND GL.ACTINDX=RECDTL.INVINDX AND GL.SOURCDOC IN (''RECVG'',''PORET'')
 LEFT JOIN (SELECT (CASE WHEN INVDTL.UNITCOST=0 THEN INVDTL.EXTDCOST-RECDTL.EXTDCOST ELSE (INVDTL.UNITCOST-RECDTL.UNITCOST)*QTYINVCD END) AS PPVTotal,INVDTL.* FROM [FFSMQ0300].[FORD].[DBO].POP30310 INVDTL (NOLOCK) 
			JOIN [FFSMQ0300].[FORD].[DBO].POP10600 INV (NOLOCK) ON INV.POPIVCNO=INVDTL.POPRCTNM AND INV.IVCLINNO=INVDTL.RCPTLNNM 
			JOIN [FFSMQ0300].[FORD].[DBO].POP30310 RECDTL (NOLOCK) ON INV.POPRCTNM=RECDTL.POPRCTNM AND INV.RCPTLNNM=RECDTL.RCPTLNNM
			WHERE (CASE WHEN INVDTL.UNITCOST=0 THEN ABS(INVDTL.EXTDCOST-RECDTL.EXTDCOST) ELSE ABS((INVDTL.UNITCOST-RECDTL.UNITCOST)*QTYINVCD) END)>0) INVDTL ON GL.ORCTRNUM=INVDTL.POPRCTNM AND GL.ACTINDX=INVDTL.INVINDX AND GL.SOURCDOC IN (''POIVC'')
 LEFT JOIN (SELECT VCHRNMBR,MAX(PTDUSRID) AS PTDUSRID,MAX(MDFUSRID) AS MDFUSRID,MAX(MODIFDT) AS MODIFDT,
 MAX(BACHNUMB) AS BACHNUMB, MAX(DOCNUMBR) AS DOCNUMBR FROM [FFSMQ0300].[FORD].[DBO].PM20000 PM2 (NOLOCK) GROUP BY VCHRNMBR) PMOpen ON GL.ORCTRNUM=PMOpen.VCHRNMBR AND GL.SOURCDOC LIKE ''PM%'' 
 LEFT JOIN  (SELECT VCHRNMBR,MAX(PTDUSRID) AS PTDUSRID,MAX(MDFUSRID) AS MDFUSRID,MAX(MODIFDT) AS MODIFDT,
 MAX(BACHNUMB) AS BACHNUMB, MAX(DOCNUMBR) AS DOCNUMBR FROM [FFSMQ0300].[FORD].[DBO].PM30200 PM3 (NOLOCK) GROUP BY VCHRNMBR) PMHistory ON GL.ORCTRNUM=PMHistory.VCHRNMBR AND GL.SOURCDOC LIKE ''PM%'' 
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].CM20200 CMDep (NOLOCK) ON GL.ORCTRNUM=CONVERT(VARCHAR,CONVERT(INT,CMDep.CMRECNUM)) AND GL.SOURCDOC IN (''CMDEP'')
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].CM20200 CMTrx (NOLOCK) ON GL.ORCTRNUM=CONVERT(VARCHAR,CMTrx.CMRECNUM) AND GL.SOURCDOC IN (''CMTRX'')
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].CM20300 CMRec (NOLOCK) ON GL.ORCTRNUM=CONVERT(VARCHAR,CMRec.CMRECNUM) AND GL.SOURCDOC=''CMTRX''
 LEFT JOIN (SELECT PP_Document_Number,OFFACCT,ACTINDX FROM [FFSMQ0300].[FORD].[DBO].PP100100 PP1 (NOLOCK) WHERE PP_Module=7 GROUP BY PP_Document_Number,OFFACCT,ACTINDX) DEF 
	ON GL.ORCTRNUM=DEF.PP_Document_Number AND GL.ACTINDX=DEF.ACTINDX AND GL.SOURCDOC IN (''ALTRN'')
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].POP30310 DEF_REC (NOLOCK) ON GL.ORCTRNUM=DEF_REC.POPRCTNM AND DEF.OFFACCT=DEF_REC.INVINDX AND GL.SOURCDOC IN (''ALTRN'') 
 LEFT JOIN (SELECT POPRCTNM,INVINDX,SUM(EXTDCOST) AS EXTDCOST FROM [FFSMQ0300].[FORD].[DBO].POP30310 GROUP BY POPRCTNM,INVINDX) DEF_REC_SUM ON GL.ORCTRNUM=DEF_REC_SUM.POPRCTNM AND DEF.OFFACCT=DEF_REC_SUM.INVINDX AND GL.SOURCDOC IN (''ALTRN'')  
WHERE
 GL.TRXDATE>=@StartDate ---AND GL.TRXDATE<=@EndDate - Marked for Expense Job 
UNION ALL
-- Unreconciled Line Details
SELECT JRNENTRY AS JournalEntry,
	  SEQNUMBR AS SequenceNumber,
	  RCTRXSEQ AS RecurringTransactionSequence,
	  2 AS LineOrder,
	  LTRIM(RTRIM(ACTNUMST)) AS AccountNumber,
	  LTRIM(RTRIM(ACT.ACTDESCR)) AS AccountDescription,
	  LTRIM(RTRIM(AC.ACTNUMBR_1)) AS FacilityID,
	  FAC.DSCRIPTN AS Facility,
	  LTRIM(RTRIM(AC.ACTNUMBR_2)) AS CostCentreID,
	  CST.DSCRIPTN AS CostCentre,
	  LTRIM(RTRIM(AC.ACTNUMBR_3)) AS ObjectID,
	  OBJ.DSCRIPTN AS ObjectName,
      LTRIM(RTRIM(GL.SOURCDOC)) AS SourceDocumentID,
      SRC.SDOCDSCR AS SourceDocumentDescription,
      CASE SERIES WHEN 2 THEN ''Financial'' WHEN 3 THEN ''Sales'' WHEN 4 THEN ''Purchasing'' WHEN 7 THEN ''Project'' ELSE '''' END AS Series,
      GL.REFRENCE AS Reference,
      GL.DSCRIPTN AS TransactionDescription,
      GL.TRXDATE AS TransactionDate,
      ORGNTSRC AS OriginatingSource,
      GL.ORCTRNUM AS OriginatingControlNumber,
      REC.BACHNUMB AS BatchNumber,
      ORMSTRID AS OriginatingMasterID,
      ORMSTRNM AS OriginatingMasterName,
      ORDOCNUM AS OriginatingDocumentNumber,
      GL.CURNCYID AS CurrencyID,
 	  CASE REC.POPTYPE 
		WHEN 1 THEN ''Shipment'' 
		WHEN 2 THEN ''Invoice''
		WHEN 3 THEN ''Shipment/Invoice'' 
		WHEN 4 THEN ''Return'' 
		WHEN 5 THEN ''Return w/Credit'' END AS POType,
		REC.VENDORID AS VendorID,
		ORMSTRNM AS VendorName,
		REC.VNDDOCNM AS VendorDocumentNumber,
		REC.receiptdate AS ReceiptDate,
		REC.REFRENCE AS SubledgerDocumentReference,
	  CASE WHEN GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'') THEN 1 ELSE 0 END AS ShowDetailsFlag,
	  ''Unreconciled Amount'' AS ItemNumber,
      '''' AS ItemDescription,
      '''' AS VendorItemNumber,
      '''' AS VendorItemDescription,
      ISNULL(GLAMOUNT,0)-ISNULL(EXTDCOST,0) AS ExtendedCost,
      DEBITAMT-CRDTAMNT AS GLAmount,
      CRDTAMNT AS CreditAmount,
      DEBITAMT AS DebitAmount,
      ORDBTAMT-ORCRDAMT AS OriginatingGLAmount,
      ORCRDAMT AS OriginatingCreditAmount,
      ORDBTAMT AS OriginatingDebitAmount
FROM
(SELECT ORDOCNUM,GL.ACTINDX,JRNENTRY,
   ROW_NUMBER() OVER (PARTITION BY JRNENTRY,ORDOCNUM,SOURCDOC ORDER BY GL.ACTINDX ASC) AS SEQNUMBR,
	MAX(REFRENCE) AS REFRENCE,MAX(SERIES) AS SERIES,
	MAX(DSCRIPTN) AS DSCRIPTN,MAX(TRXDATE) AS TRXDATE,MAX(RCTRXSEQ) AS RCTRXSEQ,
	MAX(ORGNTSRC) AS ORGNTSRC,MAX(ORCTRNUM) AS ORCTRNUM,
	MAX(ORMSTRID) AS ORMSTRID,MAX(ORMSTRNM) AS ORMSTRNM,
	MAX(CURNCYID) AS CURNCYID,SOURCDOC AS SOURCDOC,
    SUM(CRDTAMNT) AS CRDTAMNT,SUM(DEBITAMT) AS DEBITAMT, 
    SUM(ORCRDAMT) AS ORCRDAMT,SUM(ORDBTAMT) AS ORDBTAMT,
	SUM(DEBITAMT)-SUM(CRDTAMNT) AS GLAMOUNT
 FROM [FFSMQ0300].[FORD].[DBO].GL20000 GL (NOLOCK)
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL00100 AC ON GL.ACTINDX=AC.ACTINDX
 WHERE AC.ACTNUMBR_3 LIKE ''6%'' --Expense Accounts only
 AND AC.ACTNUMBR_3 NOT IN (''68000'',''66800'',''60100'') --Excluding Depreciation Accounts
 AND GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'')
 AND GL.TRXDATE>=@StartDate ---AND GL.TRXDATE<=@EndDate - Marked for Expense Job
 GROUP BY ORDOCNUM,GL.ACTINDX,SOURCDOC,JRNENTRY
 UNION ALL
 SELECT ORDOCNUM,GL.ACTINDX,JRNENTRY,
    ROW_NUMBER() OVER (PARTITION BY JRNENTRY,ORDOCNUM,SOURCDOC ORDER BY GL.ACTINDX ASC) AS SEQNUMBR,
	MAX(REFRENCE) AS REFRENCE,MAX(SERIES) AS SERIES,
	MAX(DSCRIPTN) AS DSCRIPTN,MAX(TRXDATE) AS TRXDATE,MAX(RCTRXSEQ) AS RCTRXSEQ,
	MAX(ORGNTSRC) AS ORGNTSRC,MAX(ORCTRNUM) AS ORCTRNUM,
	MAX(ORMSTRID) AS ORMSTRID,MAX(ORMSTRNM) AS ORMSTRNM,
	MAX(CURNCYID) AS CURNCYID,SOURCDOC AS SOURCDOC,
    SUM(CRDTAMNT) AS CRDTAMNT,SUM(DEBITAMT) AS DEBITAMT, 
    SUM(ORCRDAMT) AS ORCRDAMT,SUM(ORDBTAMT) AS ORDBTAMT,
	SUM(DEBITAMT)-SUM(CRDTAMNT) AS GLAMOUNT 
 FROM [FFSMQ0300].[FORD].[DBO].GL30000 GL (NOLOCK)
 LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL00100 AC ON GL.ACTINDX=AC.ACTINDX
 WHERE AC.ACTNUMBR_3 LIKE ''6%'' --Expense Accounts only
 AND AC.ACTNUMBR_3 NOT IN (''68000'',''66800'',''60100'') --Excluding Depreciation Accounts
 AND GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'')
 AND GL.TRXDATE>=@StartDate ---AND GL.TRXDATE<=@EndDate - Marked for Expense Job
 GROUP BY ORDOCNUM,GL.ACTINDX,SOURCDOC,JRNENTRY
 ) GL
LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL00105 AC (NOLOCK) ON GL.ACTINDX=AC.ACTINDX
LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL00100 ACT (NOLOCK) ON GL.ACTINDX=ACT.ACTINDX
LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL40200 FAC ON FAC.SGMTNUMB=1 AND SGMNTID=AC.ACTNUMBR_1 
LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL40200 CST ON CST.SGMTNUMB=2 AND CST.SGMNTID=AC.ACTNUMBR_2
LEFT JOIN [FFSMQ0300].[FORD].[DBO].GL40200 OBJ ON OBJ.SGMTNUMB=3 AND OBJ.SGMNTID=AC.ACTNUMBR_3
LEFT JOIN [FFSMQ0300].[FORD].[DBO].SY00900 SRC (NOLOCK) ON GL.SOURCDOC=SRC.SOURCDOC
LEFT JOIN [FFSMQ0300].[FORD].[DBO].POP30300 REC (NOLOCK) ON GL.ORCTRNUM=REC.POPRCTNM AND GL.SOURCDOC IN (''RECVG'',''POIVC'',''PORET'')
LEFT JOIN 
(
SELECT DTL.POPRCTNM,INVINDX,CASE WHEN POPTYPE IN (1,3) THEN ''RECVG'' ELSE ''PORET'' END AS SOURCDOC,
	CASE WHEN POPTYPE IN (1,3) THEN  SUM(EXTDCOST) ELSE -SUM(EXTDCOST) END AS EXTDCOST 
	FROM [FFSMQ0300].[FORD].[DBO].POP30310 DTL (NOLOCK) JOIN [FFSMQ0300].[FORD].[DBO].POP30300 HDR (NOLOCK) ON HDR.POPRCTNM=DTL.POPRCTNM 
	WHERE POPTYPE IN (1,3,4,5) GROUP BY DTL.POPRCTNM,POPTYPE,DTL.INVINDX
UNION ALL
SELECT INVDTL.POPRCTNM,INVDTL.INVINDX,''POIVC'' AS SOURCDOC,SUM(PPVTotal) AS PPVTotal
FROM
    (SELECT INVDTL.POPRCTNM,INVDTL.INVINDX,(CASE WHEN INVDTL.UNITCOST=0 THEN INVDTL.EXTDCOST-DTL.EXTDCOST 
			ELSE (INVDTL.UNITCOST-DTL.UNITCOST)*QTYINVCD END) AS PPVTotal 
		FROM [FFSMQ0300].[FORD].[DBO].POP30310 INVDTL (NOLOCK) 
		JOIN [FFSMQ0300].[FORD].[DBO].POP10600 INV (NOLOCK) ON INV.POPIVCNO=INVDTL.POPRCTNM AND INV.IVCLINNO=INVDTL.RCPTLNNM 
		JOIN [FFSMQ0300].[FORD].[DBO].POP30310 DTL (NOLOCK) ON INV.POPRCTNM=DTL.POPRCTNM AND INV.RCPTLNNM=DTL.RCPTLNNM
		JOIN [FFSMQ0300].[FORD].[DBO].POP30300 HDR (NOLOCK)  ON HDR.POPRCTNM=INVDTL.POPRCTNM 
		WHERE HDR.POPTYPE=2 AND (CASE WHEN INVDTL.UNITCOST=0 THEN ABS(INVDTL.EXTDCOST-DTL.EXTDCOST) 
		ELSE ABS((INVDTL.UNITCOST-DTL.UNITCOST)*QTYINVCD) END)>0) INVDTL
GROUP BY INVDTL.POPRCTNM,INVDTL.INVINDX
) RECV ON GL.ORCTRNUM=RECV.POPRCTNM AND GL.ACTINDX=RECV.INVINDX AND GL.SOURCDOC=RECV.SOURCDOC
WHERE ABS(ISNULL(GLAMOUNT,0)-ISNULL(EXTDCOST,0))>=1
) Fnx
GO
', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load GPffEmployee Travel Data]    Script Date: 11-03-2020 17:09:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load GPffEmployee Travel Data', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'----Drop Existing Tables
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffDescriptions]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffDescriptions]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffEmployeeTravel]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffEmployeeTravel]
GO

---Load the data to the Tables
select * into [dbo].[GPffDescriptions] FROM [ffsmq0300].ford.[dbo].ffDescriptions with (nolock)
GO
select * into [dbo].[GPffEmployeeTravel] FROM [ffsmq0300].ford.[dbo].ffEmployeeTravel with (nolock) Where Year([Transaction Date]) >= 2016
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load Travel Expense Detail Data]    Script Date: 11-03-2020 17:09:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load Travel Expense Detail Data', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Truncate table [BI2].[GP_TravelDetail_Load]

DECLARE @YearCurrent  int
SELECT @YearCurrent = 2016
 BEGIN
   WHILE (@YearCurrent) <= Year(getdate())
   BEGIN
      Exec [BI2].[TravelExpenseReport_tableau_Load] @YearCurrent
      SELECT @YearCurrent = @YearCurrent + 1
      CONTINUE
  END
END
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call Expense Report Data Loading]    Script Date: 11-03-2020 17:09:32 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call Expense Report Data Loading', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_start_job N''Secondary_GP_ExpenseReport_DataLoading''', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call Travel Expense Summary Data Load]    Script Date: 11-03-2020 17:09:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call Travel Expense Summary Data Load', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.sp_start_job N''Secondary_GP_TravelExpense_Summary_Loading''', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update GP tables]    Script Date: 11-03-2020 17:09:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update GP tables', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=15, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/******************Drop Existing Tables**********************************/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffInvoiceDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffInvoiceDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffInvoices]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffInvoices]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffOTIINFO]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffOTIINFO]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentDetails]'') AND type in (N''U''))
TRUNCATE TABLE [dbo].[GPffPaymentDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentDetailsWithCostCenter]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPaymentDetailsWithCostCenter]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentDetailsWithRequisitionDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPaymentDetailsWithRequisitionDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPayments]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPayments]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPOInquiry]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPOInquiry]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPurchaseOrderDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPurchaseOrderDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPurchaseOrders]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPurchaseOrders]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitionDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitionDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitions]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitions]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffShipmentReceiptDetails]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffShipmentReceiptDetails]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffShipmentReceipts]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffShipmentReceipts]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPRqdetail]'') AND type in (N''U''))
DROP TABLE [dbo].[GPRqdetail]
GO
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffDescriptions]'') AND type in (N''U''))
--DROP TABLE [dbo].[GPffDescriptions]
--GO
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffEmployeeTravel]'') AND type in (N''U''))
--DROP TABLE [dbo].[GPffEmployeeTravel]
--GO
--IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffEmployeeTravel]'') AND type in (N''U''))
--DROP TABLE [dbo].[GPffEmployeeTravel]
--GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffInvoiceDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffInvoiceDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPaymentdetailsWithRequisitionDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPaymentdetailsWithRequisitionDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffPurchaseOrderDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffPurchaseOrderDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitionDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitionDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffShipmentReceiptDetailsCalculated]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffShipmentReceiptDetailsCalculated]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffpurchaseorderdetailscalculated20160713]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffpurchaseorderdetailscalculated20160713]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitiondetailscalculated20160713]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitiondetailscalculated20160713]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffManualAdjustments]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffManualAdjustments] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffExpensesRowDefinition]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffExpensesRowDefinition] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffrcvheader]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffrcvheader] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPProjectMaster]'') AND type in (N''U''))
DROP TABLE [dbo].[GPProjectMaster]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPVendorMaster]'') AND type in (N''U''))
DROP TABLE [dbo].[GPVendorMaster]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffpurchaseorderdetailscalculated20170214]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffpurchaseorderdetailscalculated20170214]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffRequisitionDetailsCalculated20180802]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffRequisitionDetailsCalculated20180802] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffReceiptsDraft20170201]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffReceiptsDraft20170201] 
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPVendorOFACView]'') AND type in (N''U''))
DROP TABLE [dbo].[GPVendorOFACView]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPRQDetailLog]'') AND type in (N''U''))
DROP TABLE [dbo].[GPRQDetailLog]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPWCLogType]'') AND type in (N''U''))
DROP TABLE [dbo].[GPWCLogType]
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPWCLanguageResourceD]'') AND type in (N''U''))
DROP TABLE [dbo].[GPWCLanguageResourceD]
GO

/**********************loading GP View data to DW Tables*****************************************/

select * into [dbo].[GPffInvoiceDetails] from [ffsmq0300].ford.[dbo].[ffInvoiceDetails] with (nolock)

select * into [dbo].[GPffInvoices] from [ffsmq0300].ford.[dbo].[ffInvoices] with (nolock)

select * into [dbo].[GPffOTIINFO] from [ffsmq0300].ford.[dbo].[ffOTIINFO] with (nolock)
GO
Insert into [dbo].[GPffPaymentDetails] ([Payment Number],[Voucher Number],[Invoice Number],[Invoice Receipt Number],[CreatedDate])
Select [Payment Number],[Voucher Number],[Invoice Number],[Invoice Receipt Number],getdate() From
[ffsmq0300].ford.[dbo].[ffPaymentDetails] with (nolock)
GO
select * into [dbo].[GPffPaymentDetailsWithCostCenter] from [ffsmq0300].ford.[dbo].[ffPaymentDetailsWithCostCenter] with (nolock)
GO
select * into [dbo].[GPffPaymentDetailsWithRequisitionDetails] from [ffsmq0300].ford.[dbo].[ffPaymentDetailsWithRequisitionDetails] with (nolock)
GO
select * into [dbo].[GPffPayments] from [ffsmq0300].ford.[dbo].[ffPayments] with (nolock)
GO
select * into [dbo].[GPffPOInquiry] from [ffsmq0300].ford.[dbo].[ffPOInquiry] with (nolock)
GO
select * into [dbo].[GPffPurchaseOrderDetails] from [ffsmq0300].ford.[dbo].[ffPurchaseOrderDetails] with (nolock)
GO 
select * into [dbo].[GPffPurchaseOrders] from [ffsmq0300].ford.[dbo].[ffPurchaseOrders] with (nolock)
GO
select * into [dbo].[GPffRequisitionDetails] from [ffsmq0300].ford.[dbo].[ffRequisitionDetails] with (nolock)
GO 
select * into [dbo].[GPffRequisitions] from [ffsmq0300].ford.[dbo].[ffRequisitions] with (nolock)
GO
select * into [dbo].[GPffShipmentReceiptDetails] from [ffsmq0300].ford.[dbo].[ffShipmentReceiptDetails] with (nolock)
GO
select * into [dbo].[GPffShipmentReceipts] from [ffsmq0300].ford.[dbo].[ffShipmentReceipts] with (nolock)
GO
select * into [dbo].[GPRqdetail] from [ffsmq0300].ford.[dbo].[Rqdetail] with (nolock)
GO
--select * into [dbo].[GPffDescriptions] FROM [ffsmq0300].ford.[dbo].ffDescriptions with (nolock)
--GO
--select * into [dbo].[GPffEmployeeTravel] FROM [ffsmq0300].ford.[dbo].ffEmployeeTravel with (nolock) Where Year([Transaction Date]) >= 2016
--GO

/********************Loading Updated Views 14/5/2014 BICCL212**********************/

select * into [dbo].[GPffInvoiceDetailsCalculated] FROM [ffsmq0300].ford.[dbo].ffInvoiceDetailsCalculated with (nolock)
GO
select * into [dbo].[GPffPaymentdetailsWithRequisitionDetailsCalculated] FROM [ffsmq0300].ford.[dbo].ffPaymentdetailsWithRequisitionDetailsCalculated with (nolock)
GO
select * into [dbo].[GPffPurchaseOrderDetailsCalculated] FROM [ffsmq0300].ford.[dbo].ffPurchaseOrderDetailsCalculated with (nolock)
GO
select * into [dbo].[GPffRequisitionDetailsCalculated] FROM [ffsmq0300].ford.[dbo].ffRequisitionDetailsCalculated with (nolock)
GO
select * into [dbo].[GPffShipmentReceiptDetailsCalculated] FROM [ffsmq0300].ford.[dbo].ffShipmentReceiptDetailsCalculated with (nolock)
GO

/****Loading New View for Expense Dashboard 9/11/2014 MA********/
select * into [dbo].[GPffManualAdjustments] FROM [ffsmq0300].ford.[dbo].ffManualAdjustments  with (nolock)
GO

select * into [dbo].GPffExpensesRowDefinition from [ffsmq0300].ford.[dbo].ffExpensesRowDefinition with (nolock)
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffBudget]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffBudget] 
GO

select *  into [dbo].[GPffBudget] from 
(SELECT
GL00105.ACTNUMST [Account Number],
GL00100.ACTDESCR [Account Name],
GL00201.YEAR1 [Fiscal Year],
GL00201.PERIODID [Fiscal Period],
GL00201.BUDGETAMT [Budget Amount]
,(SELECT DSCRIPTN FROM [ffsmq0300].FORD.dbo.GL40200 with (nolock)  WHERE SGMTNUMB=1 AND SGMNTID=substring(GL00105.ACTNUMST,1,2)) [Location Name]
-- RTRIM(AccountMaster.ACTNUMBR_2) [Cost Center],
 ,(SELECT DSCRIPTN FROM [ffsmq0300].FORD.dbo.GL40200 with (nolock)  WHERE SGMTNUMB=2 AND SGMNTID=substring(GL00105.ACTNUMST,4,4)) [Cost Center Name]
 --RTRIM(AccountMaster.ACTNUMBR_3) [Object],
 ,(SELECT DSCRIPTN FROM [ffsmq0300].FORD.dbo.GL40200 with (nolock)  WHERE SGMTNUMB=3 AND SGMNTID=substring(GL00105.ACTNUMST,9,5)) [Object Name],
  ReportingTree.[Reporting Unit],
ReportingTree.[Parent Unit]
,substring(GL00105.ACTNUMST,9,13) as [Object]
FROM [ffsmq0300].ford.[dbo].GL00201 with (nolock)
INNER JOIN [ffsmq0300].ford.[dbo].GL00105 with (nolock)  ON GL00201.ACTINDX=GL00105.ACTINDX
INNER JOIN  [ffsmq0300].ford.[dbo].GL00100 with (nolock) ON GL00105.ACTINDX=GL00100.ACTINDX
 LEFT JOIN (SELECT
             Description [Reporting Unit],
             (SELECT TOP 1 [UnitCode] FROM [ffsmq0300].[ManagementReporter].[Reporting].[ControlTreeDetail] with (nolock) WHERE TreeID=ReportingTree.TreeID AND ID=ReportingTree.ParentUnitID) [Parent Unit],
             (SELECT TOP 1 [Low] FROM [ffsmq0300].[ManagementReporter].[Reporting].[ControlTreeCriteria] with (nolock) WHERE TreeDetailID=ReportingTree.ID AND CriteriaType=13 AND [DimensionCode]=''Location'') [Location],
             (SELECT TOP 1 [Low] FROM [ffsmq0300].[ManagementReporter].[Reporting].[ControlTreeCriteria] with (nolock) WHERE TreeDetailID=ReportingTree.ID AND CriteriaType=13 AND [DimensionCode]=''Cost Center'') [Cost Center]
            FROM [ffsmq0300].[ManagementReporter].[Reporting].[ControlTreeDetail] ReportingTree with (nolock)
            WHERE 1=1
             AND TreeID IN (SELECT [ID] FROM [ffsmq0300].[ManagementReporter].[Reporting].[ControlTreeMaster] with (nolock) WHERE Name=''FordForward Global 2020-exclFAPCapex'')
             AND CompanyID IS NOT NULL
             AND (SELECT TOP 1 [Low] FROM [ffsmq0300].[ManagementReporter].[Reporting].[ControlTreeCriteria] with (nolock) WHERE TreeDetailID=ReportingTree.ID AND CriteriaType=13 AND [DimensionCode]=''Cost Center'') IS NOT NULL
            ) ReportingTree ON substring(GL00105.ACTNUMST,1,2)=ReportingTree.Location AND substring(GL00105.ACTNUMST,4,4)=ReportingTree.[Cost Center]

WHERE 1=1
AND GL00201.BUDGETID NOT LIKE ''ENC%''  and GL00201.BUDGETID  LIKE ''FY%''  )budget
GO

/********Added on 7/14/2016 LJ********************/
Select * into [GPffpurchaseorderdetailscalculated20160713] From [ffsmq0300].ford.dbo.ffpurchaseorderdetailscalculated20160713 with (nolock)
GO
Select * into [GPffRequisitiondetailscalculated20160713] From [ffsmq0300].ford.dbo.ffRequisitiondetailscalculated20160713 with (nolock)
GO
/********Added on 8/5/2016 MA********************/
select * into [dbo].[GPffrcvheader] from [ffsmq0300].[FORD].[dbo].rcvheader with (nolock)
GO

--Added on 01/27/2017 for Masters
Select * into [dbo].[GPProjectMaster] from [ffsmq0300].[FORD].[dbo].pa01201 with (nolock)
GO
Select * into [dbo].[GPVendorMaster] from [ffsmq0300].[FORD].[dbo].PM00200 with (nolock)
GO

--Added on 2/16/2017
--Marked on 13/06/2017
-- MA 6/14/2017 Working fine.
Select * into [GPffpurchaseorderdetailscalculated20170214] from ffsmq0300.Ford.dbo.[ffpurchaseorderdetailscalculated20170214] with (nolock)
GO

----Marked by Lijo on 17/01/2019 Bcs, the same script avialable in Load ffdescription step of Secondary_GP_ExpenseReport_DataLoading job.
-----Select * into GPExpensesDescription From [BI2].[Expenses_Description]  with (nolock)
----GO

--- Added on 8/2/2018
Select * into [GPffRequisitionDetailsCalculated20180802]   from ffsmq0300.Ford.dbo.[ffRequisitionDetailsCalculated20180802] with (nolock)
GO

--- Added on 26/02/2019
Select * into [GPffReceiptsDraft20170201]   from ffsmq0300.Ford.dbo.[ffReceiptsDraft20170201] with (nolock)
GO

----Added on 05/03/2019
select * into GPVendorOFACView from [FFGCP0301\INST_GPPRD].[GPCUSTOM].[dbo].[VendorOFACView] with (nolock)
GO

---Added on 17/03/2019
select * into [dbo].[GPRQDetailLog] FROM ffsmq0300.FORD.dbo.RQDetailLog with (nolock)
GO
select * into [dbo].[GPWCLogType] FROM ffsmq0300.FORD.dbo.WCLogType with (nolock)
GO
select * into [dbo].[GPWCLanguageResourceD] FROM ffsmq0300.FORD.dbo.WCLanguageResourceD with (nolock)
GO

---------------------------------------------------------------------------------Added on 24/07/2019 for OCDCA Purchase table

Truncate table [BI2].[OCDCAprojectname_Purchase]
GO

Insert into [BI2].[OCDCAprojectname_Purchase] (OldProjectNumber,OldProjectName,NewProjectNumber,NewProjectName)
Select distinct ltrim(rtrim([Project Number])),ltrim(rtrim([Project Name])),iif(ltrim(rtrim(substring([Project Number],1,5)))=''OCDCA'',
ltrim(rtrim([Project Number])),NULL),iif(ltrim(rtrim(substring([Project Number],1,5)))=''OCDCA'',
ltrim(rtrim([Project Name])),NULL) from [GPffpurchaseorderdetailscalculated20170214] with (nolock)
Where [unit] not in (''7000'') and [Account Number]=''01-8000-62000''
GO

Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Media Strategy'',
NewProjectNumber=''OCDCAMEDIASTRAT'' where right(ltrim(rtrim(OldProjectNumber)),5)=''MEDIA''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Photography/Design'',
NewProjectNumber=''OCDCAPHOTO'' where right(ltrim(rtrim(OldProjectNumber)),5)=''PHOTO''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Oral History'',
NewProjectNumber=''OCDCAORALHIST'' where right(ltrim(rtrim(OldProjectNumber)),5)=''ORALH''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Events'',
NewProjectNumber=''OCDCAEVENTS'' where right(ltrim(rtrim(OldProjectNumber)),5)=''EVENT''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCAEVENTS'',
NewProjectNumber=''OCDCAEVENTS'' where right(ltrim(rtrim(OldProjectNumber)),6)=''EVENTS''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Digital Web Production'',
NewProjectNumber=''OCDCADIGITAL'' where right(ltrim(rtrim(OldProjectNumber)),6)=''DIITAL''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Multimedia'',
NewProjectNumber=''OCDCAMULMEDIA'' where right(ltrim(rtrim(OldProjectNumber)),6)=''MULMED''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCASOCIALMED'',
NewProjectNumber=''OCDCASOCIALMED'' where right(ltrim(rtrim(OldProjectNumber)),6)=''SOCIAL''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OC DCA Content Dev & Impact'',
NewProjectNumber=''OCDCACONTENT'' where right(ltrim(rtrim(OldProjectNumber)),7)=''CONTENT''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Digital Web Production'',
NewProjectNumber=''OCDCADIGITAL'' where right(ltrim(rtrim(OldProjectNumber)),7)=''DIGITAL''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Media Strategy'',
NewProjectNumber=''OCDCAMEDIASTRAT'' where right(ltrim(rtrim(OldProjectNumber)),8)=''MEDSTRAT''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Multimedia'',
NewProjectNumber=''OCDCAMULMEDIA'' where right(ltrim(rtrim(OldProjectNumber)),8)=''MULMEDIA''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OC DCA Brand Research'',
NewProjectNumber=''OCDCABRAND'' where right(ltrim(rtrim(OldProjectNumber)),8)=''BRANDREF''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Oral History'',
NewProjectNumber=''OCDCAORALHIST'' where right(ltrim(rtrim(OldProjectNumber)),8)=''ORALHIST''
GO
Update [BI2].[OCDCAprojectname_Purchase] set NewProjectName=''OCDCA Media Strategy'',
NewProjectNumber=''OCDCAMEDIASTRAT'' where right(ltrim(rtrim(OldProjectNumber)),10)=''MEDIASTRAT''
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [GPffExpense Data Load]    Script Date: 11-03-2020 17:09:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'GPffExpense Data Load', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[GPffExpenses]'') AND type in (N''U''))
DROP TABLE [dbo].[GPffExpenses] 
GO



---Marked on 10/24/2018 due to query timeout error
--select * into [dbo].[GPffExpenses] from 
--(
----------select * from [ffsmq0300].ford.[dbo].[ffExpensesDraft]
----------where year([expense date]) =2016 2015
--select * from [ffsmq0300].ford.[dbo].[ffExpensesForward]
--where year([expense date]) =2016 
--union
--select * from [ffsmq0300].ford.[dbo].[ffExpenses]
--where year([expense date]) < 2016
--union
--select * from [ffsmq0300].ford.[dbo].[ffExpensesForward2017]
--where year([expense date]) = 2017
--union 
--select * from [ffsmq0300].ford.[dbo].[ffExpensesForward2018]
--where year([expense date]) >2017
--) FFEXP
--GO


-----Added on 10/24/2018 to resolve the query time out error.
--Select * into GPffExpenses2016 From (
----	select * from [ffsmq0300].ford.[dbo].[ffExpensesForward] with (nolock)
----	where year([expense date]) =2016 
----MA 1/8/2018 Include only the expense from 2016 onwards 
--	--union
--	--select * from [ffsmq0300].ford.[dbo].[ffExpenses]
--	---where year([expense date]) < 2016
--) F16
--GO
Select * into GPffExpenses From (
	select * from [ffsmq0300].ford.[dbo].[ffExpensesForward] with (nolock)
	where year([expense date]) =2016 
	Union All
	select * from [ffsmq0300].ford.[dbo].[ffExpensesForward2017] with (nolock)
	where year([expense date]) = 2017
	Union All
	select * from [ffsmq0300].ford.[dbo].[ffExpensesForward2018] with (nolock)
	where year([expense date]) =2018
	Union All
	select * from [ffsmq0300].ford.[dbo].[ffExpensesForward2019] with (nolock)
	where year([expense date]) =2019
                Union All
	select * from [ffsmq0300].ford.[dbo].[ffExpensesForward2020] with (nolock)
	where year([expense date]) >=2020
)Exp_Temp
GO

---Load GPExpense Data
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[BI2].[GPExpensesData]'') AND type in (N''U''))
DROP TABLE [BI2].[GPExpensesData]
GO

Select * into [BI2].[GPExpensesData] From [BI2].[expensedata] with (nolock)
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load GP Audit Tables Data]    Script Date: 11-03-2020 17:09:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load GP Audit Tables Data', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=3, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [dbo].GPAuditData
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Secondary GP Database]    Script Date: 11-03-2020 17:09:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Secondary GP Database', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'----Backup DW Staging 
BACKUP DATABASE [PROD_GP] TO  DISK = N''\\ffgcp0558\TEMPSQLBCKP\PROD_GP.BAK'' WITH COMPRESSION , copy_only, FORMAT, INIT,  NAME = N''PROD_GP-Full Database Backup'', SKIP, NOREWIND, NOUNLOAD,  STATS = 10', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Call Secondary GP Restore Job]    Script Date: 11-03-2020 17:09:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Call Secondary GP Restore Job', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'osql -E -S FFGCP0558\INST_EDWPROD -Q "exec msdb.dbo.sp_start_job @job_name = ''Secondary GP Restore from ETL''', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DMZ-PROD_GP_SnapRefresh]    Script Date: 11-03-2020 17:09:34 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DMZ-PROD_GP_SnapRefresh', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [DMZ].msdb.dbo.sp_start_job N''PROD_GP_SnapRefresh''', 
		@database_name=N'master', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Step1', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20190226, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'caf9ff7d-d47b-4c83-8614-b5db46b680b0'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


