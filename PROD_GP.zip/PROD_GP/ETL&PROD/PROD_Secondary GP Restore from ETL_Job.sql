/****** Object:  Job [Secondary GP Restore from ETL]    Script Date: 11-03-2020 17:12:07 ******/
EXEC msdb.dbo.sp_delete_job @job_id=N'9b1f973c-c4e7-4387-b609-e6b14114b175', @delete_unused_schedule=1
GO

/****** Object:  Job [Secondary GP Restore from ETL]    Script Date: 11-03-2020 17:12:07 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 11-03-2020 17:12:08 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Secondary GP Restore from ETL', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'dbadmin', 
		@notify_email_operator_name=N'GBSII', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Point PROD_GP To PROD_GP_B]    Script Date: 11-03-2020 17:12:11 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Point PROD_GP To PROD_GP_B', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoiceDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffInvoiceDetails
END
GO 
CREATE SYNONYM GPffInvoiceDetails FOR [PROD_GP_B].[DBO].[GPffInvoiceDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoices'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffInvoices
END
GO 
CREATE SYNONYM GPffInvoices FOR [PROD_GP_B].[DBO].[GPffInvoices]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffOTIINFO'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffOTIINFO
END
GO 
CREATE SYNONYM GPffOTIINFO FOR [PROD_GP_B].[DBO].[GPffOTIINFO]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentDetails
END
GO 
CREATE SYNONYM GPffPaymentDetails FOR [PROD_GP_B].[DBO].[GPffPaymentDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentDetailsWithCostCenter'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentDetailsWithCostCenter
END
GO 
CREATE SYNONYM GPffPaymentDetailsWithCostCenter FOR [PROD_GP_B].[DBO].[GPffPaymentDetailsWithCostCenter]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentDetailsWithRequisitionDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentDetailsWithRequisitionDetails
END
GO 
CREATE SYNONYM GPffPaymentDetailsWithRequisitionDetails FOR [PROD_GP_B].[DBO].[GPffPaymentDetailsWithRequisitionDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPayments'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPayments
END
GO 
CREATE SYNONYM GPffPayments FOR [PROD_GP_B].[DBO].[GPffPayments]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPOInquiry'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPOInquiry
END
GO 
CREATE SYNONYM GPffPOInquiry FOR [PROD_GP_B].[DBO].[GPffPOInquiry]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPurchaseOrderDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPurchaseOrderDetails
END
GO 
CREATE SYNONYM GPffPurchaseOrderDetails FOR [PROD_GP_B].[DBO].[GPffPurchaseOrderDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPurchaseOrders'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPurchaseOrders
END
GO 
CREATE SYNONYM GPffPurchaseOrders FOR [PROD_GP_B].[DBO].[GPffPurchaseOrders]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitionDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitionDetails
END
GO 
CREATE SYNONYM GPffRequisitionDetails FOR [PROD_GP_B].[DBO].[GPffRequisitionDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitions
END
GO 
CREATE SYNONYM GPffRequisitions FOR [PROD_GP_B].[DBO].[GPffRequisitions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffShipmentReceiptDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffShipmentReceiptDetails
END
GO 
CREATE SYNONYM GPffShipmentReceiptDetails FOR [PROD_GP_B].[DBO].[GPffShipmentReceiptDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffShipmentReceipts'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffShipmentReceipts
END
GO 
CREATE SYNONYM GPffShipmentReceipts FOR [PROD_GP_B].[DBO].[GPffShipmentReceipts]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPRqdetail'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPRqdetail
END
GO 
CREATE SYNONYM GPRqdetail FOR [PROD_GP_B].[DBO].[GPRqdetail]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffDescriptions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffDescriptions
END
GO 
CREATE SYNONYM GPffDescriptions FOR [PROD_GP_B].[DBO].[GPffDescriptions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffEmployeeTravel'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffEmployeeTravel
END
GO 
CREATE SYNONYM GPffEmployeeTravel FOR [PROD_GP_B].[DBO].[GPffEmployeeTravel]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoiceDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffInvoiceDetailsCalculated
END
GO 
CREATE SYNONYM GPffInvoiceDetailsCalculated FOR [PROD_GP_B].[DBO].[GPffInvoiceDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentdetailsWithRequisitionDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentdetailsWithRequisitionDetailsCalculated
END
GO 
CREATE SYNONYM GPffPaymentdetailsWithRequisitionDetailsCalculated FOR [PROD_GP_B].[DBO].[GPffPaymentdetailsWithRequisitionDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPurchaseOrderDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPurchaseOrderDetailsCalculated
END
GO 
CREATE SYNONYM GPffPurchaseOrderDetailsCalculated FOR [PROD_GP_B].[DBO].[GPffPurchaseOrderDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitionDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitionDetailsCalculated
END
GO 
CREATE SYNONYM GPffRequisitionDetailsCalculated FOR [PROD_GP_B].[DBO].[GPffRequisitionDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffShipmentReceiptDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffShipmentReceiptDetailsCalculated
END
GO 
CREATE SYNONYM GPffShipmentReceiptDetailsCalculated FOR [PROD_GP_B].[DBO].[GPffShipmentReceiptDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffpurchaseorderdetailscalculated20160713'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffpurchaseorderdetailscalculated20160713
END
GO 
CREATE SYNONYM GPffpurchaseorderdetailscalculated20160713 FOR [PROD_GP_B].[DBO].[GPffpurchaseorderdetailscalculated20160713]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitiondetailscalculated20160713'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitiondetailscalculated20160713
END
GO 
CREATE SYNONYM GPffRequisitiondetailscalculated20160713 FOR [PROD_GP_B].[DBO].[GPffRequisitiondetailscalculated20160713]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffManualAdjustments'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffManualAdjustments
END
GO 
CREATE SYNONYM GPffManualAdjustments FOR [PROD_GP_B].[DBO].[GPffManualAdjustments]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffExpensesRowDefinition'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffExpensesRowDefinition
END
GO 
CREATE SYNONYM GPffExpensesRowDefinition FOR [PROD_GP_B].[DBO].[GPffExpensesRowDefinition]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPAccountBudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPAccountBudget
END
GO 
CREATE SYNONYM GPAccountBudget FOR [PROD_GP_B].[DBO].[GPAccountBudget]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffrcvheader'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffrcvheader
END
GO 
CREATE SYNONYM GPffrcvheader FOR [PROD_GP_B].[DBO].[GPffrcvheader]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPProjectMaster'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPProjectMaster
END
GO 
CREATE SYNONYM GPProjectMaster FOR [PROD_GP_B].[DBO].[GPProjectMaster]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffpurchaseorderdetailscalculated20170214'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffpurchaseorderdetailscalculated20170214
END
GO 
CREATE SYNONYM GPffpurchaseorderdetailscalculated20170214 FOR [PROD_GP_B].[DBO].[GPffpurchaseorderdetailscalculated20170214]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPExpensesDescription'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPExpensesDescription
END
GO 
CREATE SYNONYM GPExpensesDescription FOR [PROD_GP_B].[DBO].[GPExpensesDescription]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitionDetailsCalculated20180802'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitionDetailsCalculated20180802
END
GO 
CREATE SYNONYM GPffRequisitionDetailsCalculated20180802 FOR [PROD_GP_B].[DBO].[GPffRequisitionDetailsCalculated20180802]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''ExpenseReport_Data'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM ExpenseReport_Data
END
GO 
CREATE SYNONYM ExpenseReport_Data FOR [PROD_GP_B].[DBO].[ExpenseReport_Data]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffBudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffBudget
END
GO 
CREATE SYNONYM GPffBudget FOR [PROD_GP_B].[DBO].[GPffBudget]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffExpenses'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffExpenses
END
GO 
CREATE SYNONYM GPffExpenses FOR [PROD_GP_B].[DBO].[GPffExpenses]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Dim_ChartOfAccounts'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Dim_ChartOfAccounts
END
GO 
CREATE SYNONYM Dim_ChartOfAccounts FOR [PROD_GP_B].[DBO].[Dim_ChartOfAccounts]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Dim_Vendors'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Dim_Vendors
END
GO 
CREATE SYNONYM Dim_Vendors FOR [PROD_GP_B].[DBO].[Dim_Vendors]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_GeneralLedger'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_GeneralLedger
END
GO 
CREATE SYNONYM Fact_GeneralLedger FOR [PROD_GP_B].[DBO].[Fact_GeneralLedger]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PayablesTransactions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PayablesTransactions
END
GO 
CREATE SYNONYM Fact_PayablesTransactions FOR [PROD_GP_B].[DBO].[Fact_PayablesTransactions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PayablesApplication'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PayablesApplication
END
GO 
CREATE SYNONYM Fact_PayablesApplication FOR [PROD_GP_B].[DBO].[Fact_PayablesApplication]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PurchasingReceipts'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PurchasingReceipts
END
GO 
CREATE SYNONYM Fact_PurchasingReceipts FOR [PROD_GP_B].[DBO].[Fact_PurchasingReceipts]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_ReceiveMatchInvoices'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_ReceiveMatchInvoices
END
GO 
CREATE SYNONYM Fact_ReceiveMatchInvoices FOR [PROD_GP_B].[DBO].[Fact_ReceiveMatchInvoices]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_Requisitions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_Requisitions
END
GO 
CREATE SYNONYM Fact_Requisitions FOR [PROD_GP_B].[DBO].[Fact_Requisitions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PurchaseOrders'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PurchaseOrders
END
GO 
CREATE SYNONYM Fact_PurchaseOrders FOR [PROD_GP_B].[DBO].[Fact_PurchaseOrders]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_RequisitionsLog'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_RequisitionsLog
END
GO 
CREATE SYNONYM Fact_RequisitionsLog FOR [PROD_GP_B].[DBO].[Fact_RequisitionsLog]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPVendorMaster'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPVendorMaster
END
GO 
CREATE SYNONYM GPVendorMaster FOR [PROD_GP_B].[DBO].[GPVendorMaster]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GP_TravelExpenseReports'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GP_TravelExpenseReports
END
GO 
CREATE SYNONYM GP_TravelExpenseReports FOR [PROD_GP_B].[DBO].[GP_TravelExpenseReports]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''TravelExpenseReport_tableau'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[TravelExpenseReport_tableau]
END
GO 
CREATE SYNONYM [BI2].[TravelExpenseReport_tableau] FOR [PROD_GP_B].[BI2].[TravelExpenseReport_tableau]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GP_TravelDetail_Load'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[GP_TravelDetail_Load]
END
GO 
CREATE SYNONYM [BI2].[GP_TravelDetail_Load] FOR [PROD_GP_B].[BI2].[GP_TravelDetail_Load]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GP_TravelSummary_Load'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[GP_TravelSummary_Load]
END
GO 
CREATE SYNONYM [BI2].[GP_TravelSummary_Load] FOR [PROD_GP_B].[BI2].[GP_TravelSummary_Load]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffReceiptsDraft20170201'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [dbo].[GPffReceiptsDraft20170201]
END
GO 
CREATE SYNONYM [dbo].[GPffReceiptsDraft20170201] FOR [PROD_GP_B].[DBO].[GPffReceiptsDraft20170201]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffDescriptions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffDescriptions
END
GO 
CREATE SYNONYM GPffDescriptions FOR [PROD_GP_B].[DBO].[GPffDescriptions]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPVendorOFACView'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPVendorOFACView
END
GO 
CREATE SYNONYM GPVendorOFACView FOR [PROD_GP_B].[DBO].[GPVendorOFACView]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Dim_Department'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Dim_Department
END
GO 
CREATE SYNONYM Dim_Department FOR [PROD_GP_B].[DBO].[Dim_Department]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PurchasingReceipts2Requisitions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PurchasingReceipts2Requisitions
END
GO 
CREATE SYNONYM Fact_PurchasingReceipts2Requisitions FOR [PROD_GP_B].[DBO].[Fact_PurchasingReceipts2Requisitions]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPRQDetailLog'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPRQDetailLog
END
GO 
CREATE SYNONYM GPRQDetailLog FOR [PROD_GP_B].[DBO].[GPRQDetailLog]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPWCLanguageResourceD'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPWCLanguageResourceD
END
GO 
CREATE SYNONYM GPWCLanguageResourceD FOR [PROD_GP_B].[DBO].[GPWCLanguageResourceD]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPWCLogType'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPWCLogType
END
GO 
CREATE SYNONYM GPWCLogType FOR [PROD_GP_B].[DBO].[GPWCLogType]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPExpensesData'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[GPExpensesData]
END
GO 
CREATE SYNONYM [BI2].[GPExpensesData] FOR [PROD_GP_B].[BI2].[GPExpensesData]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''UserCostCenter_V1'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM UserCostCenter_V1
END
GO 
CREATE SYNONYM UserCostCenter_V1 FOR [PROD_GP_B].[dbo].[UserCostCenter_V1]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Usercostcenterexception'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Usercostcenterexception
END
GO 
CREATE SYNONYM Usercostcenterexception FOR [PROD_GP_B].[dbo].[Usercostcenterexception]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''UserCostCenterLocationPermission'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM UserCostCenterLocationPermission
END
GO 
CREATE SYNONYM UserCostCenterLocationPermission FOR [PROD_GP_B].[dbo].[UserCostCenterLocationPermission]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Organization Tree'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[Organization Tree]
END
GO 
CREATE SYNONYM [BI2].[Organization Tree] FOR [PROD_GP_B].[BI2].[Organization Tree]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''WorkdayUserInformation'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM WorkdayUserInformation
END
GO 
CREATE SYNONYM WorkdayUserInformation FOR [PROD_GP_B].[dbo].[WorkdayUserInformation]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''WorkdayUserInformation_All'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM WorkdayUserInformation_All
END
GO 
CREATE SYNONYM WorkdayUserInformation_All FOR [PROD_GP_B].[dbo].[WorkdayUserInformation_All]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''2015TravelBudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [2015TravelBudget]
END
GO 
CREATE SYNONYM [2015TravelBudget] FOR [PROD_GP_B].[dbo].[2015TravelBudget]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoiceSummary'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [GPffInvoiceSummary]
END
GO 
CREATE SYNONYM [GPffInvoiceSummary] FOR [PROD_GP_B].[dbo].[GPffInvoiceSummary]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''OCDCABudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[OCDCABudget]
END
GO 
CREATE SYNONYM [BI2].[OCDCABudget] FOR [PROD_GP_B].[BI2].[OCDCABudget]; 
GO


--------Added on 24/07/2019
IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''OCDCAprojectname_Purchase'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[OCDCAprojectname_Purchase]
END
GO 
CREATE SYNONYM [BI2].[OCDCAprojectname_Purchase] FOR [PROD_GP_B].[BI2].[OCDCAprojectname_Purchase]; 
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Restore PROD_GP_A]    Script Date: 11-03-2020 17:12:11 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Restore PROD_GP_A', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''PROD_GP_A''
GO
USE [master]
GO
ALTER DATABASE [PROD_GP_A] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
ALTER DATABASE [PROD_GP_A] SET  SINGLE_USER 
GO
USE [master]
GO
RESTORE DATABASE [PROD_GP_A] FROM  DISK = N''\\FFGCP0558\TEMPSQLBCKP\PROD_GP.BAK''
WITH  
MOVE ''GBS_DW_Base_Staging_UAT'' TO ''D:\MSSQL\DATA\PROD_FF_Grants_DW_Staging_A.mdf'', 
MOVE ''ftrow_GRANTEENAME'' TO ''D:\MSSQL\DATA\PROD_FF_Grants_DW_Staging_1_A.ndf'', 
MOVE ''GBS_DW_Base_Staging_UAT_log'' TO ''G:\LOG1\PROD_FF_Grants_DW_Staging_2_A.ldf'', 
FILE = 1,  
NOUNLOAD,  REPLACE,  STATS = 10
GO
ALTER DATABASE [PROD_GP_A] SET  MULTI_USER 
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Point PROD_GP To PROD_GP_A]    Script Date: 11-03-2020 17:12:11 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Point PROD_GP To PROD_GP_A', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoiceDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffInvoiceDetails
END
GO 
CREATE SYNONYM GPffInvoiceDetails FOR [PROD_GP_A].[DBO].[GPffInvoiceDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoices'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffInvoices
END
GO 
CREATE SYNONYM GPffInvoices FOR [PROD_GP_A].[DBO].[GPffInvoices]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffOTIINFO'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffOTIINFO
END
GO 
CREATE SYNONYM GPffOTIINFO FOR [PROD_GP_A].[DBO].[GPffOTIINFO]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentDetails
END
GO 
CREATE SYNONYM GPffPaymentDetails FOR [PROD_GP_A].[DBO].[GPffPaymentDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentDetailsWithCostCenter'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentDetailsWithCostCenter
END
GO 
CREATE SYNONYM GPffPaymentDetailsWithCostCenter FOR [PROD_GP_A].[DBO].[GPffPaymentDetailsWithCostCenter]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentDetailsWithRequisitionDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentDetailsWithRequisitionDetails
END
GO 
CREATE SYNONYM GPffPaymentDetailsWithRequisitionDetails FOR [PROD_GP_A].[DBO].[GPffPaymentDetailsWithRequisitionDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPayments'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPayments
END
GO 
CREATE SYNONYM GPffPayments FOR [PROD_GP_A].[DBO].[GPffPayments]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPOInquiry'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPOInquiry
END
GO 
CREATE SYNONYM GPffPOInquiry FOR [PROD_GP_A].[DBO].[GPffPOInquiry]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPurchaseOrderDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPurchaseOrderDetails
END
GO 
CREATE SYNONYM GPffPurchaseOrderDetails FOR [PROD_GP_A].[DBO].[GPffPurchaseOrderDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPurchaseOrders'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPurchaseOrders
END
GO 
CREATE SYNONYM GPffPurchaseOrders FOR [PROD_GP_A].[DBO].[GPffPurchaseOrders]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitionDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitionDetails
END
GO 
CREATE SYNONYM GPffRequisitionDetails FOR [PROD_GP_A].[DBO].[GPffRequisitionDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitions
END
GO 
CREATE SYNONYM GPffRequisitions FOR [PROD_GP_A].[DBO].[GPffRequisitions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffShipmentReceiptDetails'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffShipmentReceiptDetails
END
GO 
CREATE SYNONYM GPffShipmentReceiptDetails FOR [PROD_GP_A].[DBO].[GPffShipmentReceiptDetails]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffShipmentReceipts'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffShipmentReceipts
END
GO 
CREATE SYNONYM GPffShipmentReceipts FOR [PROD_GP_A].[DBO].[GPffShipmentReceipts]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPRqdetail'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPRqdetail
END
GO 
CREATE SYNONYM GPRqdetail FOR [PROD_GP_A].[DBO].[GPRqdetail]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffDescriptions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffDescriptions
END
GO 
CREATE SYNONYM GPffDescriptions FOR [PROD_GP_A].[DBO].[GPffDescriptions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffEmployeeTravel'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffEmployeeTravel
END
GO 
CREATE SYNONYM GPffEmployeeTravel FOR [PROD_GP_A].[DBO].[GPffEmployeeTravel]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoiceDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffInvoiceDetailsCalculated
END
GO 
CREATE SYNONYM GPffInvoiceDetailsCalculated FOR [PROD_GP_A].[DBO].[GPffInvoiceDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPaymentdetailsWithRequisitionDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPaymentdetailsWithRequisitionDetailsCalculated
END
GO 
CREATE SYNONYM GPffPaymentdetailsWithRequisitionDetailsCalculated FOR [PROD_GP_A].[DBO].[GPffPaymentdetailsWithRequisitionDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffPurchaseOrderDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffPurchaseOrderDetailsCalculated
END
GO 
CREATE SYNONYM GPffPurchaseOrderDetailsCalculated FOR [PROD_GP_A].[DBO].[GPffPurchaseOrderDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitionDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitionDetailsCalculated
END
GO 
CREATE SYNONYM GPffRequisitionDetailsCalculated FOR [PROD_GP_A].[DBO].[GPffRequisitionDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffShipmentReceiptDetailsCalculated'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffShipmentReceiptDetailsCalculated
END
GO 
CREATE SYNONYM GPffShipmentReceiptDetailsCalculated FOR [PROD_GP_A].[DBO].[GPffShipmentReceiptDetailsCalculated]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffpurchaseorderdetailscalculated20160713'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffpurchaseorderdetailscalculated20160713
END
GO 
CREATE SYNONYM GPffpurchaseorderdetailscalculated20160713 FOR [PROD_GP_A].[DBO].[GPffpurchaseorderdetailscalculated20160713]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitiondetailscalculated20160713'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitiondetailscalculated20160713
END
GO 
CREATE SYNONYM GPffRequisitiondetailscalculated20160713 FOR [PROD_GP_A].[DBO].[GPffRequisitiondetailscalculated20160713]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffManualAdjustments'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffManualAdjustments
END
GO 
CREATE SYNONYM GPffManualAdjustments FOR [PROD_GP_A].[DBO].[GPffManualAdjustments]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffExpensesRowDefinition'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffExpensesRowDefinition
END
GO 
CREATE SYNONYM GPffExpensesRowDefinition FOR [PROD_GP_A].[DBO].[GPffExpensesRowDefinition]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPAccountBudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPAccountBudget
END
GO 
CREATE SYNONYM GPAccountBudget FOR [PROD_GP_A].[DBO].[GPAccountBudget]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffrcvheader'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffrcvheader
END
GO 
CREATE SYNONYM GPffrcvheader FOR [PROD_GP_A].[DBO].[GPffrcvheader]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPProjectMaster'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPProjectMaster
END
GO 
CREATE SYNONYM GPProjectMaster FOR [PROD_GP_A].[DBO].[GPProjectMaster]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffpurchaseorderdetailscalculated20170214'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffpurchaseorderdetailscalculated20170214
END
GO 
CREATE SYNONYM GPffpurchaseorderdetailscalculated20170214 FOR [PROD_GP_A].[DBO].[GPffpurchaseorderdetailscalculated20170214]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPExpensesDescription'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPExpensesDescription
END
GO 
CREATE SYNONYM GPExpensesDescription FOR [PROD_GP_A].[DBO].[GPExpensesDescription]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffRequisitionDetailsCalculated20180802'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffRequisitionDetailsCalculated20180802
END
GO 
CREATE SYNONYM GPffRequisitionDetailsCalculated20180802 FOR [PROD_GP_A].[DBO].[GPffRequisitionDetailsCalculated20180802]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''ExpenseReport_Data'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM ExpenseReport_Data
END
GO 
CREATE SYNONYM ExpenseReport_Data FOR [PROD_GP_A].[DBO].[ExpenseReport_Data]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffBudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffBudget
END
GO 
CREATE SYNONYM GPffBudget FOR [PROD_GP_A].[DBO].[GPffBudget]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffExpenses'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffExpenses
END
GO 
CREATE SYNONYM GPffExpenses FOR [PROD_GP_A].[DBO].[GPffExpenses]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Dim_ChartOfAccounts'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Dim_ChartOfAccounts
END
GO 
CREATE SYNONYM Dim_ChartOfAccounts FOR [PROD_GP_A].[DBO].[Dim_ChartOfAccounts]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Dim_Vendors'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Dim_Vendors
END
GO 
CREATE SYNONYM Dim_Vendors FOR [PROD_GP_A].[DBO].[Dim_Vendors]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_GeneralLedger'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_GeneralLedger
END
GO 
CREATE SYNONYM Fact_GeneralLedger FOR [PROD_GP_A].[DBO].[Fact_GeneralLedger]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PayablesTransactions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PayablesTransactions
END
GO 
CREATE SYNONYM Fact_PayablesTransactions FOR [PROD_GP_A].[DBO].[Fact_PayablesTransactions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PayablesApplication'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PayablesApplication
END
GO 
CREATE SYNONYM Fact_PayablesApplication FOR [PROD_GP_A].[DBO].[Fact_PayablesApplication]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PurchasingReceipts'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PurchasingReceipts
END
GO 
CREATE SYNONYM Fact_PurchasingReceipts FOR [PROD_GP_A].[DBO].[Fact_PurchasingReceipts]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_ReceiveMatchInvoices'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_ReceiveMatchInvoices
END
GO 
CREATE SYNONYM Fact_ReceiveMatchInvoices FOR [PROD_GP_A].[DBO].[Fact_ReceiveMatchInvoices]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_Requisitions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_Requisitions
END
GO 
CREATE SYNONYM Fact_Requisitions FOR [PROD_GP_A].[DBO].[Fact_Requisitions]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PurchaseOrders'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PurchaseOrders
END
GO 
CREATE SYNONYM Fact_PurchaseOrders FOR [PROD_GP_A].[DBO].[Fact_PurchaseOrders]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_RequisitionsLog'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_RequisitionsLog
END
GO 
CREATE SYNONYM Fact_RequisitionsLog FOR [PROD_GP_A].[DBO].[Fact_RequisitionsLog]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPVendorMaster'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPVendorMaster
END
GO 
CREATE SYNONYM GPVendorMaster FOR [PROD_GP_A].[DBO].[GPVendorMaster]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GP_TravelExpenseReports'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GP_TravelExpenseReports
END
GO 
CREATE SYNONYM GP_TravelExpenseReports FOR [PROD_GP_A].[DBO].[GP_TravelExpenseReports]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''TravelExpenseReport_tableau'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[TravelExpenseReport_tableau]
END
GO 
CREATE SYNONYM [BI2].[TravelExpenseReport_tableau] FOR [PROD_GP_A].[BI2].[TravelExpenseReport_tableau]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GP_TravelDetail_Load'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[GP_TravelDetail_Load]
END
GO 
CREATE SYNONYM [BI2].[GP_TravelDetail_Load] FOR [PROD_GP_A].[BI2].[GP_TravelDetail_Load]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GP_TravelSummary_Load'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[GP_TravelSummary_Load]
END
GO 
CREATE SYNONYM [BI2].[GP_TravelSummary_Load] FOR [PROD_GP_A].[BI2].[GP_TravelSummary_Load]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffReceiptsDraft20170201'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [dbo].[GPffReceiptsDraft20170201]
END
GO 
CREATE SYNONYM [dbo].[GPffReceiptsDraft20170201] FOR [PROD_GP_A].[DBO].[GPffReceiptsDraft20170201]; 
GO 

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffDescriptions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPffDescriptions
END
GO 
CREATE SYNONYM GPffDescriptions FOR [PROD_GP_A].[DBO].[GPffDescriptions]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPVendorOFACView'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPVendorOFACView
END
GO 
CREATE SYNONYM GPVendorOFACView FOR [PROD_GP_A].[DBO].[GPVendorOFACView]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Dim_Department'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Dim_Department
END
GO 
CREATE SYNONYM Dim_Department FOR [PROD_GP_A].[DBO].[Dim_Department]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Fact_PurchasingReceipts2Requisitions'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Fact_PurchasingReceipts2Requisitions
END
GO 
CREATE SYNONYM Fact_PurchasingReceipts2Requisitions FOR [PROD_GP_A].[DBO].[Fact_PurchasingReceipts2Requisitions]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPRQDetailLog'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPRQDetailLog
END
GO 
CREATE SYNONYM GPRQDetailLog FOR [PROD_GP_A].[DBO].[GPRQDetailLog]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPWCLanguageResourceD'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPWCLanguageResourceD
END
GO 
CREATE SYNONYM GPWCLanguageResourceD FOR [PROD_GP_A].[DBO].[GPWCLanguageResourceD]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPWCLogType'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM GPWCLogType
END
GO 
CREATE SYNONYM GPWCLogType FOR [PROD_GP_A].[DBO].[GPWCLogType]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPExpensesData'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[GPExpensesData]
END
GO 
CREATE SYNONYM [BI2].[GPExpensesData] FOR [PROD_GP_A].[BI2].[GPExpensesData]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''UserCostCenter_V1'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM UserCostCenter_V1
END
GO 
CREATE SYNONYM UserCostCenter_V1 FOR [PROD_GP_A].[dbo].[UserCostCenter_V1]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Usercostcenterexception'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM Usercostcenterexception
END
GO 
CREATE SYNONYM Usercostcenterexception FOR [PROD_GP_A].[dbo].[Usercostcenterexception]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''UserCostCenterLocationPermission'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM UserCostCenterLocationPermission
END
GO 
CREATE SYNONYM UserCostCenterLocationPermission FOR [PROD_GP_A].[dbo].[UserCostCenterLocationPermission]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''Organization Tree'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[Organization Tree]
END
GO 
CREATE SYNONYM [BI2].[Organization Tree] FOR [PROD_GP_A].[BI2].[Organization Tree]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''WorkdayUserInformation'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM WorkdayUserInformation
END
GO 
CREATE SYNONYM WorkdayUserInformation FOR [PROD_GP_A].[dbo].[WorkdayUserInformation]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''WorkdayUserInformation_All'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM WorkdayUserInformation_All
END
GO 
CREATE SYNONYM WorkdayUserInformation_All FOR [PROD_GP_A].[dbo].[WorkdayUserInformation_All]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''2015TravelBudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [2015TravelBudget]
END
GO 
CREATE SYNONYM [2015TravelBudget] FOR [PROD_GP_A].[dbo].[2015TravelBudget]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''GPffInvoiceSummary'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [GPffInvoiceSummary]
END
GO 
CREATE SYNONYM [GPffInvoiceSummary] FOR [PROD_GP_A].[dbo].[GPffInvoiceSummary]; 
GO

IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''OCDCABudget'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[OCDCABudget]
END
GO 
CREATE SYNONYM [BI2].[OCDCABudget] FOR [PROD_GP_A].[BI2].[OCDCABudget]; 
GO

--------Added on 24/07/2019
IF EXISTS (SELECT * FROM SYS.SYNONYMS WHERE NAME = ''OCDCAprojectname_Purchase'' AND OBJECT_ID(BASE_OBJECT_NAME) IS NOT NULL)
BEGIN
DROP SYNONYM [BI2].[OCDCAprojectname_Purchase]
END
GO 
CREATE SYNONYM [BI2].[OCDCAprojectname_Purchase] FOR [PROD_GP_A].[BI2].[OCDCAprojectname_Purchase]; 
GO', 
		@database_name=N'PROD_GP', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Restore PROD_GP_B]    Script Date: 11-03-2020 17:12:11 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Restore PROD_GP_B', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''PROD_GP_B''
GO
USE [master]
GO
ALTER DATABASE [PROD_GP_B] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
ALTER DATABASE [PROD_GP_B] SET  SINGLE_USER 
GO
USE [master]
GO
RESTORE DATABASE [PROD_GP_B] FROM  DISK = N''\\FFGCP0558\TEMPSQLBCKP\PROD_GP.BAK''
WITH  
MOVE ''GBS_DW_Base_Staging_UAT'' TO ''D:\MSSQL\DATA\PROD_FF_Grants_DW_Staging_B.mdf'', 
MOVE ''ftrow_GRANTEENAME'' TO ''D:\MSSQL\DATA\PROD_FF_Grants_DW_Staging_1_B.ndf'', 
MOVE ''GBS_DW_Base_Staging_UAT_log'' TO ''G:\LOG1\PROD_FF_Grants_DW_Staging_2_B.ldf'', 
FILE = 1,  
NOUNLOAD,  REPLACE,  STATS = 10
GO
ALTER DATABASE [PROD_GP_B] SET  MULTI_USER 
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Set Database Compatibility Level]    Script Date: 11-03-2020 17:12:11 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Set Database Compatibility Level', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'------PROD_GP
EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N''PROD_GP''
GO
USE [master]
GO
ALTER DATABASE [PROD_GP] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
ALTER DATABASE [PROD_GP] SET  SINGLE_USER 
GO
USE [master]
GO
ALTER DATABASE [PROD_GP] SET COMPATIBILITY_LEVEL = 100
GO 
ALTER DATABASE [PROD_GP] SET  MULTI_USER 
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


