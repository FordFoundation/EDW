/****** Object:  StoredProcedure [dbo].[GPAuditData]    Script Date: 11-03-2020 16:03:27 ******/
DROP PROCEDURE [dbo].[GPAuditData]
GO

/****** Object:  StoredProcedure [dbo].[GPAuditData]    Script Date: 11-03-2020 16:03:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*=============================================               
  
Revision History:        
******************  
Created By  : Lijojose   
Created At  : 06/29/2018
Modified At : 
Description : GP Audit Data

Modified By: 
Modified on: 
Description: 
-- EXEC [dbo].GPAuditData

--QS 2/7/2019 (1) add  ACCTTYPE ACTNUMBR_3 in the Dim_ChartOfAccounts table
              ALTER TABLE Dim_ChartOfAccounts ADD AcctType smallint not null,ACTNUMBR_3 char(7) not null ;
              (2) update insert scripts for Dim_ChartOfAccounts table
			  (3) use select * into from to create Fact_PurchasingReceipts2Requisitions table
			  (4) update insert script for Fact_PurchasingReceipts2Requisitions table
			  (5) add Receipt_Line_Number in the Fact_ReceiveMatchInvoices
			  ALTER TABLE Fact_ReceiveMatchInvoices ADD Receipt_Line_Number smallint  null;
--QS 3/8/2019 add new column Extended_Cost_LC at Fact_PurchasingReceipts
              ALTER TABLE Fact_PurchasingReceipts ADD Extended_Cost_LC numeric(19,5)  not null ;
              update Fact_PurchasingReceipts refresh scripts

=============================================*/

CREATE PROC [dbo].[GPAuditData] AS

--select * from  Dim_ChartOfAccounts
--QS 2/7/2019 add  ACCTTYPE ACTNUMBR_3 in the Dim_ChartOfAccounts table
Truncate Table [dbo].[Dim_ChartOfAccounts]

INSERT INTO [dbo].[Dim_ChartOfAccounts]
SELECT GL00100.ACTINDX, GL00105.ACTNUMST, GL00100.ACTDESCR, GL00100.ACTIVE, GL00100.ACCATNUM,
GL00100.PSTNGTYP, GL00100.TPCLBLNC, GL00100.ACCTTYPE,GL00100.ACTNUMBR_3
FROM [FFSMQ0300].FORD.dbo.GL00100 GL00100 With (nolock)
LEFT JOIN [FFSMQ0300].FORD.dbo.GL00105 GL00105 With (nolock) ON GL00100.ACTINDX=GL00105.ACTINDX

--Dim_Vendors
Truncate Table [dbo].[Dim_Vendors]

INSERT INTO [dbo].[Dim_Vendors]
SELECT PM00200.VENDORID, PM00200.VENDNAME, PM00200.VNDCHKNM, PM00200.VNDCLSID, PM00200.ACNMVNDR
FROM [FFSMQ0300].FORD.dbo.PM00200 PM00200 With (nolock) Where 1=1

--Dim_Vendors
Truncate Table [dbo].[Dim_Department]

INSERT INTO [dbo].[Dim_Department]
Select idfwcdeptkey as deptkey, idfdeptid as [DeptID], idfDescription as [Department]
From [FFSMQ0300].FORD.dbo.Wcdept department With (nolock) Where 1=1

--Fact_GeneralLedger
Truncate Table [dbo].[Fact_GeneralLedger]

INSERT INTO [dbo].[Fact_GeneralLedger]
SELECT GL20000.JRNENTRY, GL20000.TRXDATE, GL20000.SOURCDOC, GL20000.REFRENCE, GL20000.ACTINDX,
GL20000.ORMSTRID, GL20000.ORCTRNUM, GL20000.DEBITAMT, GL20000.CRDTAMNT, GL20000.ORDBTAMT,
GL20000.ORCRDAMT, GL20000.CURNCYID, GL20000.USWHPSTD, GL20000.DEX_ROW_ID 
FROM [FFSMQ0300].FORD.dbo.GL20000 GL20000 With (nolock) Where 1=1
Union All
SELECT  GL30000.JRNENTRY, GL30000.TRXDATE, GL30000.SOURCDOC, GL30000.REFRENCE, GL30000.ACTINDX,
GL30000.ORMSTRID, GL30000.ORCTRNUM, GL30000.DEBITAMT, GL30000.CRDTAMNT, GL30000.ORDBTAMT,
GL30000.ORCRDAMT, GL30000.CURNCYID, GL30000.USWHPSTD, GL30000.DEX_ROW_ID 
FROM [FFSMQ0300].FORD.dbo.GL30000 GL30000 With (nolock) Where 1=1

--Fact_PayablesTransactions
Truncate Table Fact_PayablesTransactions

INSERT INTO Fact_PayablesTransactions
SELECT VCHRNMBR, VENDORID,
 CASE DOCTYPE
  WHEN 1 THEN 'Invoice'
  WHEN 2 THEN 'Finance Charge'
  WHEN 3 THEN 'Misc Charge'
  WHEN 4 THEN 'Return'
  WHEN 5 THEN 'Credit Memo'
  WHEN 6 THEN 'Payment'
 END ,  DOCDATE, DOCNUMBR, DOCAMNT, BACHNUMB, CHEKBKID, VNDCHKNM, DEX_ROW_ID,VOIDED,POSTEDDT,Vendors.[1099 Type],
 PORDNMBR --Added on 26/02/2020
FROM [FFSMQ0300].FORD.dbo.PM20000 PM20000 With (nolock) 
left join (select distinct  [1099 Type] ,[vendor id],[document number] from [FFSMQ0300].FORD.dbo.PayablesTransactions With (nolock) ) Vendors 
on Vendors.[vendor id]=PM20000.VENDORID  AND DOCNUMBR= Vendors.[document number] 
Where 1=1
Union All
SELECT VCHRNMBR, VENDORID,
 CASE DOCTYPE
  WHEN 1 THEN 'Invoice'
  WHEN 2 THEN 'Finance Charge'
  WHEN 3 THEN 'Misc Charge'
  WHEN 4 THEN 'Return'
  WHEN 5 THEN 'Credit Memo'
  WHEN 6 THEN 'Payment'
 END ,  DOCDATE, DOCNUMBR, DOCAMNT, BACHNUMB, CHEKBKID, VNDCHKNM, DEX_ROW_ID,VOIDED,POSTEDDT,Vendors.[1099 Type],
 PORDNMBR --Added on 26/02/2020
FROM [FFSMQ0300].FORD.dbo.PM30200 PM30200 With (nolock) 
left join (select distinct  [1099 Type] ,[vendor id],[document number] from [FFSMQ0300].FORD.dbo.PayablesTransactions With (nolock) ) Vendors 
on Vendors.[vendor id]=PM30200.VENDORID AND DOCNUMBR= Vendors.[document number]
Where 1=1

--Fact_PayablesApplication
Truncate table Fact_PayablesApplication

INSERT INTO Fact_PayablesApplication
SELECT VENDORID [Vendor_ID], DOCDATE [Document_Date], VCHRNMBR [Voucher_Number],
 CASE DOCTYPE
  WHEN 1 THEN 'Invoice'
  WHEN 2 THEN 'Finance Charge'
  WHEN 3 THEN 'Misc Charge'
  WHEN 4 THEN 'Return'
  WHEN 5 THEN 'Credit Memo'
  WHEN 6 THEN 'Payment'
 END [Document_Type], APTVCHNM [Apply_To_Voucher_Number],
 CASE APTODCTY
  WHEN 1 THEN 'Invoice'
  WHEN 2 THEN 'Finance Charge'
  WHEN 3 THEN 'Misc Charge'
  WHEN 4 THEN 'Return'
  WHEN 5 THEN 'Credit Memo'
  WHEN 6 THEN 'Payment'
 END [Apply_To_Document_Type], APPLDAMT [Applied_Amount], ORAPPAMT [Originating_Applied_Amount], CURNCYID [Currency_ID],
 DEX_ROW_ID [Record_ID] FROM [FFSMQ0300].FORD.dbo.PM10200  PM10200 With (nolock) Where 1=1
Union All
SELECT VENDORID [Vendor_ID], DOCDATE [Document_Date], VCHRNMBR [Voucher_Number],
 CASE DOCTYPE
  WHEN 1 THEN 'Invoice'
  WHEN 2 THEN 'Finance Charge'
  WHEN 3 THEN 'Misc Charge'
  WHEN 4 THEN 'Return'
  WHEN 5 THEN 'Credit Memo'
  WHEN 6 THEN 'Payment'
 END [Document_Type], APTVCHNM [Apply_To_Voucher_Number],
 CASE APTODCTY
  WHEN 1 THEN 'Invoice'
  WHEN 2 THEN 'Finance Charge'
  WHEN 3 THEN 'Misc Charge'
  WHEN 4 THEN 'Return'
  WHEN 5 THEN 'Credit Memo'
  WHEN 6 THEN 'Payment'
 END [Apply_To_Document_Type], APPLDAMT [Applied_Amount], ORAPPAMT [Originating_Applied_Amount], CURNCYID [Currency_ID],
 DEX_ROW_ID [Record_ID] FROM [FFSMQ0300].FORD.dbo.PM30300 PM30300 With (nolock) Where 1=1

--Fact_PurchasingReceipts
Truncate Table Fact_PurchasingReceipts

INSERT INTO Fact_PurchasingReceipts
SELECT POP30300.POPRCTNM [POP_Receipt_Number],
CASE POPTYPE
 WHEN 1 THEN 'Shipment'
 WHEN 2 THEN 'Invoice'
 WHEN 3 THEN 'Shipment/Invoice'
 WHEN 4 THEN 'Return'
 WHEN 5 THEN 'Return w/Credit'
 WHEN 6 THEN 'Inventory Return'
 WHEN 7 THEN 'Inventory Return w/Credit'
 WHEN 8 THEN 'Intransit Transfer'
END [POP_Type], VNDDOCNM [Vendor_Document_Number],receiptdate [Receipt_Date],GLPOSTDT [GL_Post_Date],VCHRNMBR [Voucher_Number],
RCPTLNNM [Receipt_Line_Number],PONUMBER [PO_Number],ITEMNMBR [Item_Number],ITEMDESC [Item_Description],EXTDCOST [Extended_Cost],
ProjNum [Project_Number],CostCatID [Cost_Category_ID],INVINDX [Inventory_Index],POP30310.DEX_ROW_ID [Record_ID],OREXTCST Extended_Cost_LC
FROM [FFSMQ0300].FORD.dbo.POP30300 POP30300 With (nolock)
JOIN [FFSMQ0300].FORD.dbo.POP30310 POP30310 With (nolock) ON POP30300.POPRCTNM=POP30310.POPRCTNM

--Fact_ReceiveMatchInvoices
Truncate Table Fact_ReceiveMatchInvoices

INSERT INTO Fact_ReceiveMatchInvoices
SELECT RCVHeader.idfRCVHeaderKey [Receive_Match_Invoice_Number],
 CASE idfTransactionType
  WHEN 1 THEN 'Shipment'
  WHEN 2 THEN 'Invoice'
  WHEN 3 THEN 'Shipment'
 END [Transaction_Type], RCVHeader.idfComment [Comment], idfDateActual [Date_Actual], idfDateReceipt [Date_Receipt],
 edfFacilityID [Facility_ID], edfReceiptNumber [Receipt_Number], edfVendor [Vendor_ID], edfVendorDocNum [Vendor_Document_Number],
 edfPONumber [PO_Number], edfItem [Item], edfItemDesc [Item_Description], edfAmtExtended [Extended_Amount], edfCurrency [Currency],
 RCVDetail.idfRCVDetailKey [Record_ID], RCVDetail.idfline  Receipt_Line_Number
 FROM [FFSMQ0300].FORD.dbo.RCVHeader RCVHeader With (nolock)
 LEFT JOIN [FFSMQ0300].FORD.dbo.RCVDetail RCVDetail With (nolock) ON RCVHeader.idfRCVHeaderKey=RCVDetail.idfRCVHeaderKey 
 --order by RCVDetail.idfline 

--Fact_Requisitions
Truncate Table Fact_Requisitions 

INSERT INTO Fact_Requisitions 
SELECT  RQHeader.idfRQHeaderKey [Requisition], RQHeader.idfDescription [Business_Purpose], RQHeader.idfDateCreated [Created],
RQHeader.idfRQDate [Date], 
--NULL as edfVendorDocNum,
 CASE RQHeader.idfRQTypeKey
  WHEN 3 THEN 'Check Request'
  WHEN 1 THEN 'Requisition'
 END [Type],  RQHeader.edfFacilityID [Facility_ID], RQHeader.edfDocumentID [Document_ID], RQDetail.idfLine [Line],
 RQDetail.edfItem [Item], RQDetail.edfItemDesc [Item_Description], RQDetail.edfVendor [Vendor], RQDetail.edfPONumber [PO_Number],
 RQDetail.edfPOLine [PO_Line],  RQDetail.idfRQDetailKey [Record_ID]--, RQDetail.idfwcdeptkey as deptkey 
 FROM [FFSMQ0300].FORD.dbo.RQHeader RQHeader With (nolock)
 LEFT JOIN [FFSMQ0300].FORD.dbo.RQDetail RQDetail With (nolock) ON RQHeader.idfRQHeaderKey=RQDetail.idfRQHeaderKey

--Fact_PurchaseOrders
Truncate Table Fact_PurchaseOrders

INSERT INTO Fact_PurchaseOrders
SELECT POP10100.PONUMBER [PO_Number], POP10100.DOCDATE [Document_Date], POP10100.VENDORID [Vendor_ID], POP10100.VENDNAME [Vendor_Name],
 POP10110.ORD [Ord], POP10110.ITEMNMBR [Item_Number], POP10110.ITEMDESC [Item_Description], POP10110.EXTDCOST [Extended_Cost],
 POP10110.OREXTCST [Originating_Extended_Cost], POP10110.CURNCYID [Currency ID], POP10110.DEX_ROW_ID [Record_ID]
FROM [FFSMQ0300].FORD.dbo.POP10100 POP10100 With (nolock)
LEFT JOIN [FFSMQ0300].FORD.dbo.POP10110 POP10110 With (nolock) ON POP10100.PONUMBER=POP10110.PONUMBER

--Fact_RequisitionsLog
Truncate Table Fact_RequisitionsLog

INSERT INTO Fact_RequisitionsLog
SELECT RQDetailLog.idfRQDetailKey [Requisitions_Record_ID], RQDetailLog.idfDateCreated [Date_Time],
 CASE RQDetailLog.idfWCLogTypeKey
  WHEN 100 THEN 'Created'
  WHEN 102 THEN 'Recalled'
  WHEN 103 THEN 'Change Order'
  WHEN 105 THEN 'Disapproved'
  WHEN 110 THEN 'Submitted'
  WHEN 115 THEN 'Resubmitted'
  WHEN 117 THEN 'Modified'
  WHEN 130 THEN 'Approved'
  WHEN 140 THEN 'Auto Approved'
  WHEN 141 THEN 'Escalated Auto Approved'
  WHEN 165 THEN 'Batch'
  WHEN 170 THEN 'Processed'
  WHEN 171 THEN 'Transfered'
  WHEN 172 THEN 'Fulfilled'
  WHEN 173 THEN 'Supplied'
  WHEN 180 THEN 'Canceled'
 END [Type], WCSecurity.idfDescription [Name], RQDetailLog.idfRQDetailLogKey [Record_ID]
FROM [FFSMQ0300].FORD.dbo.RQDetailLog RQDetailLog With (nolock)
LEFT JOIN [FFSMQ0300].FORD.dbo.WCSecurity WCSecurity With (nolock) ON RQDetailLog.idfWCSecurityKey=WCSecurity.idfWCSecurityKey
 

 truncate table Fact_PurchasingReceipts2Requisitions
 --drop table Fact_PurchasingReceipts2Requisitions
 --select * 
 --into Fact_PurchasingReceipts2Requisitions
 --from (
 insert into  Fact_PurchasingReceipts2Requisitions
    SELECT
             CheckRequests2Requisitions.[Invoice Receipt Number] Invoice_Receipt_Number,
             CheckRequests2Requisitions.[Invoice Receipt Line] Invoice_Receipt_Line,
             RQDetail.idfRQHeaderKey Requisition_Number,
             ROW_NUMBER() OVER(PARTITION BY RQDetail.idfRQHeaderKey ORDER BY RQDetail.idfRQDetailkey ASC) 
, 
RQDetail.edfPONumber as [PONumber],
RQDetail.edfPOLine as [POLine]
            FROM (SELECT
                   POP10500.POPRCTNM [Invoice Receipt Number],
                   POP10500.RCPTLNNM [Invoice Receipt Line],
                   MAX(RQDetail.idfRQDetailKey) idfRQDetailKey
                  FROM [FFSMQ0300].FORD.dbo.POP10500 POP10500 (NOLOCK)
                   JOIN [FFSMQ0300].FORD.dbo.RCVHeader RCVHeader (NOLOCK) ON POP10500.POPRCTNM=RCVHeader.edfReceiptNumber
                   JOIN [FFSMQ0300].FORD.dbo.RCVDetail RCVDetail  (NOLOCK) ON RCVHeader.idfRCVHeaderKey=RCVDetail.idfRCVHeaderKey
                   JOIN [FFSMQ0300].FORD.dbo.RQDetail RQDetail (NOLOCK) ON RCVDetail.idfRCVDetailKey=RQDetail.idfRCVDetailKey
                  WHERE 1=1
                   AND POP10500.POPTYPE IN (2,3)
                   AND PONUMBER=''
                   AND POLNENUM=0
                  GROUP BY POP10500.POPRCTNM, POP10500.RCPTLNNM) CheckRequests2Requisitions
                   JOIN [FFSMQ0300].FORD.dbo.RQDetail RQDetail (NOLOCK) ON CheckRequests2Requisitions.idfRQDetailKey=RQDetail.idfRQDetailKey
                   JOIN [FFSMQ0300].FORD.dbo.RQHeader RQHeader(NOLOCK) ON RQDetail.idfRQHeaderKey=RQHeader.idfRQHeaderKey
            WHERE 1=1 --AND CheckRequests2Requisitions.[Invoice Receipt Number]='RCT00143205'

            UNION ALL

SELECT 
             POP10500.POPRCTNM Invoice_Receipt_Number,
             POP10500.RCPTLNNM Invoice_Receipt_Line,
             RQDetail.idfRQHeaderKey Requisition_Number,
             --ROW_NUMBER() OVER(PARTITION BY RQDetail.idfRQHeaderKey ORDER BY RQDetail.idfRQDetailkey ASC) 
RQDetail.idfline Requisition_Line,--RQDetail.idfLine [Requisition Line],
RQDetail.edfPONumber as [PONumber],
RQDetail.edfPOLine as [POLine]
            FROM [FFSMQ0300].FORD.dbo.POP10500 POP10500 (NOLOCK)
             JOIN [FFSMQ0300].FORD.dbo.RQDetail RQDetail(NOLOCK) ON POP10500.PONUMBER=RQDetail.edfPONumber
                                        AND POP10500.POLNENUM=RQDetail.edfPOLine
             ------JOIN (SELECT MAX(RQDetail.idfRQDetailKey) idfRQDetailKey
             ------      FROM [FFSMQ0300].FORD.dbo.RQDetail RQDetail (NOLOCK)
             ------      WHERE RQDetail.edfPONumber<>'' AND RQDetail.edfPOLine<>''
             ------      GROUP BY RQDetail.edfPONumber, RQDetail.edfPOLine) ValidRQDetail ON RQDetail.idfRQDetailKey=ValidRQDetail.idfRQDetailKey
             JOIN [FFSMQ0300].FORD.dbo.RQHeader RQHeader (NOLOCK) ON RQDetail.idfRQHeaderKey=RQHeader.idfRQHeaderKey
            WHERE 1=1 --AND POP10500.POPRCTNM='RCT00131900'
             AND POP10500.POPTYPE IN (2,3)
             AND POP10500.PONUMBER <> ''


--) as A







GO


